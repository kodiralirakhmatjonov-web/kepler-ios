-- Expand the live DevSMS challenge table for standalone SMS sign-in and registration.
-- Existing verification/activation rows are preserved.
CREATE TABLE IF NOT EXISTS iumrah_client_sms_challenges_v2 (
  id TEXT PRIMARY KEY,
  purpose TEXT NOT NULL CHECK (purpose IN ('verify_phone','activate_account','login_phone','register_phone')),
  pilgrim_id INTEGER NOT NULL,
  phone_normalized TEXT NOT NULL,
  phone_display TEXT NOT NULL,
  code_salt TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  code_iterations INTEGER NOT NULL DEFAULT 100000,
  attempts INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 5,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  consumed_at TEXT,
  request_ip_hash TEXT NOT NULL DEFAULT '',
  provider_sms_id TEXT,
  provider_request_id TEXT,
  provider_status TEXT,
  FOREIGN KEY (pilgrim_id) REFERENCES pilgrims(id) ON DELETE CASCADE
);

INSERT OR IGNORE INTO iumrah_client_sms_challenges_v2 (
  id,purpose,pilgrim_id,phone_normalized,phone_display,code_salt,code_hash,
  code_iterations,attempts,max_attempts,expires_at,created_at,consumed_at,
  request_ip_hash,provider_sms_id,provider_request_id,provider_status
)
SELECT
  id,purpose,pilgrim_id,phone_normalized,phone_display,code_salt,code_hash,
  code_iterations,attempts,max_attempts,expires_at,created_at,consumed_at,
  request_ip_hash,provider_sms_id,provider_request_id,provider_status
FROM iumrah_client_sms_challenges;

DROP TABLE iumrah_client_sms_challenges;
ALTER TABLE iumrah_client_sms_challenges_v2 RENAME TO iumrah_client_sms_challenges;

CREATE INDEX IF NOT EXISTS idx_iumrah_client_sms_challenge_lookup
ON iumrah_client_sms_challenges(purpose, phone_normalized, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_iumrah_client_sms_challenge_account
ON iumrah_client_sms_challenges(pilgrim_id, created_at DESC);
