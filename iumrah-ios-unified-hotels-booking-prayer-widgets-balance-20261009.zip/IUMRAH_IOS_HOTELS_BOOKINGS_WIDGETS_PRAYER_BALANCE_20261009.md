# iumrah iOS — Hotels, Booking widgets, Prayer Times, Balance

This ZIP is a **cumulative root patch** based on `kepler-ios-main 4.zip`. It includes the full Prayer Times + seven wallpapers update from 2026-10-09 so that no earlier Prayer Times ZIP is required.

## Changes

- **Hotels:** matched the Account tab's 18-point horizontal page padding, 12-point top padding, 46-point bottom padding; removed forced clipping and the extra 112-point bottom spacer. The flights assembly control keeps a bottom inset only while the Flights board is selected.
- **Gift Cards:** replaced the previous gift issuance, activation and sharing interface with a read-only native-looking `iumrah Balance` surface. The UI explicitly marks the unlaunched balance and gift functionality as unavailable; no fabricated USD balance is displayed.
- **Booking empty state:** renders the three-page Prayer / Weather / World Clock carousel even when there is no active booking. Prayer times are calculated offline immediately; a later API response may refine them. Active bookings keep the carousel.
- **Navigation:** tapping the Prayer widget card opens Prayer Times; tapping weather opens a dedicated Saudi Weather screen. The weather page supports Makkah/Madinah and a seven-day forecast when available.
- **SF Symbols:** weather icons use native multicolor symbol rendering rather than mapping the sun to a blue palette.
- **Prayer Times:** explicit Makkah/Madinah quick selector above the countdown, early reminders (5 / 10 / 15 / 30 min) independent of the main reminder, and existing test notification scheduled 5 seconds after tap.
- **Home Screen WidgetKit:** adds separate Makkah Prayer Times and Makkah Weather widgets (small and medium). Tapping them deep-links to the corresponding in-app pages. The weather widget fetches MET Norway data; WidgetKit determines the actual refresh cadence.
- **Add widgets help:** an in-app sheet shows the official Home Screen placement steps. iOS does not allow an app to install Home Screen widgets automatically.
- **Prior Prayer Times update:** includes offline calculator, notification settings, city selection, all seven normalized wallpapers, account navigation, and existing notification delegate integration.

## Verification performed in this environment

- All Swift source and widget files parsed with Swift 6.2 `swiftc -frontend -parse` on Linux.
- Pure Foundation prayer calculator compiled and passed 800 combinations of cities, methods, Asr schools and days.
- XcodeGen YAML, asset Contents.json metadata, wallpaper dimensions and ZIP integrity checked.

## Required final QA

An Xcode / iOS SDK build cannot run in this environment. **A passing parser does not establish type-checking or build success.** Run the existing `TestFlight` GitHub workflow, including the `com.iumrah.app.widgets` provisioning profile, and test on iPhone 11 and iPhone 13 mini. Check Hotel top/bottom safe areas, the empty Booking carousel, weather without network, widget placement/deep links, custom notification permissions and all Gift Card entry points.
