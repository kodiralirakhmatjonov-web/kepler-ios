import SwiftUI

/// Production-safe balance surface. Gift issuance, redemption and sharing are
/// deliberately unavailable until the product is launched and verified.
struct IumrahGiftCardsView: View {
    @EnvironmentObject private var settings: AppSettingsStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(tr("Balance", "Баланс", "Balans", "Баланс"))
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                    Text(tr("Your iumrah account overview", "Обзор вашего аккаунта iumrah", "iumrah hisobingiz ko‘rinishi", "iumrah ҳисобингиз кўриниши"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.top, 8)

                VStack(alignment: .leading, spacing: 24) {
                    HStack(alignment: .top) {
                        Image(systemName: "wallet.pass.fill")
                            .font(.system(size: 24, weight: .medium))
                            .frame(width: 54, height: 54)
                            .foregroundStyle(.white)
                            .background(.white.opacity(0.16), in: RoundedRectangle(cornerRadius: 17))
                        Spacer()
                        Label(tr("Coming soon", "Скоро", "Tez kunda", "Тез кунда"), systemImage: "clock")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(.white.opacity(0.14), in: Capsule())
                    }
                    VStack(alignment: .leading, spacing: 9) {
                        Text("iumrah Balance")
                            .font(.system(size: 15, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.70))
                        Text("—")
                            .font(.system(size: 48, weight: .bold, design: .rounded))
                        Text(tr("Not available yet", "Пока недоступен", "Hozircha mavjud emas", "Ҳозирча мавжуд эмас"))
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.75))
                    }
                }
                .padding(24)
                .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundStyle(.white)
                .background {
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .fill(LinearGradient(colors: [Color(red: 0.13, green: 0.19, blue: 0.30), Color(red: 0.04, green: 0.08, blue: 0.14)], startPoint: .topLeading, endPoint: .bottomTrailing))
                }

                VStack(alignment: .leading, spacing: 14) {
                    Text(tr("Account features", "Возможности аккаунта", "Hisob imkoniyatlari", "Ҳисоб имкониятлари"))
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                    infoRow(icon: "creditcard.fill", title: tr("iumrah Balance", "Баланс iumrah", "iumrah balansi", "iumrah баланси"), detail: tr("Under preparation", "В разработке", "Tayyorlanmoqda", "Тайёрланмоқда"))
                    infoRow(icon: "gift.fill", title: "Gift Cards", detail: tr("Not available in production", "Пока не запущены", "Hali ishga tushirilmagan", "Ҳали ишга туширилмаган"))
                }

                Label(tr("Gift Cards cannot be purchased, activated, or shared yet. Your bookings and payments are not affected.", "Покупка, активация и отправка Gift Cards пока отключены. Бронирования и платежи работают отдельно.", "Gift Card sotib olish, faollashtirish va ulashish hali yopiq. Bron va to‘lovlarga ta’sir qilmaydi.", "Gift Card сотиб олиш, фаоллаштириш ва улашиш ҳали ёпиқ. Брон ва тўловларга таъсир қилмайди."), systemImage: "lock.shield")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 20))
            }
            .padding(.horizontal, IumrahDesign.pagePadding)
            .padding(.top, 12)
            .padding(.bottom, 46)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(Color.iumrahPageBackground)
        .navigationTitle(tr("Balance", "Баланс", "Balans", "Баланс"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func infoRow(icon: String, title: String, detail: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 21))
                .foregroundStyle(.orange)
                .frame(width: 49, height: 49)
                .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 16))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            Image(systemName: "lock.fill")
                .font(.subheadline)
                .foregroundStyle(.tertiary)
        }
        .padding(16)
        .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private func tr(_ en: String, _ ru: String, _ uz: String, _ cy: String) -> String {
        switch settings.language {
        case .english: en
        case .russian: ru
        case .uzbek: uz
        case .uzbekCyrillic: cy
        }
    }
}
