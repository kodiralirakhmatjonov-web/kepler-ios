import SwiftUI

struct IumrahWeatherDetailView: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @AppStorage("iumrah.booking.travelInfo.city") private var selectedCityRaw = IumrahHolyCity.makkah.rawValue
    @StateObject private var model = JourneyTravelInfoModel()

    private var city: IumrahHolyCity { IumrahHolyCity(rawValue: selectedCityRaw) ?? .makkah }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {
                Picker(local("Holy city", "Священный город", "Muqaddas shahar", "Муқаддас шаҳар"), selection: $selectedCityRaw) {
                    ForEach(IumrahHolyCity.allCases) { city in
                        Text(city.title(settings.language)).tag(city.rawValue)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.top, 10)

                weatherHero
                if let forecast = model.weather {
                    VStack(alignment: .leading, spacing: 14) {
                        Text(local("Next 7 days", "Ближайшие 7 дней", "Kelgusi 7 kun", "Келгуси 7 кун"))
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                        ForEach(forecast.days.prefix(7)) { day in
                            HStack(spacing: 14) {
                                Text(day.dayLabel(language: settings.language, timeZone: city.timeZone))
                                    .font(.headline)
                                    .frame(width: 65, alignment: .leading)
                                Image(systemName: day.condition.symbol)
                                    .symbolRenderingMode(.multicolor)
                                    .font(.system(size: 25))
                                    .frame(width: 38)
                                Text(day.condition.localized(settings.language))
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                Spacer(minLength: 4)
                                Text("\(Int(day.high.rounded()))°")
                                    .font(.headline.monospacedDigit())
                                Text("\(Int(day.low.rounded()))°")
                                    .font(.headline.monospacedDigit())
                                    .foregroundStyle(.secondary)
                            }
                            .padding(.horizontal, 17)
                            .padding(.vertical, 14)
                            .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 21))
                        }
                    }
                    Text(forecast.updatedLabel(language: settings.language, timeZone: city.timeZone) + " · MET Norway")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else if model.isRefreshing {
                    HStack(spacing: 12) {
                        ProgressView()
                        Text(local("Loading forecast…", "Загружаем прогноз…", "Prognoz yuklanmoqda…", "Прогноз юкланмоқда…"))
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 26)
                } else {
                    Label(local("Weather is currently unavailable. Pull down to retry.", "Погода пока недоступна. Потяните вниз, чтобы повторить.", "Ob-havo hozircha mavjud emas. Qayta urinish uchun pastga torting.", "Об-ҳаво ҳозирча мавжуд эмас. Қайта уриниш учун пастга тортинг."), systemImage: "wifi.slash")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 24))
                }
            }
            .padding(.horizontal, IumrahDesign.pagePadding)
            .padding(.bottom, 46)
            .frame(maxWidth: 680)
            .frame(maxWidth: .infinity)
        }
        .background(Color.iumrahPageBackground)
        .navigationTitle(local("Saudi weather", "Погода Саудии", "Saudiya ob-havosi", "Саудия об-ҳавоси"))
        .navigationBarTitleDisplayMode(.inline)
        .task(id: city.rawValue) { await model.refresh(city: city) }
        .refreshable { await model.refresh(city: city, force: true) }
    }

    private var weatherHero: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Label(local("CURRENT WEATHER", "ПОГОДА СЕЙЧАС", "HOZIRGI OB-HAVO", "ҲОЗИРГИ ОБ-ҲАВО"), systemImage: "location.fill")
                        .font(.caption.weight(.semibold))
                        .tracking(0.6)
                        .foregroundStyle(.white.opacity(0.72))
                    Text(city.title(settings.language))
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Image(systemName: model.weather?.currentCondition.symbol ?? "cloud.sun.fill")
                    .symbolRenderingMode(.multicolor)
                    .font(.system(size: 58))
            }
            Spacer(minLength: 20)
            HStack(alignment: .lastTextBaseline, spacing: 14) {
                Text(model.weather.map { "\(Int($0.currentTemperature.rounded()))°" } ?? "—")
                    .font(.system(size: 77, weight: .light, design: .rounded))
                    .minimumScaleFactor(0.7)
                    .foregroundStyle(.white)
                Spacer()
                Text(model.weather?.currentCondition.localized(settings.language) ?? "")
                    .font(.subheadline.weight(.medium))
                    .multilineTextAlignment(.trailing)
                    .foregroundStyle(.white.opacity(0.85))
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, minHeight: 255)
        .background {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(LinearGradient(colors: [Color(red: 0.10, green: 0.31, blue: 0.56), Color(red: 0.20, green: 0.51, blue: 0.66)], startPoint: .topLeading, endPoint: .bottomTrailing))
        }
    }

    private func local(_ en: String, _ ru: String, _ uz: String, _ cy: String) -> String {
        switch settings.language {
        case .english: en
        case .russian: ru
        case .uzbek: uz
        case .uzbekCyrillic: cy
        }
    }
}

struct IumrahAddWidgetsSheet: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    HStack(spacing: 12) {
                        preview(symbol: "moon.stars.fill", caption: local("Prayer times", "Времена молитв", "Namoz vaqtlari", "Намоз вақтлари"), accent: .indigo)
                        preview(symbol: "cloud.sun.fill", caption: local("Makkah weather", "Погода Мекки", "Makka ob-havosi", "Макка об-ҳавоси"), accent: .orange)
                    }
                    .padding(.top, 20)

                    VStack(alignment: .leading, spacing: 17) {
                        step(1, local("Go to your iPhone Home Screen and touch and hold an empty area.", "На главном экране iPhone удерживайте пустое место.", "iPhone bosh ekranidagi bo‘sh joyni bosib turing.", "iPhone бош экранидаги бўш жойни босиб туринг."))
                        step(2, local("Tap Edit → Add Widget (or the + button).", "Выберите «Изменить» → «Добавить виджет» (или +).", "Tahrirlash → Vidjet qo‘shish (yoki +) ni bosing.", "Таҳрирлаш → Виджет қўшиш (ёки +) ни босинг."))
                        step(3, local("Search for iumrah, choose Prayer Times or Weather, then tap Add Widget.", "Найдите iumrah, выберите «Время молитв» или «Погода» и нажмите «Добавить виджет». ", "iumrah ni qidiring, Namoz vaqtlari yoki Ob-havo vidjetini tanlab qo‘shing.", "iumrah ни қидиринг, Намоз вақтлари ёки Об-ҳаво виджетини танлаб қўшинг."))
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 24))

                    Text(local("iOS requires you to place widgets from the Home Screen. Apps cannot install them automatically.", "iOS позволяет размещать виджеты только с главного экрана. Приложение не может установить их автоматически.", "iOS da vidjetlarni faqat bosh ekrandan qo‘shish mumkin. Ilova ularni avtomatik qo‘sha olmaydi.", "iOS да виджетларни фақат бош экрандан қўшиш мумкин. Илова уларни автоматик қўша олмайди."))
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .background(Color.iumrahPageBackground)
            .navigationTitle(local("Home Screen widgets", "Виджеты на экран «Домой»", "Bosh ekran vidjetlari", "Бош экран виджетлари"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(local("Done", "Готово", "Tayyor", "Тайёр")) { dismiss() } } }
        }
        .presentationDetents([.large])
    }

    private func preview(symbol: String, caption: String, accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 32))
                .foregroundStyle(accent)
            Spacer(minLength: 8)
            Text(caption).font(.subheadline.weight(.bold)).lineLimit(2)
        }
        .frame(maxWidth: .infinity, minHeight: 128, alignment: .leading)
        .padding(18)
        .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 24))
    }
    private func step(_ n: Int, _ title: String) -> some View {
        HStack(alignment: .top, spacing: 13) {
            Text("\(n)").font(.headline).foregroundStyle(.white)
                .frame(width: 28, height: 28)
                .background(Color.black, in: Circle())
            Text(title).font(.subheadline).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }
    private func local(_ en: String, _ ru: String, _ uz: String, _ cy: String) -> String {
        switch settings.language {
        case .english: en
        case .russian: ru
        case .uzbek: uz
        case .uzbekCyrillic: cy
        }
    }
}
