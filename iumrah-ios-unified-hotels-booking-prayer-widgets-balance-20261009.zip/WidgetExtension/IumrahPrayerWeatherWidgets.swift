import Foundation
import SwiftUI
import WidgetKit

// Both widgets work without an active booking. Prayer calculations are local;
// weather is fetched on the widget's own bounded system timeline.
private struct IumrahPrayerWidgetEntry: TimelineEntry {
    let date: Date
    let next: IumrahPrayerEntry?
    let today: IumrahPrayerSchedule
}

private struct IumrahPrayerWidgetProvider: TimelineProvider {
    private var makkah: IumrahPrayerPlace { IumrahPrayerPlace.presets[0] }

    func placeholder(in context: Context) -> IumrahPrayerWidgetEntry { entry(at: Date()) }
    func getSnapshot(in context: Context, completion: @escaping (IumrahPrayerWidgetEntry) -> Void) {
        completion(entry(at: Date()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<IumrahPrayerWidgetEntry>) -> Void) {
        let now = Date()
        var dates: [Date] = [now]
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = makkah.timeZone
        for day in 0..<3 {
            guard let date = calendar.date(byAdding: .day, value: day, to: now) else { continue }
            let schedule = IumrahPrayerCalculator.calculate(on: date, place: makkah, method: .ummAlQura, hanafi: false)
            for prayer in schedule.entries where [.fajr, .dhuhr, .asr, .maghrib, .isha].contains(prayer.kind) {
                let refresh = prayer.date.addingTimeInterval(2)
                if refresh > now && refresh < now.addingTimeInterval(48 * 3600) { dates.append(refresh) }
            }
        }
        let entries = dates.sorted().map(entry(at:))
        completion(Timeline(entries: entries, policy: .after(now.addingTimeInterval(45 * 3600))))
    }
    private func entry(at date: Date) -> IumrahPrayerWidgetEntry {
        IumrahPrayerWidgetEntry(
            date: date,
            next: IumrahPrayerCalculator.upcoming(now: date, place: makkah, method: .ummAlQura, hanafi: false),
            today: IumrahPrayerCalculator.calculate(on: date, place: makkah, method: .ummAlQura, hanafi: false)
        )
    }
}

struct IumrahPrayerHomeWidget: Widget {
    let kind = "iumrah.prayer-times"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: IumrahPrayerWidgetProvider()) { entry in
            IumrahPrayerWidgetLayout(entry: entry)
                .containerBackground(for: .widget) { Color(red: 0.07, green: 0.13, blue: 0.23) }
                .widgetURL(URL(string: "iumrah://widget/prayer"))
        }
        .configurationDisplayName("iumrah Prayer Times")
        .description("Next prayer and daily prayer times in Makkah.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

private struct IumrahPrayerWidgetLayout: View {
    @Environment(\.widgetFamily) private var family
    let entry: IumrahPrayerWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 6) {
                Image(systemName: "moon.stars.fill")
                    .foregroundStyle(.orange)
                Text("iumrah · Makkah")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .foregroundStyle(.white)
            Spacer(minLength: 2)
            Text(entry.next?.kind.title ?? "Prayer times")
                .font(.system(size: family == .systemSmall ? 20 : 25, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            if let next = entry.next {
                Text(next.date, style: .timer)
                    .font(.system(size: family == .systemSmall ? 24 : 31, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                if family == .systemMedium {
                    HStack(spacing: 12) {
                        ForEach([IumrahPrayerKind.fajr, .dhuhr, .asr, .maghrib, .isha], id: \.self) { kind in
                            if let date = entry.today.date(for: kind) {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(kind.title)
                                        .font(.system(size: 10, weight: .medium))
                                        .foregroundStyle(.white.opacity(0.70))
                                    Text(entry.today.displayTime(date))
                                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                                        .monospacedDigit()
                                        .foregroundStyle(.white)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                    }
                    .padding(.top, 2)
                } else {
                    Text(entry.today.displayTime(next.date) + " · Saudi time")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.75))
                        .lineLimit(1)
                }
            } else {
                Text("Open iumrah for schedule")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.75))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

private struct IumrahWeatherWidgetEntry: TimelineEntry {
    let date: Date
    let temperature: Double?
    let condition: String
    let low: Double?
    let high: Double?
}

private struct IumrahWeatherWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> IumrahWeatherWidgetEntry {
        IumrahWeatherWidgetEntry(date: Date(), temperature: nil, condition: "", low: nil, high: nil)
    }
    func getSnapshot(in context: Context, completion: @escaping (IumrahWeatherWidgetEntry) -> Void) {
        completion(placeholder(in: context))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<IumrahWeatherWidgetEntry>) -> Void) {
        Task {
            let entry = await fetchWeather() ?? placeholder(in: context)
            // WidgetKit may defer or coalesce refreshes to save battery.
            completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(3600))))
        }
    }

    private func fetchWeather() async -> IumrahWeatherWidgetEntry? {
        var url = URLComponents(string: "https://api.met.no/weatherapi/locationforecast/2.0/compact")
        url?.queryItems = [URLQueryItem(name: "lat", value: "21.4225"), URLQueryItem(name: "lon", value: "39.8262")]
        guard let target = url?.url else { return nil }
        var request = URLRequest(url: target)
        request.timeoutInterval = 8
        request.setValue("iumrah-iOS/2.0 (https://iumrah.app)", forHTTPHeaderField: "User-Agent")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let properties = root["properties"] as? [String: Any],
              let series = properties["timeseries"] as? [[String: Any]],
              let first = series.first,
              let instant = first["data"] as? [String: Any],
              let instantValues = instant["instant"] as? [String: Any],
              let details = instantValues["details"] as? [String: Any],
              let current = details["air_temperature"] as? Double else { return nil }

        let hourly = instant["next_1_hours"] as? [String: Any]
        let summary = hourly?["summary"] as? [String: Any]
        let code = summary?["symbol_code"] as? String ?? ""
        let tempValues = series.prefix(24).compactMap { item -> Double? in
            let data = item["data"] as? [String: Any]
            let current = data?["instant"] as? [String: Any]
            let values = current?["details"] as? [String: Any]
            return values?["air_temperature"] as? Double
        }
        return IumrahWeatherWidgetEntry(date: Date(), temperature: current, condition: code,
                                        low: tempValues.min(), high: tempValues.max())
    }
}

struct IumrahWeatherHomeWidget: Widget {
    let kind = "iumrah.makkah-weather"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: IumrahWeatherWidgetProvider()) { entry in
            IumrahWeatherWidgetLayout(entry: entry)
                .containerBackground(for: .widget) { Color(red: 0.91, green: 0.96, blue: 0.99) }
                .widgetURL(URL(string: "iumrah://widget/weather"))
        }
        .configurationDisplayName("iumrah Makkah Weather")
        .description("Current weather in Makkah. Refreshes when iOS allows.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

private struct IumrahWeatherWidgetLayout: View {
    @Environment(\.widgetFamily) private var family
    let entry: IumrahWeatherWidgetEntry

    private var symbol: String {
        let c = entry.condition.lowercased()
        if c.contains("thunder") { return "cloud.bolt.rain.fill" }
        if c.contains("rain") { return "cloud.rain.fill" }
        if c.contains("snow") { return "cloud.snow.fill" }
        if c.contains("cloud") { return "cloud.sun.fill" }
        if c.contains("clearsky") || c.contains("fair") { return "sun.max.fill" }
        return "cloud.sun.fill"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "location.fill")
                    .foregroundStyle(.orange)
                Text("Makkah")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                Spacer()
                Image(systemName: symbol)
                    .symbolRenderingMode(.multicolor)
                    .font(.system(size: 28))
            }
            Spacer(minLength: 1)
            Text(entry.temperature.map { "\(Int($0.rounded()))°" } ?? "—")
                .font(.system(size: family == .systemSmall ? 51 : 61, weight: .medium, design: .rounded))
                .foregroundStyle(Color(red: 0.06, green: 0.21, blue: 0.36))
            if let low = entry.low, let high = entry.high {
                Text("H: \(Int(high.rounded()))°   L: \(Int(low.rounded()))°")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.secondary)
            } else {
                Text("Weather updates when online")
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}
