import SwiftUI
import PhotosUI
import QuickLook
import UniformTypeIdentifiers
import UIKit
import AuthenticationServices

private enum IumrahActivationMethod: String, CaseIterable, Identifiable {
    case iumrahID
    case email
    case sms

    var id: String { rawValue }
}

private enum IumrahCheckoutLoginMethod: String, CaseIterable, Identifiable {
    case iumrahID
    case email
    case sms

    var id: String { rawValue }
}


enum PilgrimCheckoutPresentation {
    case screen
    case bookingStatus
}

struct PilgrimCheckoutView: View {
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var bookings: BookingStore
    @EnvironmentObject private var account: IumrahAccountStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme

    let bookingID: String
    let presentation: PilgrimCheckoutPresentation

    init(bookingID: String, presentation: PilgrimCheckoutPresentation = .screen) {
        self.bookingID = bookingID
        self.presentation = presentation
    }

    @State private var checkout: IumrahCheckoutResponse?
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var activationMethod: IumrahActivationMethod = .iumrahID
    @State private var activationEmail = ""
    @State private var activationEmailChallengeID = ""
    @State private var activationEmailCode = ""
    @State private var activationPhone = "+998"
    @State private var activationSMSChallengeID = ""
    @State private var activationSMSCode = ""
    @State private var appleNonce = ""
    @State private var isAppleSigningIn = false
    @State private var isGoogleSigningIn = false
    @State private var password = ""
    @State private var passwordConfirm = ""
    @State private var isPasswordVisible = false
    @State private var isPasswordConfirmVisible = false
    @State private var existingLoginMethod: IumrahCheckoutLoginMethod = .iumrahID
    @State private var existingLoginID = ""
    @State private var existingLoginEmail = ""
    @State private var existingLoginPhone = "+998"
    @State private var loginPassword = ""
    @State private var isLoginPasswordVisible = false
    @State private var showExistingAccountLogin = false
    @State private var showPasswordRecovery = false
    @State private var isSubmittingAccount = false
    @State private var travelerEditor: IumrahTravelerForm?
    @State private var paymentMethod = "visa"
    @State private var receiptPhoto: PhotosPickerItem?
    @State private var isUploadingReceipt = false
    @State private var paymeQRImage: UIImage?
    @State private var previewFile: IumrahPreviewFile?
    @State private var isLoadingDocument = false
    @State private var friendsSummary: IumrahFriendsBookingSummary?
    @State private var giftCode = ""
    @State private var isApplyingFriendBenefit = false
    @State private var friendsMessage: String?

    private let service = IumrahAccountService()
    private let bookingService = BookingService()
    private var session: StoredBookingSession? { bookings.booking(id: bookingID) }
    private var isPaymentPending: Bool { checkout?.status.lowercased() == "payment_pending" }
    private var isAvailabilityChecking: Bool { checkout?.status.lowercased() == "availability_check" }
    private var isTravelerEditingAllowed: Bool { isAvailabilityChecking || isPaymentPending }
    private var shouldShowDocuments: Bool {
        guard let checkout else { return false }
        return !checkout.documents.isEmpty || !checkout.receipts.isEmpty || ["paid", "booking_confirmed", "documents_ready", "ready_to_travel", "in_trip", "completed"].contains(checkout.status.lowercased())
    }
    private var accountMatchesTrip: Bool {
        guard let checkout, let id = account.iumrahID else { return false }
        return normalizedID(id) == normalizedID(checkout.iumrahID)
    }

    var body: some View {
        Group {
            if presentation == .screen {
                screenBody
            } else {
                embeddedStatusBody
            }
        }
        .task { await loadCheckout() }
        .onAppear {
            if account.isAuthenticated { Task { await loadFriendsSummary() } }
        }
        .sheet(item: $travelerEditor) { traveler in
            TravelerFormEditorSheet(
                bookingID: bookingID,
                traveler: traveler,
                language: settings.language,
                onSaved: { Task { await loadCheckout(showLoader: false) } }
            )
            .environmentObject(account)
        }
        .sheet(item: $previewFile) { file in
            NavigationStack {
                QuickLookFilePreview(url: file.url)
                    .ignoresSafeArea(edges: .bottom)
                    .navigationTitle(file.title)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button(tr("Done", "Готово", "Tayyor", "Тайёр")) { previewFile = nil }
                        }
                    }
            }
        }
        .sheet(isPresented: $showPasswordRecovery) {
            IumrahPasswordRecoveryView()
        }
        .onChange(of: receiptPhoto) { _, item in
            guard let item else { return }
            Task { await uploadReceipt(item) }
        }
    }

    private var screenBody: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                hero
                checkoutContent(includeProgress: true)
            }
            .padding(.horizontal, IumrahDesign.pagePadding)
            .padding(.top, 12)
            .padding(.bottom, 48)
        }
        .background(Color.iumrahPageBackground)
        .toolbar(.hidden, for: .tabBar)
        .toolbar {
            ToolbarItem(placement: .principal) {
                VStack(spacing: 1) {
                    Text(tr("Pilgrim details & payment", "Данные и оплата", "Ma’lumotlar va to‘lov", "Маълумотлар ва тўлов"))
                        .font(.headline)
                        .lineLimit(1)
                    if let id = checkout?.iumrahID ?? session?.displayPilgrimID {
                        Text("iumrah ID \(normalizedID(id))")
                            .font(.caption2.monospaced().weight(.semibold))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
            }
        }
        .iumrahInternalNavigation()
    }

    private var embeddedStatusBody: some View {
        VStack(spacing: 18) {
            checkoutContent(includeProgress: false)
        }
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private func checkoutContent(includeProgress: Bool) -> some View {
        if isLoading {
            loadingCard
        } else if let checkout {
            if accountMatchesTrip {
                if includeProgress { progressCard(checkout) }
                travelersCard(checkout)

                if isAvailabilityChecking {
                    availabilityPaymentLockedCard
                } else if isPaymentPending {
                    paymentCard(checkout)
                } else if isPostPaymentStatus(checkout.status) {
                    if let session {
                        IumrahPaidReceiptCard(
                            session: session,
                            checkout: checkout,
                            receipt: checkout.receipts.first(where: { $0.reviewStatus.lowercased() == "approved" }) ?? checkout.receipts.first
                        )
                    }
                    if shouldShowDocuments { documentsCard(checkout) }
                } else {
                    paymentCard(checkout)
                    if shouldShowDocuments { documentsCard(checkout) }
                }
            } else if showExistingAccountLogin {
                loginCard(checkout)
            } else {
                activationCard(checkout)
            }
        }

        if let errorMessage {
            Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                .font(.footnote)
                .foregroundStyle(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 4)
        }
    }

    private var availabilityPaymentLockedCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                IumrahIconBadge(systemName: "lock.clock.fill", role: .payment, size: 44, symbolSize: 17, cornerRadius: 15)
                VStack(alignment: .leading, spacing: 3) {
                    Text(tr("Payment opens after confirmation", "Оплата откроется после подтверждения", "To‘lov tasdiqdan keyin ochiladi", "Тўлов тасдиқдан кейин очилади"))
                        .font(.subheadline.weight(.semibold))
                    Text(tr(
                        "Complete the pilgrim forms now. Invoice and payment details stay hidden until availability is confirmed.",
                        "Сейчас заполните анкеты паломников. Инвойс и реквизиты оплаты появятся только после подтверждения наличия.",
                        "Hozir ziyoratchilar anketalarini to‘ldiring. Invoice va to‘lov rekvizitlari faqat mavjudlik tasdiqlangach ko‘rinadi.",
                        "Ҳозир зиёратчилар анкеталарини тўлдиринг. Invoice ва тўлов реквизитлари фақат мавжудлик тасдиқлангач кўринади."
                    ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(16)
        .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.7)
        }
    }

    private func isPostPaymentStatus(_ raw: String) -> Bool {
        ["paid", "booking_confirmed", "documents_ready", "ready_to_travel", "in_trip", "completed"].contains(raw.lowercased())
    }


    private var hero: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 7) {
                    Text(isAvailabilityChecking
                         ? tr("We are checking availability", "Проверяем наличие", "Mavjudlik tekshirilmoqda", "Мавжудлик текширилмоқда")
                         : tr("Continue your booking", "Продолжите оформление", "Bronni davom ettiring", "Бронни давом эттиринг"))
                        .font(.system(size: 29, weight: .bold, design: .rounded))
                        .tracking(-0.5)
                    Text(isAvailabilityChecking
                         ? tr(
                            "You can safely close the app — we will update the status automatically. Fill in pilgrim and passport details now to move straight to payment after confirmation.",
                            "Вы можете спокойно закрыть приложение — статус обновится автоматически. Заранее заполните данные паломников и паспортов, чтобы после подтверждения сразу перейти к оплате.",
                            "Ilovani bemalol yopishingiz mumkin — holat avtomatik yangilanadi. Tasdiqdan keyin darhol to‘lovga o‘tish uchun ziyoratchilar va pasport ma’lumotlarini oldindan kiriting.",
                            "Иловани бемалол ёпишингиз мумкин — ҳолат автоматик янгиланади. Тасдиқдан кейин дарҳол тўловга ўтиш учун зиёратчилар ва паспорт маълумотларини олдиндан киритинг."
                         )
                         : tr(
                            "Create your iumrah ID password, complete every pilgrim form and attach the payment receipt.",
                            "Создайте пароль для iumrah ID, заполните анкеты всех паломников и прикрепите чек оплаты.",
                            "iumrah ID uchun parol yarating, barcha ziyoratchilar anketasini to‘ldiring va to‘lov chekini biriktiring.",
                            "iumrah ID учун парол яратинг, барча зиёратчилар анкетасини тўлдиринг ва тўлов чекини бириктиринг."
                         ))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 12)
                IumrahIconBadge(
                    systemName: "person.text.rectangle.fill",
                    role: .profile,
                    size: 50,
                    symbolSize: 21,
                    cornerRadius: 17
                )
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahCard()
    }

    private var loadingCard: some View {
        HStack(spacing: 13) {
            ProgressView()
            Text(tr("Loading secure checkout…", "Загружаем защищённое оформление…", "Himoyalangan sahifa yuklanmoqda…", "Ҳимояланган саҳифа юкланмоқда…"))
                .font(.subheadline.weight(.medium))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahCard()
    }

    private func activationCard(_ value: IumrahCheckoutResponse) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            stageHeader(
                number: "01",
                icon: "person.badge.key.fill",
                title: tr("Activate your iumrah account", "Активируйте аккаунт iumrah", "iumrah akkauntingizni faollashtiring", "iumrah аккаунтингизни фаоллаштиринг")
            )

            Label("iumrah Security", systemImage: "checkmark.shield.fill")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)

            Text(tr(
                "Create a password and keep it safe. You will use it to sign in to your iumrah account from another device or on the iumrah website.",
                "Придумайте пароль и сохраните его надёжно. Он будет использоваться для входа в Ваш аккаунт iumrah с другого устройства или на сайте iumrah.",
                "Parol yarating va uni xavfsiz saqlang. U boshqa qurilmadan yoki iumrah saytida akkauntingizga kirish uchun ishlatiladi.",
                "Парол яратинг ва уни хавфсиз сақланг. У бошқа қурилмадан ёки iumrah сайтида аккаунтингизга кириш учун ишлатилади."
            ))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Picker("", selection: $activationMethod) {
                Text("iumrah ID").tag(IumrahActivationMethod.iumrahID)
                Text("Email").tag(IumrahActivationMethod.email)
                Text("SMS").tag(IumrahActivationMethod.sms)
            }
            .pickerStyle(.segmented)
            .onChange(of: activationMethod) { _, _ in
                errorMessage = nil
                activationEmailChallengeID = ""
                activationEmailCode = ""
                activationSMSChallengeID = ""
                activationSMSCode = ""
            }

            if activationMethod == .iumrahID {
                VStack(alignment: .leading, spacing: 7) {
                    Text("iumrah ID")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(normalizedID(value.iumrahID))
                        .font(.system(size: 36, weight: .bold, design: .monospaced))
                        .tracking(3)
                        .textSelection(.enabled)
                    Text(tr(
                        "Your eight-digit iumrah ID is permanent and stays with you for future trips.",
                        "Ваш восьмизначный iumrah ID постоянный и сохраняется для будущих поездок.",
                        "Sakkiz xonali iumrah ID doimiy va keyingi safarlarda ham saqlanadi.",
                        "Саккиз хонали iumrah ID доимий ва кейинги сафарларда ҳам сақланади."
                    ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            } else if activationMethod == .email {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 11) {
                        Image(systemName: "envelope.fill")
                            .foregroundStyle(.secondary)
                            .frame(width: 22)
                        TextField("name@example.com", text: $activationEmail)
                            .keyboardType(.emailAddress)
                            .textContentType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .disabled(!activationEmailChallengeID.isEmpty)
                    }
                    .padding(.horizontal, 14)
                    .frame(height: 54)
                    .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

                    if !activationEmailChallengeID.isEmpty {
                        HStack(spacing: 11) {
                            Image(systemName: "number.square.fill")
                                .foregroundStyle(.secondary)
                                .frame(width: 22)
                            TextField(tr("6-digit code", "Код из 6 цифр", "6 xonali kod", "6 хонали код"), text: $activationEmailCode)
                                .keyboardType(.numberPad)
                                .textContentType(.oneTimeCode)
                                .font(.body.monospaced())
                                .onChange(of: activationEmailCode) { _, raw in
                                    let digits = String(raw.filter(\.isNumber).prefix(6))
                                    if digits != raw { activationEmailCode = digits }
                                }
                        }
                        .padding(.horizontal, 14)
                        .frame(height: 54)
                        .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

                        Text(tr(
                            "We sent a verification code to your email. It expires in 10 minutes.",
                            "Мы отправили код подтверждения на почту. Он действует 10 минут.",
                            "Tasdiqlash kodi emailingizga yuborildi. U 10 daqiqa amal qiladi.",
                            "Тасдиқлаш коди emailingizга юборилди. У 10 дақиқа амал қилади."
                        ))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }
                }
            } else {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 11) {
                        Image(systemName: "phone.fill")
                            .foregroundStyle(.secondary)
                            .frame(width: 22)
                        TextField("+998 90 123 45 67", text: $activationPhone)
                            .keyboardType(.phonePad)
                            .textContentType(.telephoneNumber)
                            .disabled(!activationSMSChallengeID.isEmpty)
                            .onChange(of: activationPhone) { _, raw in
                                let formatted = activationPhoneInput(raw)
                                if formatted != raw { activationPhone = formatted }
                            }
                    }
                    .padding(.horizontal, 14)
                    .frame(height: 54)
                    .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

                    if activationSMSCovered {
                        if activationSMSChallengeID.isEmpty {
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: "message.badge.fill")
                                    .foregroundStyle(Color.blue)
                                Text(tr(
                                    "We will send a one-time confirmation code to this Uzbekistan number through DevSMS.",
                                    "Мы отправим одноразовый код подтверждения на этот номер Узбекистана через DevSMS.",
                                    "Ushbu O‘zbekiston raqamiga DevSMS orqali bir martalik tasdiqlash kodi yuboramiz.",
                                    "Ушбу Ўзбекистон рақамига DevSMS орқали бир марталик тасдиқлаш коди юборамиз."
                                ))
                                .font(.caption.weight(.medium))
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(13)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.blue.opacity(0.08), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            .overlay { RoundedRectangle(cornerRadius: 17, style: .continuous).strokeBorder(Color.blue.opacity(0.18), lineWidth: 0.8) }
                        } else {
                            HStack(spacing: 11) {
                                Image(systemName: "number.square.fill")
                                    .foregroundStyle(.secondary)
                                    .frame(width: 22)
                                TextField(tr("6-digit SMS code", "Код SMS из 6 цифр", "6 xonali SMS kodi", "6 хонали SMS коди"), text: $activationSMSCode)
                                    .keyboardType(.numberPad)
                                    .textContentType(.oneTimeCode)
                                    .font(.body.monospaced())
                                    .onChange(of: activationSMSCode) { _, raw in
                                        let digits = String(raw.filter(\.isNumber).prefix(6))
                                        if digits != raw { activationSMSCode = digits }
                                    }
                            }
                            .padding(.horizontal, 14)
                            .frame(height: 54)
                            .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

                            Text(tr(
                                "The code was sent by DevSMS and is valid for 10 minutes.",
                                "Код отправлен через DevSMS и действует 10 минут.",
                                "Kod DevSMS orqali yuborildi va 10 daqiqa amal qiladi.",
                                "Код DevSMS орқали юборилди ва 10 дақиқа амал қилади."
                            ))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        }
                    } else {
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: "exclamationmark.bubble.fill")
                                .foregroundStyle(Color.orange)
                            Text(tr(
                                "SMS is temporarily unavailable for this country. Please continue by email or use your Google or Apple account. SMS currently supports only Uzbekistan numbers beginning with +998.",
                                "SMS для этой страны временно недоступны. Продолжите по электронной почте или воспользуйтесь аккаунтом Google или Apple. Сейчас SMS поддерживает только номера Узбекистана, начинающиеся с +998.",
                                "Bu davlat uchun SMS vaqtincha mavjud emas. Email orqali davom eting yoki Google/Apple akkauntingizdan foydalaning. Hozir SMS faqat +998 bilan boshlanuvchi O‘zbekiston raqamlarini qo‘llaydi.",
                                "Бу давлат учун SMS вақтинча мавжуд эмас. Email орқали давом этинг ёки Google/Apple аккаунтингиздан фойдаланинг. Ҳозир SMS фақат +998 билан бошланувчи Ўзбекистон рақамларини қўллайди."
                            ))
                            .font(.caption.weight(.medium))
                            .foregroundStyle(Color.orange)
                            .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(13)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                        .overlay { RoundedRectangle(cornerRadius: 17, style: .continuous).strokeBorder(Color.orange.opacity(0.18), lineWidth: 0.8) }
                    }
                }
            }

            passwordField(
                tr("Create password", "Создайте пароль", "Parol yarating", "Парол яратинг"),
                text: $password,
                isVisible: $isPasswordVisible,
                newPassword: true
            )
            passwordField(
                tr("Confirm password", "Подтвердите пароль", "Parolni tasdiqlang", "Паролни тасдиқланг"),
                text: $passwordConfirm,
                isVisible: $isPasswordConfirmVisible,
                newPassword: true
            )

            VStack(alignment: .leading, spacing: 7) {
                activationRequirement(
                    tr("At least 8 characters", "Минимум 8 символов", "Kamida 8 belgi", "Камида 8 белги"),
                    ready: password.count >= 8
                )
                activationRequirement(
                    tr("Passwords match", "Пароли совпадают", "Parollar mos", "Пароллар мос"),
                    ready: !passwordConfirm.isEmpty && password == passwordConfirm
                )
            }

            Button {
                Task {
                    switch activationMethod {
                    case .iumrahID:
                        await activateAccount(value)
                    case .email:
                        if activationEmailChallengeID.isEmpty { await startEmailActivation(value) }
                        else { await confirmEmailActivation(value) }
                    case .sms:
                        if activationSMSChallengeID.isEmpty { await startSMSActivation(value) }
                        else { await confirmSMSActivation(value) }
                    }
                }
            } label: {
                HStack {
                    if isSubmittingAccount { ProgressView().tint(.white) }
                    Text(activationPrimaryTitle)
                    Spacer()
                    Image(systemName: activationMethod == .sms ? "message.badge" : (activationMethod == .email && activationEmailChallengeID.isEmpty ? "envelope.badge.fill" : "arrow.right"))
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!activationPrimaryReady || isSubmittingAccount || !isTravelerEditingAllowed)

            if activationMethod == .email && !activationEmailChallengeID.isEmpty {
                HStack {
                    Button {
                        activationEmailChallengeID = ""
                        activationEmailCode = ""
                        errorMessage = nil
                    } label: {
                        Text(tr("Change email", "Изменить почту", "Emailni o‘zgartirish", "Emailни ўзгартириш"))
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.plain)

                    Spacer()

                    Button {
                        Task { await startEmailActivation(value) }
                    } label: {
                        Text(tr("Send again", "Отправить ещё раз", "Qayta yuborish", "Қайта юбориш"))
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.plain)
                    .disabled(isSubmittingAccount)
                }
            }

            if activationMethod == .sms && !activationSMSChallengeID.isEmpty {
                HStack {
                    Button {
                        activationSMSChallengeID = ""
                        activationSMSCode = ""
                        errorMessage = nil
                    } label: {
                        Text(tr("Change number", "Изменить номер", "Raqamni o‘zgartirish", "Рақамни ўзгартириш"))
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.plain)

                    Spacer()

                    Button {
                        Task { await startSMSActivation(value) }
                    } label: {
                        Text(tr("Send again", "Отправить ещё раз", "Qayta yuborish", "Қайта юбориш"))
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.plain)
                    .disabled(isSubmittingAccount)
                }
            }

            HStack(spacing: 10) {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 1)
                Text(tr("or", "или", "yoki", "ёки"))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 1)
            }

            IumrahLocalizedAppleAuthButton(
                title: tr("Continue with Apple", "Продолжить с Apple", "Apple bilan davom etish", "Apple билан давом этиш"),
                isDisabled: isSubmittingAccount || isGoogleSigningIn || !isTravelerEditingAllowed,
                onRequest: prepareActivationAppleSignIn,
                onCompletion: completeActivationAppleSignIn
            )

            IumrahGoogleAuthButton(
                title: tr("Continue with Google", "Продолжить с Google", "Google bilan davom etish", "Google билан давом этиш"),
                isDisabled: isSubmittingAccount || isAppleSigningIn || isGoogleSigningIn || !isTravelerEditingAllowed
            ) {
                startActivationGoogleSignIn()
            }

            Button {
                errorMessage = nil
                if existingLoginID.isEmpty { existingLoginID = normalizedID(value.iumrahID) }
                showExistingAccountLogin = true
            } label: {
                Text(value.accountActive
                    ? tr("Already created a password? Sign in", "Уже создавали пароль? Войти", "Avval parol yaratganmisiz? Kiring", "Аввал парол яратганмисиз? Киринг")
                    : tr("I already have an iumrah account", "У меня уже есть аккаунт iumrah", "Menda iumrah akkaunti bor", "Менда iumrah аккаунти бор"))
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
        }
        .iumrahCard()
    }

    private func loginCard(_ value: IumrahCheckoutResponse) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            stageHeader(number: "01", icon: "person.crop.circle.badge.checkmark", title: tr("Use an existing iumrah account", "Войдите в существующий аккаунт", "Mavjud iumrah akkauntiga kiring", "Мавжуд iumrah аккаунтига киринг"))
            Text(tr(
                "Sign in with your existing account. This booking will then be securely linked to that same permanent iumrah ID.",
                "Войдите в свой существующий аккаунт. После входа эта бронь будет безопасно привязана к тому же постоянному iumrah ID.",
                "Mavjud akkauntingizga kiring. Shundan keyin bu bron aynan shu doimiy iumrah ID ga xavfsiz ulanadi.",
                "Мавжуд аккаунтингизга киринг. Шундан кейин бу брон айнан шу доимий iumrah ID га хавфсиз уланади."
            ))
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)

            Picker("", selection: $existingLoginMethod) {
                Text("iumrah ID").tag(IumrahCheckoutLoginMethod.iumrahID)
                Text("Email").tag(IumrahCheckoutLoginMethod.email)
                Text("SMS").tag(IumrahCheckoutLoginMethod.sms)
            }
            .pickerStyle(.segmented)
            .onChange(of: existingLoginMethod) { _, _ in errorMessage = nil }

            switch existingLoginMethod {
            case .iumrahID:
                HStack(spacing: 11) {
                    Image(systemName: "number").foregroundStyle(.secondary).frame(width: 22)
                    TextField("00000016", text: $existingLoginID)
                        .keyboardType(.numberPad)
                        .textContentType(.username)
                        .font(.body.monospaced())
                        .onChange(of: existingLoginID) { _, raw in
                            let digits = String(raw.filter(\.isNumber).prefix(8))
                            if digits != raw { existingLoginID = digits }
                        }
                }
                .padding(.horizontal, 14)
                .frame(height: 54)
                .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

            case .email:
                HStack(spacing: 11) {
                    Image(systemName: "envelope.fill").foregroundStyle(.secondary).frame(width: 22)
                    TextField("name@example.com", text: $existingLoginEmail)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 14)
                .frame(height: 54)
                .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

            case .sms:
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 11) {
                        Image(systemName: "phone.fill").foregroundStyle(.secondary).frame(width: 22)
                        TextField("+998 90 123 45 67", text: $existingLoginPhone)
                            .keyboardType(.phonePad)
                            .textContentType(.telephoneNumber)
                            .onChange(of: existingLoginPhone) { _, raw in
                                let formatted = activationPhoneInput(raw)
                                if formatted != raw { existingLoginPhone = formatted }
                            }
                    }
                    .padding(.horizontal, 14)
                    .frame(height: 54)
                    .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)

                    if !activationPhoneInput(existingLoginPhone).hasPrefix("+998") {
                        HStack(alignment: .top, spacing: 9) {
                            Image(systemName: "exclamationmark.bubble.fill").foregroundStyle(.orange)
                            Text(tr(
                                "SMS sign-in is temporarily unavailable for this country. Use Email, iumrah ID, Google or Apple.",
                                "Вход по SMS для этой страны временно недоступен. Используйте Email, iumrah ID, Google или Apple.",
                                "Bu davlat uchun SMS orqali kirish vaqtincha mavjud emas. Email, iumrah ID, Google yoki Apple’dan foydalaning.",
                                "Бу давлат учун SMS орқали кириш вақтинча мавжуд эмас. Email, iumrah ID, Google ёки Apple’дан фойдаланинг."
                            ))
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.orange)
                        }
                        .padding(12)
                        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
            }

            passwordField(
                tr("Password", "Пароль", "Parol", "Парол"),
                text: $loginPassword,
                isVisible: $isLoginPasswordVisible,
                newPassword: false
            )

            HStack {
                Button {
                    errorMessage = nil
                    showExistingAccountLogin = false
                } label: {
                    Text(tr("Create an account for this booking", "Создать аккаунт для этой брони", "Bu bron uchun akkaunt yaratish", "Бу брон учун аккаунт яратиш"))
                        .font(.caption.weight(.semibold))
                }
                .buttonStyle(.plain)
                Spacer()
                Button { showPasswordRecovery = true } label: {
                    Text(tr("Forgot password?", "Забыли пароль?", "Parolni unutdingizmi?", "Паролни унутдингизми?"))
                        .font(.caption.weight(.semibold))
                }
                .buttonStyle(.plain)
            }

            Button {
                Task { await login(value) }
            } label: {
                HStack {
                    if isSubmittingAccount { ProgressView().tint(.white) }
                    Text(tr("Sign in and link booking", "Войти и привязать бронь", "Kirish va bronni ulash", "Кириш ва бронни улаш"))
                    Spacer(); Image(systemName: "arrow.right")
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!existingLoginReady || isSubmittingAccount || isAppleSigningIn || isGoogleSigningIn)

            HStack(spacing: 10) {
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 1)
                Text(tr("or", "или", "yoki", "ёки")).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Rectangle().fill(Color.primary.opacity(0.08)).frame(height: 1)
            }

            IumrahLocalizedAppleAuthButton(
                title: tr("Sign in with Apple", "Войти с Apple", "Apple orqali kirish", "Apple орқали кириш"),
                isDisabled: isSubmittingAccount || isGoogleSigningIn || isAppleSigningIn,
                onRequest: prepareActivationAppleSignIn,
                onCompletion: completeActivationAppleSignIn
            )

            IumrahGoogleAuthButton(
                title: tr("Sign in with Google", "Войти с Google", "Google orqali kirish", "Google орқали кириш"),
                isDisabled: isSubmittingAccount || isAppleSigningIn || isGoogleSigningIn
            ) {
                startActivationGoogleSignIn()
            }
        }
        .iumrahCard()
    }

    private var existingLoginReady: Bool {
        guard loginPassword.count >= 8 else { return false }
        switch existingLoginMethod {
        case .iumrahID:
            return [6, 8].contains(existingLoginID.filter(\.isNumber).count)
        case .email:
            let email = existingLoginEmail.trimmingCharacters(in: .whitespacesAndNewlines)
            return email.contains("@") && email.contains(".")
        case .sms:
            let phone = activationPhoneInput(existingLoginPhone)
            return phone.hasPrefix("+998") && phone.count == 13
        }
    }

    private var activationPrimaryTitle: String {
        switch activationMethod {
        case .iumrahID:
            return tr("Activate ID and continue", "Активировать ID и продолжить", "ID ni faollashtirish va davom etish", "ID ни фаоллаштириш ва давом этиш")
        case .email:
            if activationEmailChallengeID.isEmpty {
                return tr("Send verification code", "Отправить код", "Tasdiqlash kodini yuborish", "Тасдиқлаш кодини юбориш")
            }
            return tr("Confirm email and continue", "Подтвердить почту и продолжить", "Emailni tasdiqlash va davom etish", "Emailни тасдиқлаш ва давом этиш")
        case .sms:
            if activationSMSChallengeID.isEmpty {
                return tr("Send SMS code", "Отправить SMS-код", "SMS kodini yuborish", "SMS кодини юбориш")
            }
            return tr("Confirm SMS and continue", "Подтвердить SMS и продолжить", "SMSni tasdiqlash va davom etish", "SMSни тасдиқлаш ва давом этиш")
        }
    }

    private var activationPrimaryReady: Bool {
        guard password.count >= 8, password == passwordConfirm else { return false }
        switch activationMethod {
        case .iumrahID:
            return true
        case .email:
            let email = activationEmail.trimmingCharacters(in: .whitespacesAndNewlines)
            guard email.contains("@"), email.contains(".") else { return false }
            if activationEmailChallengeID.isEmpty { return true }
            return activationEmailCode.count == 6
        case .sms:
            guard activationSMSCovered, activationPhoneInput(activationPhone).count == 13 else { return false }
            if activationSMSChallengeID.isEmpty { return true }
            return activationSMSCode.count == 6
        }
    }

    private var activationSMSCovered: Bool {
        activationPhoneInput(activationPhone).hasPrefix("+998")
    }

    private func activationPhoneInput(_ raw: String) -> String {
        let digits = String(raw.filter(\.isNumber).prefix(15))
        return digits.isEmpty ? "" : "+" + digits
    }

    private func activationRequirement(_ title: String, ready: Bool) -> some View {
        Label(title, systemImage: ready ? "checkmark.circle.fill" : "circle")
            .font(.caption.weight(.semibold))
            .foregroundStyle(ready ? Color.iumrahCareDark : Color.secondary)
    }

    private func progressCard(_ value: IumrahCheckoutResponse) -> some View {
        let complete = value.travelers.filter(\.completed).count
        return VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(tr("Booking readiness", "Готовность оформления", "Rasmiylashtirish holati", "Расмийлаштириш ҳолати"))
                        .font(.headline)
                    Text(L10n.status(value.status, settings.language))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Text("\(complete)/\(value.travelers.count)")
                    .font(.headline.monospacedDigit())
            }
            ProgressView(value: Double(complete + (value.receipts.isEmpty ? 0 : 1)), total: Double(max(1, value.travelers.count + 1)))
                .tint(Color.iumrahCareDark)
            HStack(spacing: 8) {
                readinessChip(tr("Account", "Аккаунт", "Akkaunt", "Аккаунт"), ready: accountMatchesTrip)
                readinessChip(tr("Pilgrims", "Анкеты", "Anketalar", "Анкеталар"), ready: complete == value.travelers.count)
                readinessChip(tr("Receipt", "Чек", "Chek", "Чек"), ready: !value.receipts.isEmpty)
            }
        }
        .iumrahCard()
    }

    private func travelersCard(_ value: IumrahCheckoutResponse) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            stageHeader(number: "02", icon: "person.2.fill", title: tr("Pilgrim details", "Данные паломников", "Ziyoratchilar ma’lumotlari", "Зиёратчилар маълумотлари"))
            Text(tr(
                isTravelerEditingAllowed ? "One secure form for every traveler in this booking." : "Traveler details stay attached to this booking for the rest of the journey.",
                isTravelerEditingAllowed ? "Для каждого участника поездки — отдельная защищённая анкета." : "Данные каждого паломника закреплены за этим бронированием до конца поездки.",
                isTravelerEditingAllowed ? "Har bir sayohatchi uchun alohida himoyalangan anketa." : "Har bir ziyoratchining ma’lumotlari safar oxirigacha shu bronga biriktiriladi.",
                isTravelerEditingAllowed ? "Ҳар бир саёҳатчи учун алоҳида ҳимояланган анкета." : "Ҳар бир зиёратчининг маълумотлари сафар охиригача шу бронга бириктирилади."
            ))
            .font(.subheadline)
            .foregroundStyle(.secondary)

            ForEach(value.travelers) { traveler in
                VStack(alignment: .leading, spacing: 12) {
                    Button {
                        if isTravelerEditingAllowed {
                            travelerEditor = traveler
                        }
                    } label: {
                        HStack(spacing: 13) {
                            IumrahIconBadge(
                                systemName: traveler.completed ? "checkmark" : travelerIcon(traveler.travelerType),
                                role: traveler.completed ? .success : .profile,
                                size: 46,
                                symbolSize: 17,
                                cornerRadius: 15
                            )

                            VStack(alignment: .leading, spacing: 3) {
                                Text(travelerName(traveler))
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                Text(relationshipTitle(traveler.relationship, position: traveler.position))
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(traveler.completed ? tr("Completed", "Анкета готова", "Anketa tayyor", "Анкета тайёр") : tr("Passport and travel details required", "Нужны данные и паспорт", "Ma’lumot va pasport kerak", "Маълумот ва паспорт керак"))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if isTravelerEditingAllowed {
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.tertiary)
                            } else {
                                Image(systemName: "lock.fill")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.tertiary)
                            }
                        }
                    }
                    .buttonStyle(.plain)

                    if !isTravelerEditingAllowed {
                        Divider()
                        VStack(spacing: 9) {
                            travelerDetailFact(tr("Date of birth", "Дата рождения", "Tug‘ilgan sana", "Туғилган сана"), traveler.dateOfBirth)
                            travelerDetailFact(tr("Nationality", "Гражданство", "Fuqarolik", "Фуқаролик"), traveler.nationality)
                            travelerDetailFact(tr("Passport", "Паспорт", "Pasport", "Паспорт"), traveler.passportNumber)
                            travelerDetailFact(tr("Passport expiry", "Срок паспорта", "Pasport muddati", "Паспорт муддати"), traveler.passportExpiryDate)
                            travelerDetailFact(tr("Phone", "Телефон", "Telefon", "Телефон"), traveler.phone)
                            travelerDetailFact("Email", traveler.email)
                        }
                    }
                }
                .padding(13)
                .iumrahGlass(in: RoundedRectangle(cornerRadius: 20, style: .continuous), interactive: true)
            }
        }
        .iumrahCard()
    }

    @ViewBuilder
    private func travelerDetailFact(_ title: String, _ rawValue: String) -> some View {
        let value = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        if !value.isEmpty {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer(minLength: 10)
                Text(value)
                    .font(.caption.weight(.semibold))
                    .multilineTextAlignment(.trailing)
                    .textSelection(.enabled)
            }
        }
    }


    private func paymentCard(_ value: IumrahCheckoutResponse) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            stageHeader(number: "03", icon: "creditcard.fill", title: tr("Payment", "Оплата", "To‘lov", "Тўлов"))

            if isAvailabilityChecking {
                VStack(alignment: .leading, spacing: 12) {
                    Label(tr("Payment will open after availability is confirmed", "Оплата откроется после подтверждения наличия", "To‘lov mavjudlik tasdiqlangach ochiladi", "Тўлов мавжудлик тасдиқлангач очилади"), systemImage: "lock.clock.fill")
                        .font(.headline)
                    Text(tr(
                        "Nothing needs to be paid now. Complete the pilgrim forms above — the entered details will remain saved.",
                        "Сейчас ничего оплачивать не нужно. Заполните анкеты паломников выше — введённые данные сохранятся.",
                        "Hozir to‘lov qilish shart emas. Yuqoridagi ziyoratchi anketalarini to‘ldiring — ma’lumotlar saqlanadi.",
                        "Ҳозир тўлов қилиш шарт эмас. Юқоридаги зиёратчи анкеталарини тўлдиринг — маълумотлар сақланади."
                    ))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                }
                .padding(16)
                .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            } else {
                IumrahManualPaymentNotice()
                IumrahRefundPolicyCard(component: .package, compact: true)
                if let session {
                    IumrahInvoiceShareCard(session: session, compact: true)
                }

                friendsBenefitCard

                if paymentOptions(value).isEmpty {
                    Label(tr("Payment details will appear after iumrah Business adds them.", "Реквизиты появятся после того, как iumrah Business их добавит.", "To‘lov rekvizitlari iumrah Business qo‘shgandan keyin paydo bo‘ladi.", "Тўлов реквизитлари iumrah Business қўшгандан кейин пайдо бўлади."), systemImage: "clock")
                        .font(.subheadline).foregroundStyle(.secondary)
                } else {
                    HStack(spacing: 8) {
                        ForEach(paymentOptions(value), id: \.self) { method in
                            Button {
                                paymentMethod = method
                                if method == "payme" { Task { await loadPaymeQR(value) } }
                            } label: {
                                Text(paymentTitle(method))
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(paymentMethod == method ? Color.iumrahPrimaryButtonText : Color.primary)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 42)
                                    .background(paymentMethod == method ? Color.iumrahPrimaryButtonBackground : Color.iumrahRaisedBackground, in: Capsule())
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    paymentDetails(value)

                    if !value.payment.instructions.isEmpty {
                        Text(value.payment.instructions)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }

                    Divider()

                    if let receipt = value.receipts.first {
                        paymentReceiptSummary(receipt, checkout: value)
                    } else if isPaymentPending {
                        PhotosPicker(selection: $receiptPhoto, matching: .images) {
                            HStack {
                                if isUploadingReceipt { ProgressView().tint(.white) }
                                Image(systemName: "paperclip")
                                Text(tr("Attach payment receipt", "Прикрепить чек оплаты", "To‘lov chekini biriktirish", "Тўлов чекини бириктириш"))
                                Spacer()
                                Image(systemName: "arrow.up")
                            }
                        }
                        .buttonStyle(IumrahPrimaryButtonStyle())
                        .disabled(isUploadingReceipt || paymentOptions(value).isEmpty)
                    }
                }
            }
        }
        .iumrahCard()
    }

    private func paymentReceiptSummary(_ receipt: IumrahPaymentReceipt, checkout: IumrahCheckoutResponse) -> some View {
        let number = receipt.paymentMethod == "humo" ? checkout.payment.humoCardNumber : checkout.payment.visaCardNumber
        let holder = receipt.paymentMethod == "humo" ? checkout.payment.humoHolder : checkout.payment.visaHolder
        return VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                IumrahIconBadge(systemName: receipt.reviewStatus == "approved" ? "checkmark.seal.fill" : "clock.badge.checkmark.fill", role: receipt.reviewStatus == "approved" ? .success : .payment, size: 48, symbolSize: 19, cornerRadius: 16)
                VStack(alignment: .leading, spacing: 3) {
                    Text(tr("Payment receipt", "Чек об оплате", "To‘lov cheki", "Тўлов чеки"))
                        .font(.headline)
                    Text(receiptStatus(receipt.reviewStatus))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(receipt.reviewStatus == "approved" ? Color.green : Color.secondary)
                }
                Spacer()
            }

            VStack(spacing: 9) {
                receiptFact(tr("Booking", "Бронирование", "Bron", "Брон"), session?.displayBookingNumber ?? "—")
                receiptFact(tr("Payment method", "Способ оплаты", "To‘lov usuli", "Тўлов усули"), paymentTitle(receipt.paymentMethod))
                if !number.isEmpty { receiptFact(tr("Card number", "Номер карты", "Karta raqami", "Карта рақами"), groupedCard(number)) }
                if !holder.isEmpty { receiptFact(tr("Recipient", "Получатель", "Qabul qiluvchi", "Қабул қилувчи"), holder) }
                receiptFact(tr("Platform", "Платформа", "Platforma", "Платформа"), "Iumrah")
                receiptFact(tr("Responsible team", "Ответственное лицо", "Mas’ul jamoa", "Масъул жамоа"), "Iumrah Booking Operations")
                receiptFact(tr("Sent", "Отправлен", "Yuborildi", "Юборилди"), checkoutDate(receipt.createdAt))
            }

            Label(tr(
                "Iumrah is responsible for issuing and delivering the airline ticket after payment confirmation. Refund and change conditions follow the airline fare rules.",
                "Iumrah несёт ответственность за оформление и передачу авиабилета после подтверждения оплаты. Условия возврата и изменений зависят от тарифа авиакомпании.",
                "To‘lov tasdiqlangach, aviachiptani rasmiylashtirish va yetkazish uchun Iumrah javob beradi. Qaytarish va o‘zgartirish shartlari aviakompaniya tarifiga bog‘liq.",
                "Тўлов тасдиқлангач, авиачиптани расмийлаштириш ва етказиш учун Iumrah жавоб беради. Қайтариш ва ўзгартириш шартлари авиакомпания тарифига боғлиқ."
            ), systemImage: "shield.checkered")
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)

            if let url = receipt.url, !url.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Button { Task { await openReceipt(receipt) } } label: {
                    HStack {
                        if isLoadingDocument { ProgressView().tint(.white) } else { Image(systemName: "doc.text.image.fill") }
                        Text(tr("Open payment receipt", "Открыть чек оплаты", "To‘lov chekini ochish", "Тўлов чекини очиш"))
                        Spacer()
                        Image(systemName: "arrow.up.right")
                    }
                }
                .buttonStyle(IumrahPrimaryButtonStyle())
                .disabled(isLoadingDocument)
            }

            NavigationLink {
                IumrahPolicyDetailView(kind: .refund)
            } label: {
                Label(tr("Refund policy", "Политика возврата", "Qaytarish siyosati", "Қайтариш сиёсати"), systemImage: "arrow.uturn.backward.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 14)
                    .frame(height: 50)
                    .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(16)
        .background(Color.iumrahRaisedBackground.opacity(0.72), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private func receiptFact(_ title: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Spacer(minLength: 10)
            Text(value).font(.caption.weight(.semibold)).multilineTextAlignment(.trailing).textSelection(.enabled)
        }
    }

    @ViewBuilder
    private var friendsBenefitCard: some View {
        if account.isAuthenticated {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 12) {
                    IumrahIconBadge(
                        systemName: "gift.fill",
                        role: .gift,
                        size: 42,
                        symbolSize: 17,
                        cornerRadius: 15
                    )

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Iumrah Gift Cards")
                            .font(.headline)
                        Text(tr("Gift Card & Iumrah Balance", "Gift Card и Iumrah Balance", "Gift Card va Iumrah Balance", "Gift Card ва Iumrah Balance"))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "lock.fill")
                        .foregroundStyle(.secondary)
                }

                HStack(alignment: .top, spacing: 11) {
                    Image(systemName: "clock.badge.exclamationmark.fill")
                        .foregroundStyle(.orange)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(tr("Gift Cards are not available yet", "Gift Card ещё недоступна", "Gift Card hali mavjud emas", "Gift Card ҳали мавжуд эмас"))
                            .font(.subheadline.weight(.semibold))
                        Text(tr(
                            "The section is already visible in the booking, but applying Gift Cards and Iumrah Balance is temporarily disabled. We will enable it after the payment flow is ready.",
                            "Раздел уже виден в бронировании, но применение Gift Card и Iumrah Balance временно отключено. Мы включим его после готовности платёжного сценария.",
                            "Bo‘lim bron ichida ko‘rinadi, ammo Gift Card va Iumrah Balance qo‘llash vaqtincha o‘chirilgan. To‘lov jarayoni tayyor bo‘lgach yoqiladi.",
                            "Бўлим брон ичида кўринади, аммо Gift Card ва Iumrah Balance қўллаш вақтинча ўчирилган. Тўлов жараёни тайёр бўлгач ёқилади."
                        ))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(13)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 17, style: .continuous)
                        .strokeBorder(Color.orange.opacity(0.18), lineWidth: 0.8)
                }
            }
            .padding(14)
            .background(Color.iumrahRaisedBackground.opacity(0.45), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .accessibilityElement(children: .contain)
        }
    }

    private func friendsPricingSummary(_ summary: IumrahFriendsBookingSummary) -> some View {
        VStack(spacing: 8) {
            HStack {
                Text(tr("Gift Card limit", "Лимит Gift Card", "Gift Card limiti", "Gift Card лимити"))
                    .foregroundStyle(.secondary)
                Spacer()
                Text(friendMoney(summary.maxDiscountUsd)).fontWeight(.semibold)
            }
            if summary.totalUsd > 0 {
                HStack {
                    Text(tr("Package", "Пакет", "Paket", "Пакет"))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(friendMoney(summary.totalUsd))
                }
            }
            if summary.totalDiscountUsd > 0 {
                HStack {
                    Text("Iumrah Gift Cards")
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("−\(friendMoney(summary.totalDiscountUsd))")
                        .fontWeight(.semibold)
                        .foregroundStyle(.green)
                }
            }
            if summary.totalUsd > 0 {
                Divider()
                HStack {
                    Text(tr("Amount to pay", "К оплате", "To‘lov summasi", "Тўлов суммаси"))
                        .fontWeight(.semibold)
                    Spacer()
                    Text(friendMoney(summary.payableUsd))
                        .font(.headline.monospacedDigit())
                }
            }
            HStack {
                Text(tr("Available Iumrah Balance", "Доступный Iumrah Balance", "Mavjud Iumrah Balance", "Мавжуд Iumrah Balance"))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(friendMoney(summary.availableCreditUsd))
                    .font(.caption.weight(.bold))
            }
        }
        .font(.subheadline)
    }

    private var normalizedGiftCode: String {
        giftCode.uppercased().filter { !$0.isWhitespace }
    }

    private var friendsMessageIsError: Bool {
        guard let value = friendsMessage?.lowercased() else { return false }
        return value.contains("не ") || value.contains("cannot") || value.contains("required") || value.contains("нельзя") || value.contains("xato") || value.contains("kerak") || value.contains("керак")
    }

    private func friendMoney(_ amount: Double) -> String {
        "$\(Int(amount.rounded()))"
    }

    @MainActor
    private func loadFriendsSummary() async {
        guard let session, account.isAuthenticated else {
            friendsSummary = nil
            return
        }
        do {
            let headers = account.authorizationHeaders(bookingToken: session.accessToken)
            friendsSummary = try await bookingService.friendsSummary(id: bookingID, headers: headers)
        } catch APIError.status(let code) where code == 404 {
            friendsSummary = nil
        } catch APIError.server(_, let message) where message == "FRIENDS_UNAVAILABLE" {
            friendsSummary = nil
        } catch {
            // Friends is supplemental to checkout. Do not block payment if the service is temporarily unavailable.
        }
    }

    @MainActor
    private func redeemFriendGift() async {
        guard let session else { return }
        isApplyingFriendBenefit = true
        friendsMessage = nil
        defer { isApplyingFriendBenefit = false }
        do {
            let headers = account.authorizationHeaders(bookingToken: session.accessToken)
            friendsSummary = try await bookingService.redeemFriendGift(
                id: bookingID,
                headers: headers,
                code: normalizedGiftCode
            )
            giftCode = ""
            friendsMessage = tr("$100 Gift Card applied.", "Gift Card на $100 применён.", "$100 Gift Card qo‘llandi.", "$100 Gift Card қўлланди.")
            IumrahHaptics.success()
        } catch APIError.server(_, let code) {
            friendsMessage = friendError(code)
            IumrahHaptics.error()
        } catch {
            friendsMessage = L10n.error(error, settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func applyFriendCredit(amountUsd: Int) async {
        guard let session else { return }
        isApplyingFriendBenefit = true
        friendsMessage = nil
        defer { isApplyingFriendBenefit = false }
        do {
            let headers = account.authorizationHeaders(bookingToken: session.accessToken)
            friendsSummary = try await bookingService.applyFriendCredit(
                id: bookingID,
                headers: headers,
                amountUsd: amountUsd
            )
            friendsMessage = tr("Iumrah Balance applied.", "Iumrah Balance применён.", "Iumrah Balance qo‘llandi.", "Iumrah Balance қўлланди.")
            IumrahHaptics.success()
        } catch APIError.server(_, let code) {
            friendsMessage = friendError(code)
            IumrahHaptics.error()
        } catch {
            friendsMessage = L10n.error(error, settings.language)
            IumrahHaptics.error()
        }
    }

    private func friendError(_ code: String) -> String {
        switch code.uppercased() {
        case "IDENTITY_CONFIRMATION_REQUIRED":
            return tr("Iumrah Security Confirmation is required.", "Сначала пройдите Iumrah Security Confirmation.", "Avval Iumrah Security Confirmation dan o‘ting.", "Аввал Iumrah Security Confirmation дан ўтинг.")
        case "FRIENDS_GIFT_INVALID":
            return tr("Check the Gift code.", "Проверьте код Gift-карты.", "Gift kodini tekshiring.", "Gift кодини текширинг.")
        case "FRIENDS_GIFT_NOT_AVAILABLE":
            return tr("This Gift is unavailable or already used.", "Эта Gift-карта недоступна или уже использована.", "Bu Gift mavjud emas yoki allaqachon ishlatilgan.", "Бу Gift мавжуд эмас ёки аллақачон ишлатилган.")
        case "FRIENDS_NEW_CUSTOMER_ONLY":
            return tr("This identity already has a previously paid iumrah trip or has used a first-booking Gift Card.", "У этой личности уже есть ранее оплаченная поездка iumrah или использованная Gift Card первого бронирования.", "Bu shaxsning avval to‘langan iumrah safari bor yoki birinchi bron Gift Card idan foydalangan.", "Бу шахснинг аввал тўланган iumrah сафари бор ёки биринчи брон Gift Card идан фойдаланган.")
        case "FRIENDS_DISCOUNT_LIMIT_REACHED":
            return tr("The Gift Card limit for this trip is already reached.", "Лимит Gift Card для этой поездки уже исчерпан.", "Bu safar uchun Gift Card limiti tugagan.", "Бу сафар учун Gift Card лимити тугаган.")
        case "FRIENDS_SELF_REFERRAL":
            return tr("You cannot use your own Gift.", "Нельзя применить собственную Gift-карту.", "O‘z Gift kartangizni ishlata olmaysiz.", "Ўз Gift картангизни ишлата олмайсиз.")
        case "FRIENDS_CREDIT_UNAVAILABLE":
            return tr("There is not enough available Iumrah Balance for this booking.", "Недостаточно доступного Iumrah Balance для этого бронирования.", "Bu bron uchun Iumrah Balance yetarli emas.", "Бу брон учун Iumrah Balance етарли эмас.")
        default:
            return L10n.error(APIError.server(409, code), settings.language)
        }
    }

    private func documentsCard(_ value: IumrahCheckoutResponse) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            stageHeader(number: "04", icon: "doc.fill", title: tr("Travel documents", "Документы поездки", "Safar hujjatlari", "Сафар ҳужжатлари"))
            Text(tr("Each document appears here as soon as it is ready.", "Каждый документ появится здесь отдельно сразу после готовности.", "Har bir hujjat tayyor bo‘lishi bilan shu yerda alohida paydo bo‘ladi.", "Ҳар бир ҳужжат тайёр бўлиши билан шу ерда алоҳида пайдо бўлади."))
                .font(.subheadline).foregroundStyle(.secondary)

            documentStatusRow(kind: "ticket", title: tr("Airline ticket", "Авиабилет", "Aviachipta", "Авиачипта"), icon: "airplane", documents: value.documents)
            documentStatusRow(kind: "voucher", title: tr("Hotel confirmation", "Подтверждение отеля", "Mehmonxona tasdig‘i", "Меҳмонхона тасдиғи"), icon: "building.2.fill", documents: value.documents)
            documentStatusRow(kind: "visa", title: tr("Visa", "Виза", "Viza", "Виза"), icon: "checkmark.seal.fill", documents: value.documents)
            documentStatusRow(kind: "insurance", title: tr("Insurance", "Страховка", "Sug‘urta", "Суғурта"), icon: "cross.case.fill", documents: value.documents)

            ForEach(value.documents.filter { !["ticket", "voucher", "visa", "insurance"].contains($0.documentKind) }) { document in
                readyDocumentButton(document, title: document.title, icon: "doc.fill")
            }
        }
        .iumrahCard()
    }

    @ViewBuilder
    private func documentStatusRow(kind: String, title: String, icon: String, documents: [IumrahTravelDocument]) -> some View {
        if let document = documents.first(where: { $0.documentKind == kind }) {
            readyDocumentButton(document, title: title, icon: icon)
        } else {
            HStack(spacing: 13) {
                IumrahIconBadge(systemName: icon, role: .document, size: 48, symbolSize: 18, cornerRadius: 16)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.subheadline.weight(.semibold))
                    Text(tr("Being prepared", "Готовится", "Tayyorlanmoqda", "Тайёрланмоқда"))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                ProgressView().controlSize(.small)
            }
            .padding(14)
            .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }

    private func readyDocumentButton(_ document: IumrahTravelDocument, title: String, icon: String) -> some View {
        Button { Task { await openDocument(document) } } label: {
            HStack(spacing: 13) {
                IumrahIconBadge(systemName: icon, role: .success, size: 48, symbolSize: 18, cornerRadius: 16)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text(tr("Ready to open", "Готов · можно открыть", "Tayyor · ochish mumkin", "Тайёр · очиш мумкин"))
                        .font(.caption).foregroundStyle(.secondary)
                    if let reference = document.bookingReference, !reference.isEmpty {
                        Text(tr("Booking code: ", "Код бронирования: ", "Bron kodi: ", "Брон коди: ") + reference)
                            .font(.caption2.monospaced().weight(.semibold))
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
                Spacer()
                if isLoadingDocument { ProgressView() } else { Image(systemName: "arrow.up.right").foregroundStyle(.tertiary) }
            }
            .padding(14)
            .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func paymentDetails(_ value: IumrahCheckoutResponse) -> some View {
        switch paymentMethod {
        case "payme":
            VStack(spacing: 12) {
                if let image = paymeQRImage {
                    Image(uiImage: image)
                        .resizable().scaledToFit()
                        .padding(14)
                        .frame(maxWidth: 260, maxHeight: 260)
                        .background(.white, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                } else {
                    ProgressView()
                        .frame(maxWidth: .infinity, minHeight: 150)
                        .task { await loadPaymeQR(value) }
                }
                Text(tr("Scan the QR in PayMe, then attach the receipt below.", "Отсканируйте QR в PayMe, затем прикрепите чек ниже.", "PayMe orqali QR ni skanerlang, so‘ng chekni biriktiring.", "PayMe орқали QR ни сканерланг, сўнг чекни бириктиринг."))
                    .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
        case "humo":
            paymentNumberBlock(title: "Humo", number: value.payment.humoCardNumber, holder: value.payment.humoHolder)
        default:
            paymentNumberBlock(title: "Visa", number: value.payment.visaCardNumber, holder: value.payment.visaHolder)
        }
    }

    private func paymentNumberBlock(title: String, number: String, holder: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text(title).font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Text(groupedCard(number))
                        .font(.system(size: 22, weight: .semibold, design: .monospaced))
                        .minimumScaleFactor(0.78)
                        .lineLimit(1)
                    if !holder.isEmpty { Text(holder).font(.caption.weight(.medium)).foregroundStyle(.secondary) }
                }
                Spacer(minLength: 8)
                Button {
                    UIPasteboard.general.string = number
                    IumrahHaptics.success()
                } label: {
                    Image(systemName: "doc.on.doc")
                        .frame(width: 42, height: 42)
                        .contentShape(Circle())
                        .iumrahGlass(in: Circle(), interactive: true)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(15)
        .background(Color.iumrahRaisedBackground.opacity(0.70), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func stageHeader(number: String, icon: String, title: String) -> some View {
        HStack(spacing: 11) {
            IumrahIconBadge(
                systemName: icon,
                size: 38,
                symbolSize: 15,
                cornerRadius: 12
            )
            VStack(alignment: .leading, spacing: 1) {
                Text(number).font(.caption2.monospaced().weight(.bold)).foregroundStyle(.secondary)
                Text(title).font(.headline)
            }
        }
    }

    private func passwordField(_ title: String, text: Binding<String>, isVisible: Binding<Bool>, newPassword: Bool) -> some View {
        HStack(spacing: 11) {
            Image(systemName: "lock.fill").foregroundStyle(.secondary).frame(width: 22)
            Group {
                if isVisible.wrappedValue {
                    TextField(title, text: text)
                        .textContentType(newPassword ? .newPassword : .password)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } else {
                    SecureField(title, text: text)
                        .textContentType(newPassword ? .newPassword : .password)
                }
            }
            Button { isVisible.wrappedValue.toggle() } label: {
                Image(systemName: isVisible.wrappedValue ? "eye.slash.fill" : "eye.fill")
                    .foregroundStyle(.secondary)
                    .frame(width: 30, height: 40)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isVisible.wrappedValue ? tr("Hide password", "Скрыть пароль", "Parolni yashirish", "Паролни яшириш") : tr("Show password", "Показать пароль", "Parolni ko‘rsatish", "Паролни кўрсатиш"))
        }
        .padding(.horizontal, 14)
        .frame(height: 54)
        .iumrahGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)
    }

    private func readinessChip(_ title: String, ready: Bool) -> some View {
        HStack(spacing: 5) {
            Image(systemName: ready ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(ready ? .green : .secondary)
            Text(title).lineLimit(1).minimumScaleFactor(0.8)
        }
        .font(.caption2.weight(.semibold))
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color.iumrahRaisedBackground, in: Capsule())
    }

    @MainActor
    private func loadCheckout(showLoader: Bool = true) async {
        guard let session else { return }
        if showLoader { isLoading = true }
        defer { isLoading = false }
        do {
            let loaded = try await service.checkout(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                accountToken: account.bearerToken
            )
            checkout = loaded
            errorMessage = nil
            let options = paymentOptions(loaded)
            if let first = options.first, !options.contains(paymentMethod) {
                paymentMethod = first
            }
            if account.isAuthenticated { await loadFriendsSummary() }
        } catch {
            errorMessage = L10n.error(error, settings.language)
        }
    }

    private func prepareActivationAppleSignIn(_ request: ASAuthorizationAppleIDRequest) {
        do {
            appleNonce = try IumrahAppleSignInSupport.prepare(request)
            isAppleSigningIn = true
            errorMessage = nil
        } catch {
            isAppleSigningIn = false
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
        }
    }

    private func completeActivationAppleSignIn(_ result: Result<ASAuthorization, Error>) {
        Task { @MainActor in
            defer { isAppleSigningIn = false }
            do {
                let authorization = try result.get()
                let credential = try IumrahAppleSignInSupport.credential(from: authorization, nonce: appleNonce)
                let profile = try await account.signInWithApple(credential, locale: settings.language.rawValue)
                guard let session else { throw APIError.missingBookingToken }
                await finishAccountActivation(profile, session: session)
            } catch let error as ASAuthorizationError where error.code == .canceled {
                errorMessage = nil
            } catch {
                errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
                IumrahHaptics.error()
            }
        }
    }

    private func startActivationGoogleSignIn() {
        guard !isGoogleSigningIn, !isAppleSigningIn, !isSubmittingAccount else { return }
        isGoogleSigningIn = true
        errorMessage = nil
        Task { @MainActor in
            defer { isGoogleSigningIn = false }
            do {
                let credential = try await IumrahGoogleSignInSupport.signIn()
                let profile = try await account.signInWithGoogle(credential, locale: settings.language.rawValue)
                guard let session else { throw APIError.missingBookingToken }
                await finishAccountActivation(profile, session: session)
            } catch where IumrahGoogleSignInSupport.isCancellation(error) {
                errorMessage = nil
            } catch {
                errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
                IumrahHaptics.error()
            }
        }
    }

    @MainActor
    private func activateAccount(_ value: IumrahCheckoutResponse) async {
        guard let session, !session.accessToken.isEmpty else { return }
        isSubmittingAccount = true
        errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let profile = try await account.activate(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                password: password,
                locale: settings.language.rawValue
            )
            await finishAccountActivation(profile, session: session)
        } catch APIError.server(_, let message) where message.uppercased().contains("ACCOUNT_ALREADY_ACTIVE") {
            errorMessage = IumrahAccountSecurityCopy.message(for: APIError.server(409, "ACCOUNT_ALREADY_ACTIVE"), language: settings.language)
            showExistingAccountLogin = true
            IumrahHaptics.error()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func startEmailActivation(_ value: IumrahCheckoutResponse) async {
        guard let session, !session.accessToken.isEmpty else { return }
        isSubmittingAccount = true
        errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let response = try await account.startActivationEmail(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                email: activationEmail.trimmingCharacters(in: .whitespacesAndNewlines),
                locale: settings.language.rawValue
            )
            activationEmailChallengeID = response.challengeID
            activationEmailCode = ""
            IumrahHaptics.success()
        } catch APIError.server(_, let message) where message.uppercased().contains("ACCOUNT_ALREADY_ACTIVE") {
            errorMessage = IumrahAccountSecurityCopy.message(for: APIError.server(409, "ACCOUNT_ALREADY_ACTIVE"), language: settings.language)
            showExistingAccountLogin = true
            IumrahHaptics.error()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func confirmEmailActivation(_ value: IumrahCheckoutResponse) async {
        guard let session, !session.accessToken.isEmpty, !activationEmailChallengeID.isEmpty else { return }
        isSubmittingAccount = true
        errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let profile = try await account.confirmActivationEmail(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                challengeID: activationEmailChallengeID,
                code: activationEmailCode,
                password: password,
                locale: settings.language.rawValue
            )
            await finishAccountActivation(profile, session: session)
        } catch APIError.server(_, let message) where message.uppercased().contains("ACCOUNT_ALREADY_ACTIVE") {
            errorMessage = IumrahAccountSecurityCopy.message(for: APIError.server(409, "ACCOUNT_ALREADY_ACTIVE"), language: settings.language)
            showExistingAccountLogin = true
            IumrahHaptics.error()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func startSMSActivation(_ value: IumrahCheckoutResponse) async {
        guard let session, !session.accessToken.isEmpty, activationSMSCovered else { return }
        isSubmittingAccount = true
        errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let response = try await IumrahAccountActivationBridge().startBookingSMS(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                phone: activationPhoneInput(activationPhone),
                locale: settings.language.rawValue
            )
            activationSMSChallengeID = response.challengeID
            activationSMSCode = ""
            IumrahHaptics.success()
        } catch APIError.server(_, let message) where message.uppercased().contains("ACCOUNT_ALREADY_ACTIVE") {
            errorMessage = IumrahAccountSecurityCopy.message(for: APIError.server(409, "ACCOUNT_ALREADY_ACTIVE"), language: settings.language)
            showExistingAccountLogin = true
            IumrahHaptics.error()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func confirmSMSActivation(_ value: IumrahCheckoutResponse) async {
        guard let session, !session.accessToken.isEmpty, !activationSMSChallengeID.isEmpty else { return }
        isSubmittingAccount = true
        errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let response = try await IumrahAccountActivationBridge().confirmBookingSMS(
                bookingID: bookingID,
                bookingToken: session.accessToken,
                challengeID: activationSMSChallengeID,
                code: activationSMSCode,
                password: password,
                locale: settings.language.rawValue
            )
            // Establish the normal Keychain-backed app session via the canonical login path.
            let profile = try await account.login(
                identifier: response.account.iumrahID,
                password: password,
                locale: settings.language.rawValue
            )
            await finishAccountActivation(profile, session: session)
        } catch APIError.server(_, let message) where message.uppercased().contains("ACCOUNT_ALREADY_ACTIVE") {
            errorMessage = IumrahAccountSecurityCopy.message(for: APIError.server(409, "ACCOUNT_ALREADY_ACTIVE"), language: settings.language)
            showExistingAccountLogin = true
            IumrahHaptics.error()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func finishAccountActivation(_ profile: IumrahAccountProfile, session: StoredBookingSession) async {
        _ = profile
        bookings.setAccountToken(account.bearerToken)
        if let linked = try? await account.linkBooking(bookingID: bookingID, bookingToken: session.accessToken) {
            bookings.applyCanonicalLink(linked, to: bookingID)
        }
        if let token = account.bearerToken {
            await bookings.restoreAccountTrips(token: token)
        }
        password = ""
        passwordConfirm = ""
        activationEmailCode = ""
        activationSMSCode = ""
        activationSMSChallengeID = ""
        await loadCheckout(showLoader: false)
        IumrahHaptics.success()
    }

    @MainActor
    private func login(_ value: IumrahCheckoutResponse) async {
        isSubmittingAccount = true; errorMessage = nil
        defer { isSubmittingAccount = false }
        do {
            let identifier: String
            switch existingLoginMethod {
            case .iumrahID:
                identifier = normalizedID(existingLoginID)
            case .email:
                identifier = existingLoginEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            case .sms:
                identifier = activationPhoneInput(existingLoginPhone)
            }
            _ = try await account.login(identifier: identifier, password: loginPassword, locale: settings.language.rawValue)
            bookings.setAccountToken(account.bearerToken)
            guard let session else { throw APIError.missingBookingToken }
            let linked = try await account.linkBooking(bookingID: bookingID, bookingToken: session.accessToken)
            bookings.applyCanonicalLink(linked, to: bookingID)
            if let token = account.bearerToken { await bookings.restoreAccountTrips(token: token) }
            loginPassword = ""
            await loadCheckout(showLoader: false)
            IumrahHaptics.success()
        } catch {
            errorMessage = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func uploadReceipt(_ item: PhotosPickerItem) async {
        guard let token = account.bearerToken else { return }
        isUploadingReceipt = true; errorMessage = nil
        defer { isUploadingReceipt = false; receiptPhoto = nil }
        do {
            guard let data = try await item.loadTransferable(type: Data.self) else { throw URLError(.cannotDecodeContentData) }
            let contentType = item.supportedContentTypes.first?.preferredMIMEType ?? "image/jpeg"
            _ = try await service.uploadReceipt(bookingID: bookingID, method: paymentMethod, data: data, contentType: contentType, token: token)
            await loadCheckout(showLoader: false)
            IumrahHaptics.success()
        } catch {
            errorMessage = L10n.error(error, settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func loadPaymeQR(_ value: IumrahCheckoutResponse) async {
        guard value.payment.hasPaymeQR, let path = value.payment.paymeQRURL, let token = account.bearerToken else { return }
        do {
            let data = try await service.media(path: path, token: token)
            paymeQRImage = UIImage(data: data)
        } catch { errorMessage = L10n.error(error, settings.language) }
    }

    @MainActor
    private func openReceipt(_ receipt: IumrahPaymentReceipt) async {
        guard let token = account.bearerToken,
              let path = receipt.url?.trimmingCharacters(in: .whitespacesAndNewlines),
              !path.isEmpty else { return }
        isLoadingDocument = true
        defer { isLoadingDocument = false }
        do {
            let data = try await service.media(path: path, token: token)
            let ext: String
            if let filename = receipt.filename, !URL(fileURLWithPath: filename).pathExtension.isEmpty {
                ext = URL(fileURLWithPath: filename).pathExtension
            } else if receipt.contentType == "application/pdf" {
                ext = "pdf"
            } else if let direct = URL(string: path), !direct.pathExtension.isEmpty {
                ext = direct.pathExtension
            } else {
                ext = "jpg"
            }
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("iumrah-payment-receipt-\(receipt.id).\(ext)")
            try data.write(to: url, options: .atomic)
            previewFile = IumrahPreviewFile(
                id: "receipt-\(receipt.id)",
                title: tr("Payment receipt", "Чек оплаты", "To‘lov cheki", "Тўлов чеки"),
                url: url
            )
        } catch {
            errorMessage = L10n.error(error, settings.language)
        }
    }

    @MainActor
    private func openDocument(_ document: IumrahTravelDocument) async {
        guard let token = account.bearerToken else { return }
        isLoadingDocument = true; errorMessage = nil
        defer { isLoadingDocument = false }
        do {
            let data = try await service.media(path: document.url, token: token)
            let ext = document.contentType == "application/pdf" ? "pdf" : document.contentType.contains("png") ? "png" : "jpg"
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("iumrah-\(document.id).\(ext)")
            try data.write(to: url, options: .atomic)
            previewFile = IumrahPreviewFile(id: document.id, title: document.title, url: url)
        } catch { errorMessage = L10n.error(error, settings.language) }
    }

    private func paymentOptions(_ value: IumrahCheckoutResponse) -> [String] {
        var result: [String] = []
        if !value.payment.visaCardNumber.isEmpty { result.append("visa") }
        if value.payment.hasPaymeQR { result.append("payme") }
        if !value.payment.humoCardNumber.isEmpty { result.append("humo") }
        return result
    }

    private func paymentTitle(_ value: String) -> String { value == "payme" ? "PayMe" : value == "humo" ? "Humo" : "Visa" }
    private func receiptStatus(_ value: String) -> String {
        switch value { case "approved": return tr("Verified", "Проверен", "Tekshirildi", "Текширилди"); case "rejected": return tr("Needs attention", "Нужно исправить", "Qayta yuklang", "Қайта юкланг"); default: return tr("Sent for verification", "Отправлен на проверку", "Tekshiruvga yuborildi", "Текширувга юборилди") }
    }
    private func checkoutDate(_ value: String) -> String {
        let parser = ISO8601DateFormatter()
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = parser.date(from: value) ?? ISO8601DateFormatter().date(from: value) else { return value }
        return date.formatted(.dateTime.day().month(.abbreviated).year().hour().minute())
    }
    private func relationshipTitle(_ value: String?, position: Int) -> String {
        switch value ?? (position == 1 ? "self" : "other") {
        case "self": return tr("You", "Вы", "Siz", "Сиз")
        case "spouse": return tr("Spouse", "Муж / жена", "Turmush o‘rtog‘i", "Турмуш ўртоғи")
        case "mother": return tr("Mother", "Мама", "Ona", "Она")
        case "father": return tr("Father", "Папа", "Ota", "Ота")
        case "brother": return tr("Brother", "Брат", "Aka / uka", "Ака / ука")
        case "sister": return tr("Sister", "Сестра", "Opa / singil", "Опа / сингил")
        case "child": return tr("Child", "Ребёнок", "Farzand", "Фарзанд")
        case "relative": return tr("Relative", "Родственник", "Qarindosh", "Қариндош")
        case "friend": return tr("Friend", "Друг / подруга", "Do‘st", "Дўст")
        default: return tr("Travel companion", "Попутчик", "Hamroh", "Ҳамроҳ")
        }
    }
    private func travelerName(_ traveler: IumrahTravelerForm) -> String {
        let name = [traveler.firstName, traveler.lastName].filter { !$0.isEmpty }.joined(separator: " ")
        if !name.isEmpty { return name }
        return "\(travelerType(traveler.travelerType)) · \(traveler.position)"
    }
    private func travelerType(_ value: String) -> String {
        switch value { case "child": return tr("Child", "Ребёнок", "Bola", "Бола"); case "infant": return tr("Infant", "Младенец", "Chaqaloq", "Чақалоқ"); default: return tr("Adult", "Взрослый", "Katta", "Катта") }
    }
    private func travelerIcon(_ value: String) -> String { value == "infant" ? "figure.and.child.holdinghands" : value == "child" ? "figure.child" : "person.fill" }
    private func documentKind(_ value: String) -> String { value == "visa" ? tr("Visa", "Виза", "Viza", "Виза") : value == "voucher" ? tr("Voucher", "Ваучер", "Vaucher", "Ваучер") : value == "ticket" ? tr("Ticket", "Билет", "Chipta", "Чипта") : value == "insurance" ? tr("Insurance", "Страховка", "Sug‘urta", "Суғурта") : tr("Document", "Документ", "Hujjat", "Ҳужжат") }
    private func groupedCard(_ value: String) -> String {
        let compact = value.replacingOccurrences(of: " ", with: "")
        return stride(from: 0, to: compact.count, by: 4).map { offset in
            let start = compact.index(compact.startIndex, offsetBy: offset)
            let end = compact.index(start, offsetBy: min(4, compact.distance(from: start, to: compact.endIndex)))
            return String(compact[start..<end])
        }.joined(separator: " ")
    }
    private func normalizedID(_ value: String) -> String {
        let digits = value.filter(\.isNumber)
        guard !digits.isEmpty else { return value }
        if digits.count >= 8 { return digits }
        return String(repeating: "0", count: 8 - digits.count) + digits
    }
    private func tr(_ en: String, _ ru: String, _ uz: String, _ cyrl: String) -> String {
        switch settings.language { case .russian: return ru; case .english: return en; case .uzbek: return uz; case .uzbekCyrillic: return cyrl }
    }
}

private struct TravelerFormEditorSheet: View {
    @EnvironmentObject private var account: IumrahAccountStore
    @EnvironmentObject private var settings: AppSettingsStore
    @Environment(\.dismiss) private var dismiss
    let bookingID: String
    let language: AppSettingsStore.Language
    let onSaved: () -> Void

    @State private var form: IumrahTravelerForm
    @State private var dateOfBirthInput: String
    @State private var passportExpiryDateInput: String
    @State private var countryTarget: CountryTarget?
    @State private var passportPhoto: PhotosPickerItem?
    @State private var isSaving = false
    @State private var errorMessage: String?
    private let service = IumrahAccountService()

    init(bookingID: String, traveler: IumrahTravelerForm, language: AppSettingsStore.Language, onSaved: @escaping () -> Void) {
        self.bookingID = bookingID
        self.language = language
        self.onSaved = onSaved
        var initial = traveler
        if initial.relationship?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty != false {
            initial.relationship = traveler.position == 1 ? "self" : "other"
        }
        _form = State(initialValue: initial)
        _dateOfBirthInput = State(initialValue: Self.displayDate(traveler.dateOfBirth))
        _passportExpiryDateInput = State(initialValue: Self.displayDate(traveler.passportExpiryDate))
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    introCard

                    section(tr("Personal details", "Личные данные", "Shaxsiy ma’lumotlar", "Шахсий маълумотлар"), icon: "person.fill") {
                        relationshipRow
                        field(tr("First name", "Имя", "Ism", "Исм"), $form.firstName, contentType: .givenName)
                        field(tr("Middle name", "Отчество / второе имя", "Otasining ismi", "Отасининг исми"), $form.middleName, contentType: .middleName)
                        field(tr("Last name", "Фамилия", "Familiya", "Фамилия"), $form.lastName, contentType: .familyName)
                        genderRow
                        smartDateField(tr("Date of birth", "Дата рождения", "Tug‘ilgan sana", "Туғилган сана"), text: $dateOfBirthInput)
                        countryRow(target: .nationality, title: tr("Citizenship", "Гражданство", "Fuqarolik", "Фуқаролик"), value: form.nationality)
                    }

                    section(tr("Passport", "Паспорт", "Pasport", "Паспорт"), icon: "passport.fill") {
                        field(
                            tr("Passport number", "Номер паспорта", "Pasport raqami", "Паспорт рақами"),
                            $form.passportNumber,
                            keyboard: .asciiCapable,
                            autocapitalization: .characters
                        )
                        smartDateField(tr("Expiry date", "Срок действия", "Amal qilish muddati", "Амал қилиш муддати"), text: $passportExpiryDateInput)

                        PhotosPicker(selection: $passportPhoto, matching: .images) {
                            HStack(spacing: 12) {
                                IumrahIconBadge(
                                    systemName: (passportPhoto != nil || form.hasPassport) ? "checkmark.circle.fill" : "camera.fill",
                                    role: (passportPhoto != nil || form.hasPassport) ? .success : .document,
                                    size: 40,
                                    symbolSize: 17,
                                    cornerRadius: 13
                                )

                                VStack(alignment: .leading, spacing: 3) {
                                    Text((passportPhoto != nil || form.hasPassport) ? tr("Passport photo attached", "Фото паспорта прикреплено", "Pasport rasmi biriktirildi", "Паспорт расми бириктирилди") : tr("Attach passport photo", "Прикрепить фото паспорта", "Pasport rasmini biriktirish", "Паспорт расмини бириктириш"))
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(.primary)
                                    Text(tr("Clear photo of the information page", "Чёткое фото страницы с данными", "Ma’lumotlar sahifasining aniq rasmi", "Маълумотлар саҳифасининг аниқ расми"))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 8)
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.tertiary)
                            }
                            .padding(.horizontal, 14)
                            .frame(minHeight: 66)
                            .iumrahGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), interactive: true)
                        }
                        .buttonStyle(.plain)
                    }

                    section(tr("Contacts", "Контакты", "Aloqa", "Алоқа"), icon: "phone.fill") {
                        field(
                            tr("Phone", "Номер телефона", "Telefon", "Телефон"),
                            $form.phone,
                            keyboard: .phonePad,
                            contentType: .telephoneNumber,
                            autocapitalization: .never
                        )
                        field(
                            "Email",
                            $form.email,
                            keyboard: .emailAddress,
                            contentType: .emailAddress,
                            autocapitalization: .never
                        )

                        Divider()

                        Text(tr("Emergency contact", "Экстренный контакт", "Favqulodda kontakt", "Фавқулодда контакт"))
                            .font(.subheadline.weight(.semibold))
                        field(tr("Contact name", "Имя контакта", "Kontakt ismi", "Контакт исми"), $form.emergencyName, contentType: .name)
                        field(
                            tr("Emergency phone", "Экстренный номер телефона", "Favqulodda telefon", "Фавқулодда телефон"),
                            $form.emergencyPhone,
                            keyboard: .phonePad,
                            contentType: .telephoneNumber,
                            autocapitalization: .never
                        )
                        field(tr("Relationship", "Кем приходится", "Qarindoshlik", "Қариндошлик"), $form.emergencyRelation)

                        if (form.relationship ?? "").lowercased() == "self" {
                            let telegram = account.account?.telegram.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
                                ? (account.account?.telegram ?? "")
                                : settings.telegram
                            if !telegram.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                HStack(spacing: 10) {
                                    Image(systemName: "paperplane.fill")
                                        .foregroundStyle(.secondary)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Telegram")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                        Text(telegram)
                                            .font(.subheadline.weight(.semibold))
                                    }
                                    Spacer()
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.green)
                                }
                                .padding(.horizontal, 14)
                                .frame(minHeight: 56)
                                .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                            }
                        }
                    }

                    if !canSave {
                        missingFieldsCard
                    }

                    if let errorMessage {
                        Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 4)
                    }

                    Button { Task { await save() } } label: {
                        HStack(spacing: 10) {
                            if isSaving { ProgressView().tint(.white) }
                            Image(systemName: "checkmark.circle.fill")
                            Text(tr("Save pilgrim", "Сохранить анкету", "Anketani saqlash", "Анкетани сақлаш"))
                            Spacer(minLength: 10)
                        }
                    }
                    .buttonStyle(IumrahPrimaryButtonStyle())
                    .disabled(!canSave || isSaving)
                }
                .padding(.horizontal, IumrahDesign.pagePadding)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
            .background(Color.iumrahPageBackground)
            .navigationTitle(tr("Pilgrim \(form.position)", "Паломник \(form.position)", "Ziyoratchi \(form.position)", "Зиёратчи \(form.position)"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(tr("Close", "Закрыть", "Yopish", "Ёпиш")) { dismiss() }
                }
            }
            .task { autofillOwnerIfNeeded() }
            .sheet(item: $countryTarget) { target in
                CountryPickerSheet(
                    language: language,
                    selectedCanonicalName: selectedCountry(for: target),
                    title: countryTitle(target),
                    onSelect: { option in
                        setCountry(option.canonicalName, for: target)
                        countryTarget = nil
                    }
                )
            }
        }
    }

    private var introCard: some View {
        HStack(spacing: 12) {
            IumrahIconBadge(
                systemName: "wand.and.stars",
                role: .umrah,
                size: 42,
                symbolSize: 17,
                cornerRadius: 14
            )
            Text(tr(
                "Dates format automatically while you type. Countries can be selected from the searchable list.",
                "Даты форматируются автоматически. Страны можно выбрать из списка с поиском.",
                "Sanalar avtomatik formatlanadi. Davlatlarni qidiruv orqali ro‘yxatdan tanlang.",
                "Саналар автоматик форматланади. Давлатларни қидирув орқали рўйхатдан танланг."
            ))
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(Color.iumrahCareLight.opacity(0.085), in: RoundedRectangle(cornerRadius: 21, style: .continuous))
    }

    private var relationshipRow: some View {
        Menu {
            ForEach(["self", "spouse", "mother", "father", "brother", "sister", "child", "relative", "friend", "other"], id: \.self) { value in
                Button {
                    form.relationship = value
                    if value == "self" { autofillOwnerIfNeeded(force: true) }
                    IumrahHaptics.selection()
                } label: {
                    Label(relationshipOptionTitle(value), systemImage: form.relationship == value ? "checkmark" : relationshipOptionIcon(value))
                }
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: relationshipOptionIcon(form.relationship ?? "other"))
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr("Who is traveling?", "Кто едет?", "Kim bormoqda?", "Ким бормоқда?"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(relationshipOptionTitle(form.relationship ?? "other"))
                        .foregroundStyle(.primary)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.down").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 16)
            .frame(height: 60)
            .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        }
    }

    private func relationshipOptionTitle(_ value: String) -> String {
        switch value {
        case "self": return tr("Me", "Я", "Men", "Мен")
        case "spouse": return tr("Husband / wife", "Муж / жена", "Turmush o‘rtog‘i", "Турмуш ўртоғи")
        case "mother": return tr("Mother", "Мама", "Ona", "Она")
        case "father": return tr("Father", "Папа", "Ota", "Ота")
        case "brother": return tr("Brother", "Брат", "Aka / uka", "Ака / ука")
        case "sister": return tr("Sister", "Сестра", "Opa / singil", "Опа / сингил")
        case "child": return tr("Child", "Ребёнок", "Farzand", "Фарзанд")
        case "relative": return tr("Relative", "Родственник", "Qarindosh", "Қариндош")
        case "friend": return tr("Friend", "Друг / подруга", "Do‘st", "Дўст")
        default: return tr("Travel companion", "Попутчик", "Hamroh", "Ҳамроҳ")
        }
    }

    private func relationshipOptionIcon(_ value: String) -> String {
        switch value {
        case "self": return "person.fill"
        case "spouse": return "heart.fill"
        case "mother", "father": return "person.crop.circle.fill"
        case "brother", "sister": return "person.2.fill"
        case "child": return "figure.and.child.holdinghands"
        case "friend": return "person.2.fill"
        default: return "person.2.fill"
        }
    }

    private var genderRow: some View {
        Menu {
            Button {
                form.gender = "male"
                IumrahHaptics.selection()
            } label: {
                Label(tr("Male", "Мужской", "Erkak", "Эркак"), systemImage: form.gender == "male" ? "checkmark" : "person.fill")
            }
            Button {
                form.gender = "female"
                IumrahHaptics.selection()
            } label: {
                Label(tr("Female", "Женский", "Ayol", "Аёл"), systemImage: form.gender == "female" ? "checkmark" : "person.fill")
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "person.2.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 22)
                Text(form.gender == "male" ? tr("Male", "Мужской", "Erkak", "Эркак") : form.gender == "female" ? tr("Female", "Женский", "Ayol", "Аёл") : tr("Gender", "Пол", "Jins", "Жинс"))
                    .foregroundStyle(form.gender.isEmpty ? Color.secondary : Color.primary)
                Spacer(minLength: 8)
                Image(systemName: "chevron.down")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 16)
            .frame(height: 56)
            .iumrahGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), interactive: true)
        }
    }

    @MainActor
    private func autofillOwnerIfNeeded(force: Bool = false) {
        guard (form.relationship ?? "").lowercased() == "self" else { return }
        let profile = account.account

        func set(_ current: inout String, _ value: String?) {
            guard let value else { return }
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty else { return }
            if force || current.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                current = clean
            }
        }

        set(&form.firstName, profile?.firstName.isEmpty == false ? profile?.firstName : settings.firstName)
        set(&form.lastName, profile?.lastName.isEmpty == false ? profile?.lastName : settings.lastName)
        set(&form.gender, settings.gender)
        set(&form.nationality, settings.nationality)
        set(&form.phone, profile?.phone.isEmpty == false ? profile?.phone : settings.phone)
        set(&form.email, profile?.email.isEmpty == false ? profile?.email : settings.email)
        set(&form.emergencyName, settings.emergencyName)
        set(&form.emergencyPhone, settings.emergencyPhone)
        set(&form.emergencyRelation, settings.emergencyRelation)

        if (force || dateOfBirthInput.isEmpty), !settings.dateOfBirth.isEmpty {
            dateOfBirthInput = Self.displayDate(settings.dateOfBirth)
        }
        if !form.nationality.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            form.passportIssuingCountry = form.nationality
        }
    }

    private var canSave: Bool {
        missingRequiredFields.isEmpty
    }

    private var missingRequiredFields: [String] {
        var missing: [String] = []
        func needs(_ value: String, _ title: String) {
            if value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { missing.append(title) }
        }
        needs(form.relationship ?? "", tr("Traveler", "Кто едет", "Kim bormoqda", "Ким бормоқда"))
        needs(form.firstName, tr("First name", "Имя", "Ism", "Исм"))
        needs(form.lastName, tr("Last name", "Фамилия", "Familiya", "Фамилия"))
        needs(form.gender, tr("Gender", "Пол", "Jins", "Жинс"))
        needs(form.nationality, tr("Citizenship", "Гражданство", "Fuqarolik", "Фуқаролик"))
        needs(form.passportNumber, tr("Passport number", "Номер паспорта", "Pasport raqami", "Паспорт рақами"))
        needs(form.phone, tr("Phone", "Телефон", "Telefon", "Телефон"))
        needs(form.emergencyName, tr("Emergency contact", "Экстренный контакт", "Favqulodda kontakt", "Фавқулодда контакт"))
        needs(form.emergencyPhone, tr("Emergency phone", "Экстренный телефон", "Favqulodda telefon", "Фавқулодда телефон"))
        if Self.isoDate(dateOfBirthInput) == nil { missing.append(tr("Date of birth", "Дата рождения", "Tug‘ilgan sana", "Туғилган сана")) }
        if Self.isoDate(passportExpiryDateInput) == nil { missing.append(tr("Passport expiry", "Срок действия паспорта", "Pasport muddati", "Паспорт муддати")) }
        if !(form.hasPassport || passportPhoto != nil) { missing.append(tr("Passport photo", "Фото паспорта", "Pasport rasmi", "Паспорт расми")) }
        return missing
    }

    private var missingFieldsCard: some View {
        HStack(alignment: .top, spacing: 11) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundStyle(.red)
            VStack(alignment: .leading, spacing: 4) {
                Text(tr("Complete the required fields", "Заполните обязательные поля", "Majburiy maydonlarni to‘ldiring", "Мажбурий майдонларни тўлдиринг"))
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.red)
                Text(missingRequiredFields.prefix(5).joined(separator: " · ") + (missingRequiredFields.count > 5 ? " …" : ""))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.red.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(Color.red.opacity(0.16), lineWidth: 0.8)
        }
    }

    private func section<Content: View>(_ title: String, icon: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                IumrahIconBadge(
                    systemName: icon,
                    size: 38,
                    symbolSize: 16,
                    cornerRadius: 13
                )
                Text(title).font(.headline)
            }
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahCard()
    }

    private func field(
        _ title: String,
        _ text: Binding<String>,
        keyboard: UIKeyboardType = .default,
        contentType: UITextContentType? = nil,
        autocapitalization: TextInputAutocapitalization = .words
    ) -> some View {
        TextField(title, text: text)
            .keyboardType(keyboard)
            .textContentType(contentType)
            .textInputAutocapitalization(autocapitalization)
            .autocorrectionDisabled(keyboard == .emailAddress || keyboard == .asciiCapable)
            .padding(.horizontal, 16)
            .frame(height: 56)
            .iumrahGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), interactive: true)
    }

    private func smartDateField(_ title: String, text: Binding<String>) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "calendar")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.secondary)
                .frame(width: 22)
            TextField("\(title) · DD.MM.YYYY", text: text)
                .keyboardType(.numberPad)
                .textContentType(.none)
                .onChange(of: text.wrappedValue) { _, value in
                    let formatted = Self.formatDateInput(value)
                    if formatted != value { text.wrappedValue = formatted }
                }
            Spacer(minLength: 0)
            if text.wrappedValue.count == 10 {
                Image(systemName: Self.isoDate(text.wrappedValue) == nil ? "exclamationmark.circle.fill" : "checkmark.circle.fill")
                    .foregroundStyle(Self.isoDate(text.wrappedValue) == nil ? Color.red : Color.green)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
        .iumrahGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), interactive: true)
    }

    private func countryRow(target: CountryTarget, title: String, value: String) -> some View {
        Button {
            countryTarget = target
            IumrahHaptics.selection()
        } label: {
            HStack(spacing: 12) {
                Image(systemName: target == .nationality ? "flag.fill" : "globe.europe.africa.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(CountryCatalog.displayName(for: value, language: language) ?? tr("Select country", "Выберите страну", "Davlatni tanlang", "Давлатни танланг"))
                        .font(.body)
                        .foregroundStyle(value.isEmpty ? Color.secondary : Color.primary)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 16)
            .frame(height: 60)
            .iumrahGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), interactive: true)
        }
        .buttonStyle(.plain)
    }

    @MainActor
    private func save() async {
        guard let token = account.bearerToken,
              let dob = Self.isoDate(dateOfBirthInput),
              let expiry = Self.isoDate(passportExpiryDateInput) else { return }
        isSaving = true
        errorMessage = nil
        defer { isSaving = false }
        do {
            var payload = form
            payload.dateOfBirth = dob
            payload.passportExpiryDate = expiry
            // The client asks only for citizenship. Keep the legacy backend field derived from it.
            payload.passportIssuingCountry = payload.nationality
            _ = try await service.saveTraveler(bookingID: bookingID, position: form.position, form: payload, token: token)
            if (payload.relationship ?? "").lowercased() == "self" {
                await persistSelfTravelerProfile(payload)
            }
            if let passportPhoto, let data = try await passportPhoto.loadTransferable(type: Data.self) {
                let type = passportPhoto.supportedContentTypes.first?.preferredMIMEType ?? "image/jpeg"
                try await service.uploadPassport(bookingID: bookingID, position: form.position, data: data, contentType: type, token: token)
            }
            IumrahHaptics.success()
            onSaved()
            dismiss()
        } catch {
            errorMessage = L10n.error(error, language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func persistSelfTravelerProfile(_ payload: IumrahTravelerForm) async {
        settings.firstName = payload.firstName.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.lastName = payload.lastName.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.phone = payload.phone.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.email = payload.email.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.dateOfBirth = payload.dateOfBirth
        settings.gender = payload.gender
        settings.nationality = payload.nationality.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.emergencyName = payload.emergencyName.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.emergencyPhone = payload.emergencyPhone.trimmingCharacters(in: .whitespacesAndNewlines)
        settings.emergencyRelation = payload.emergencyRelation.trimmingCharacters(in: .whitespacesAndNewlines)

        guard account.isAuthenticated, let current = account.account else { return }
        let resolvedEmail = payload.email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? current.email : payload.email.trimmingCharacters(in: .whitespacesAndNewlines)
        _ = try? await account.updateProfile(
            firstName: settings.firstName,
            lastName: settings.lastName,
            phone: settings.phone,
            email: resolvedEmail,
            telegram: current.telegram,
            whatsapp: current.whatsapp
        )
    }

    private func selectedCountry(for target: CountryTarget) -> String {
        form.nationality
    }

    private func setCountry(_ value: String, for target: CountryTarget) {
        form.nationality = value
    }

    private func countryTitle(_ target: CountryTarget) -> String {
        tr("Citizenship", "Гражданство", "Fuqarolik", "Фуқаролик")
    }

    private static func formatDateInput(_ raw: String) -> String {
        let digits = String(raw.filter(\.isNumber).prefix(8))
        guard digits.count > 2 else { return digits }
        let day = String(digits.prefix(2))
        let afterDay = digits.dropFirst(2)
        guard afterDay.count > 2 else { return day + "." + String(afterDay) }
        let month = String(afterDay.prefix(2))
        let year = String(afterDay.dropFirst(2))
        return day + "." + month + "." + year
    }

    private static func displayDate(_ raw: String) -> String {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil {
            let pieces = value.split(separator: "-")
            if pieces.count == 3 { return "\(pieces[2]).\(pieces[1]).\(pieces[0])" }
        }
        return formatDateInput(value)
    }

    private static func isoDate(_ display: String) -> String? {
        guard display.range(of: #"^\d{2}\.\d{2}\.\d{4}$"#, options: .regularExpression) != nil else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = "dd.MM.yyyy"
        formatter.isLenient = false
        guard let date = formatter.date(from: display) else { return nil }
        let output = DateFormatter()
        output.locale = Locale(identifier: "en_US_POSIX")
        output.calendar = Calendar(identifier: .gregorian)
        output.dateFormat = "yyyy-MM-dd"
        return output.string(from: date)
    }

    private func tr(_ en: String, _ ru: String, _ uz: String, _ cyrl: String) -> String {
        switch language {
        case .russian: return ru
        case .english: return en
        case .uzbek: return uz
        case .uzbekCyrillic: return cyrl
        }
    }
}

private enum CountryTarget: String, Identifiable {
    case nationality
    var id: String { rawValue }
}

private struct CountryOption: Identifiable, Hashable {
    let code: String
    let canonicalName: String
    let localizedName: String
    var id: String { code }
    var flag: String {
        code.uppercased().unicodeScalars.compactMap { scalar in
            UnicodeScalar(127397 + scalar.value).map(String.init)
        }.joined()
    }
}

private enum CountryCatalog {
    static func options(language: AppSettingsStore.Language) -> [CountryOption] {
        let localized = Locale(identifier: language.localeIdentifier)
        let canonical = Locale(identifier: "en_US_POSIX")
        return Locale.isoRegionCodes.compactMap { code in
            guard let englishName = canonical.localizedString(forRegionCode: code),
                  let localizedName = localized.localizedString(forRegionCode: code) else { return nil }
            return CountryOption(code: code, canonicalName: englishName, localizedName: localizedName)
        }
        .sorted { $0.localizedName.localizedCaseInsensitiveCompare($1.localizedName) == .orderedAscending }
    }

    static func displayName(for stored: String, language: AppSettingsStore.Language) -> String? {
        let value = stored.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if let option = options(language: language).first(where: {
            $0.canonicalName.caseInsensitiveCompare(value) == .orderedSame ||
            $0.localizedName.caseInsensitiveCompare(value) == .orderedSame ||
            $0.code.caseInsensitiveCompare(value) == .orderedSame
        }) {
            return option.localizedName
        }
        return value
    }
}

private struct CountryPickerSheet: View {
    @Environment(\.dismiss) private var dismiss
    let language: AppSettingsStore.Language
    let selectedCanonicalName: String
    let title: String
    let onSelect: (CountryOption) -> Void
    @State private var search = ""

    private var filtered: [CountryOption] {
        let all = CountryCatalog.options(language: language)
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return all }
        return all.filter {
            $0.localizedName.localizedCaseInsensitiveContains(q) ||
            $0.canonicalName.localizedCaseInsensitiveContains(q) ||
            $0.code.localizedCaseInsensitiveContains(q)
        }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { option in
                Button {
                    onSelect(option)
                    IumrahHaptics.selection()
                    dismiss()
                } label: {
                    HStack(spacing: 12) {
                        Text(option.flag)
                            .font(.system(size: 24))
                            .frame(width: 34)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(option.localizedName)
                                .foregroundStyle(.primary)
                            Text(option.code)
                                .font(.caption.monospaced().weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if option.canonicalName.caseInsensitiveCompare(selectedCanonicalName) == .orderedSame {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(Color.iumrahCareLight)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
            .listStyle(.plain)
            .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: searchPrompt)
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(closeTitle) { dismiss() }
                }
            }
        }
    }

    private var searchPrompt: String {
        switch language {
        case .russian: return "Поиск страны"
        case .english: return "Search country"
        case .uzbek: return "Davlatni qidirish"
        case .uzbekCyrillic: return "Давлатни қидириш"
        }
    }

    private var closeTitle: String {
        switch language {
        case .russian: return "Закрыть"
        case .english: return "Close"
        case .uzbek: return "Yopish"
        case .uzbekCyrillic: return "Ёпиш"
        }
    }
}

private struct IumrahPreviewFile: Identifiable {
    let id: String
    let title: String
    let url: URL
}

private struct QuickLookFilePreview: UIViewControllerRepresentable {
    let url: URL
    func makeCoordinator() -> Coordinator { Coordinator(url: url) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController(); controller.dataSource = context.coordinator; return controller
    }
    func updateUIViewController(_ uiViewController: QLPreviewController, context: Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}
