# Kepler Studio — Production Reels Engine (v0.2, integration preview)

**Speech-first, asset-locked editing for Iumrah.** The AI decides **WHAT original component is relevant and WHEN**. It may **not redraw, restyle, retouch, retype, or silently replace** supplied cards. Renderers only animate exact source imagery as intact layers.

> **Status:** Integration-ready developer preview, **NOT production-ready automated editing**. Real Uzbek ASR quality, semantic decisions, audience pacing, masked face safety, UI motion, licensing of visual assets, and MP4 quality still require staged reviews with real footage. This ZIP does not install ChatGPT Plugins or remotely modify GitHub.

## What's new in v0.2

- Audited all **eight** ZIPs supplied by the owner; reproducible archive SHA-256 in `integrations/sources.lock.json`.
- Curated references from **five MIT-licensed** Agent Skill projects, each with its upstream license under `upstream/` (source materials remain authored by their original maintainers).
- Remotion official Skills, Motion AI Kit, and WhisperX registered as **external integrations**; their source is **not bundled** because the first two archives lack a repository-root redistribution license, and WhisperX is a substantial BSD-licensed runtime package better installed via its supported package distribution.
- A single authority chain: `AGENTS.md` → `skills/kepler-studio/SKILL.md` → engine validation → optional upstream **reference** documentation. Upstream instructions to "invent freely" never override user-asset immutability.
- Rendering gate: **draft AI proposals are not final renders**. To render without the `--preview` flag, an explicit reviewed plan is mandatory.
- Optional WhisperX (`--engine whisperx`) with correct fallback to *segment only* when alignment is unavailable; no invented word timings.
- 2 new motion presets (`slide_up_soft`, `slide_right_soft`) animate the original bitmap only.
- `inspect` exports frame samples for downstream human/vision inspection; it does not pretend to visually understand them.
- `audit` generates a *technical* preflight report. It does not certify visual or semantic excellence.

## What the 8 packages do

| Package | Kepler use | Status |
|---|---|---|
| Video Use | Editing process, cuts, QA guidance and helper scripts | Curated MIT reference |
| Videoediting Claude Skill | FFmpeg editing, subtitle/EDL patterns | Curated MIT reference |
| Motion Design Agent | Motion tokens, sequencing, entrance/exit rules | Curated MIT reference |
| Remotion Motion Graphics Skill | Compositing and motion production patterns | Curated MIT reference |
| Claude Video / Watch | Video review instructions and tooling | Curated MIT reference |
| Remotion official Skills | React/Remotion composition and render practices | External integration; no code bundled |
| Motion AI Kit | React animation review and spring design | External integration; no code bundled |
| WhisperX | Optional speech alignment engine | External optional Python runtime |

All sources come from **user-provided archives**. Project titles are not proof of verified authorship or suitability. Technical dependencies have not all been executed in the working environment.

## Structure

```text
AGENTS.md                         ← non-negotiable agent contract
skills/kepler-studio/SKILL.md     ← primary production skill
upstream/                         ← MIT-licensed source guidance, NOT auto-executed
integrations/sources.lock.json    ← 8 archive hashes & legal/integration status
integrations/external/            ← external packages to install separately
assets/original/                  ← original user images unchanged, with publication warning
assets/registry.json              ← immutable SHA-256 for each visual asset
assets/motion_presets.json        ← allowed container animation vocabulary
kepler_studio/                    ← FFmpeg compositor, ASR adapters, timing/QA gates
docs/                             ← production rules, iPhone setup, legal notices
.github/workflows/ci.yml         ← no-key CI checks and synthetic render preview
```

## Running from a machine or a self-hosted runner

Requires Python 3.11+, FFmpeg 6+ with `libx264`, and Pillow.

```bash
python -m pip install -r requirements.txt
python -m kepler_studio verify-assets
python -m unittest discover -s tests -v

# 1. Inspect the real clip without faking visual understanding
python -m kepler_studio inspect --video original.mp4 --output local/inspect.json --stills local/stills

# 2. Install ASR only if wanted, run on the real audio
python -m pip install -r requirements-asr.txt
python -m kepler_studio transcribe --video original.mp4 --language uz --engine faster-whisper --output local/transcript.json

# 3. Draft, inspect, then explicitly approve the timestamped semantic plan
python -m kepler_studio plan --transcript local/transcript.json --output local/draft.json --mode rules
python -m kepler_studio approve-plan --plan local/draft.json --output local/approved.json --confirm-reviewed

# 4. Technical audit and final render only from an approved plan
python -m kepler_studio audit --video original.mp4 --plan local/approved.json --output local/qa.json
python -m kepler_studio render --video original.mp4 --plan local/approved.json --output local/final.mp4
```

**`approve-plan` is a deliberate user action, not AI self-approval.** Confirm the evidence, timing, relevance, persons' consent and component position before passing the flag. For a disposable draft render, `render --preview` permits unapproved events. **Never publish previews without review.**

`plan --mode rules` is a basic keyword matcher, **not semantic AI**. Optional `plan --mode ai` uses an OpenAI API key from environment and still needs manual review. WhisperX requires separately installed compatible PyTorch/WhisperX versions; no model weights are shipped. Cloud workflows intentionally **do not** download large ASR models.

## Public GitHub caution

`assets/original/` includes original cards provided by the project owner: personal names, a photograph and third-party branding reference. These original assets are **not** covered by this repo's MIT license. **Do not publish them until rights and consent are checked.** To keep cards private, use a private asset store and a separate authenticated build workflow. See `assets/ASSET_LICENSE.md` and `docs/LICENSING_AND_PRIVACY_RU.md`.

## iPhone workflow

The ZIP has files at the repository **root**, not an extra top-level folder. It can be used with the previously configured `bootstrap` workflow to unpack a ZIP on GitHub. However, **do not replace an existing repository blindly**: this is a full repository snapshot, not a cherry-pick patch. A separate `kepler-studio-v0.2-update-only.zip` is supplied for updating the v0.1 tree, retaining unchanged original assets. For GitHub Actions CI, open Actions → **Verify Kepler Studio** → **Run workflow**.

## Next production milestones

1. Verify Uzbek speech segmentation and review word-level subtitles by a native speaker.
2. Frame-aware semantic director (approved vision model + sound), sentence-boundary cuts and safeguards against face/eye/mouth occlusion.
3. Remotion render adapter with version-locked runtime and UI transitions using original PNG alpha **without redrawing**.
4. Test on real Iumrah footage against an agreed reference and score shot rhythm, pacing, text legibility and CTA compliance.
5. Authenticated media upload/storage + remote rendering and a user-approved ChatGPT plugin integration.
