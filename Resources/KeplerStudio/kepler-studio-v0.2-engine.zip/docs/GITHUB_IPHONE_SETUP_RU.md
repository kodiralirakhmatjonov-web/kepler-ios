# Запуск публичного kepler-studio на iPhone

1. В Safari открыть https://github.com/new. Name: `kepler-studio`. Выбрать `Public`; создать репозиторий с `README`.
2. Открыть репозиторий → **Add file → Create new file**. Имя: `.github/workflows/bootstrap.yml`. Вставить полный текст файла `docs/bootstrap_workflow.yml` из подготовленного архива / отдельного полученного файла. Нажать **Commit changes**.
3. **Add file → Upload files** → выбрать из «Файлы» `kepler-studio-starter.zip`. Загрузить **ZIP как один файл**, не открывать архив на телефоне; нажать **Commit changes**.
4. GitHub Actions запустит `Bootstrap Kepler Studio from ZIP`, распакует содержимое ZIP прямо в корень репозитория, создаст коммит и удалит временный ZIP.
5. В **Actions** проверить, что bootstrap завершился зелёным значком. Перейти к workflow `Verify Kepler Studio`, запустить **Run workflow** (при необходимости, commit GitHub Actions не перезапускает другие workflow автоматически).
6. В workflow `Verify Kepler Studio` скачать **kepler-studio-technical-smoketest** в разделе Artifacts. Это техническая тестовая сцена, а не отредактированный Reels.

**Если на bootstrap ошибка `403`:** GitHub Actions → repository Settings → Actions → General → Workflow permissions → проверить разрешения на запись. Workflow уже объявляет `contents: write`; политика организации может переопределить доступ.

**Важно:** данный способ без компьютера, без PAT, без API Secrets. Все пользовательские PNG в ZIP станут публичными. Не публикуйте секреты, клиентские файлы, паспорта, личные видеозаписи.
