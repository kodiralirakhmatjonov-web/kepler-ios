# Аудит восьми загруженных архивов — 10.10.2026

| ZIP | Тип | Найдено | Лицензия в архиве | Решение |
| --- | --- | --- | --- | --- |
| motion-design-agent-main.zip | Agent Skills | 73+ SKILL.md включая root | MIT | Текстовые исходники + notices в upstream/motion-design |
| remotion-motion-graphics-skill-main.zip | Agent Skills | 4 SKILL.md | MIT | Документы/скрипты без гигабайт медиа в upstream/remotion-motion-graphics |
| skills-main.zip | Agent Skills | 12 root Skills Remotion | Нет root LICENSE | Только внешняя ссылка, **не копируем** |
| claude-video-main.zip | Agent Skills | watch/SKILL.md | MIT | Кураторские файлы и помощники в upstream/watch |
| whisperX-main 2.zip | Python ASR package | whisperx library, no SKILL.md | BSD 2-Clause | Runtime устанавливается отдельно, архив не встраиваем |
| ai-kit-main.zip | Motion AI Kit Skill | motion/SKILL.md | Нет root LICENSE | Только внешняя ссылка, **не копируем** |
| videoediting-claude-skill-main.zip | Agent Skill | videoediting/SKILL.md + scripts | MIT | Кураторские файлы и помощники в upstream/videoediting |
| video-use-main.zip | Agent Skill | root SKILL.md, helpers | MIT | Кураторские файлы и помощники в upstream/video-use |

Проверка лицензий отражает содержимое конкретно загруженных ZIP, а не юридическое заключение. Отсутствие `LICENSE` в архиве **не означает**, что оригинальный проект в принципе закрыт; означает, что без дополнительного подтверждения мы не распространяем его содержимое.

`integrations/sources.lock.json` содержит SHA-256 именно загруженных восьми архивов. Это происхождение источника, не независимая проверка безопасности.

## Какие части реально подключены

- Ядро FFmpeg + валидация ассетов + собственные motion-presets — **исполняемый Kepler код**.
- faster-whisper (optional) и WhisperX (optional) — ASR, но в CI не запускаются (модели большие и нужны ресурсы).
- Официальные Remotion Skills, Motion AI Kit, MIT Skill reference guides — **техническая документация для следующей интеграции**, не подключённые runtime движки.
- Поддержка полноценной генерации сложных Remotion-анимаций **не заявляется** до реального порта и теста.

## Обработка конфликтов

Upstream Video Use рекомендует агенту творчески придумывать детали, а некоторые motion-graphics руководства предлагают генерировать элементы. Эти рекомендации **запрещены** в Kepler Studio, если они противоречат пользовательскому правилу «исходные карточки не перерисовывать». Подробнее — `AGENTS.md`.
