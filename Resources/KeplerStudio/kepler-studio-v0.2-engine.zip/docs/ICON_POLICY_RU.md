# Cupertino / SF Symbols / Liquid Glass

- **iOS**: original SF Symbols and native Liquid Glass are runtime UI technologies. They are not a free universal icon font for server-rendered promotional videos.
- **Видео**: use only assets supplied by the user (where redistribution is authorized) or icon packs with licenses covering video export, derivative work and public repository distribution.
- **Анимация**: Lottie (`.json` / `.lottie`), animated PNG, vector sequences, or transparent alpha MOV can be added as separate render adapters in future versions. v0.2 supports static original PNG/JPEG cards with animated container movement only. Native Liquid Glass and SF Symbols rendering are not implemented.
- **Do not place proprietary font/icon files into public repository without redistribution rights.**
- Source manifests must track provenance, attribution and license before asset activation.
