"""Deterministic technical checks; no claim of subjective, semantic or visual quality."""
from __future__ import annotations
import json
from pathlib import Path
from .assets import load_registry, verify_assets
from .render import media_info, validate_plan


def quality_report(video:Path, plan_path:Path, output:Path|None=None, allow_unapproved:bool=False):
    src=media_info(video)
    plan=json.loads(plan_path.read_text(encoding='utf-8'))
    cards=load_registry()
    items=validate_plan(plan,cards,src['duration'],allow_unapproved=allow_unapproved)
    original_integrity=verify_assets()
    report={
        'status':'technical_valid_preflight',
        'source_video':str(video),
        'source_resolution':[src['width'],src['height']],
        'source_aspect_ratio':round(src['width']/src['height'],6),
        'source_duration':src['duration'],
        'has_audio':src['has_audio'],
        'assets_verified':len(original_integrity),
        'events':len(items),
        'human_review_required':any(not e.get('approved',False) for e in items),
        'semantic_accuracy_verified':False,
        'face_occlusion_verified':False,
        'claim_of_natively_rendered_liquid_glass':False,
        'notes':[
            'Only technical validation was automated, not aesthetic quality or semantic correctness.',
            'Review face-safe regions, subtitle language, exact phrase timing and brand permissions manually.',
            'Upscaling cannot recover missing source detail.'
        ]
    }
    if output:
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return report
