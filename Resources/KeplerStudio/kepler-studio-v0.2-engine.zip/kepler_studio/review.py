"""Explicit human approval of candidate montage plans."""
from __future__ import annotations
import json
from pathlib import Path

def approve_plan(source:Path, dest:Path, confirm_reviewed:bool=False):
    if not confirm_reviewed:
        raise ValueError('Human approval required: explicitly supply --confirm-reviewed after reviewing timing and speech evidence.')
    if source.resolve()==dest.resolve():
        raise ValueError('Approval must write a new file, preserving the original AI proposal.')
    data=json.loads(source.read_text(encoding='utf-8'))
    if not isinstance(data.get('events'),list): raise ValueError('No events list')
    if data.get('mode')=='manual_demo_not_semantic':
        raise ValueError('Demo plan is not evidence-based and cannot be approved as production')
    for event in data['events']:
        if not event.get('evidence'):
            raise ValueError('Missing literal speech evidence; refuse approval')
        if not isinstance(event.get('start'),(float,int)) or not isinstance(event.get('end'),(float,int)):
            raise ValueError('Missing event timing; refuse approval')
        event['approved']=True
    data['review_required']=False
    data['approval_provenance']='User-confirmed manual review (local CLI); not cryptographically signed'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return data
