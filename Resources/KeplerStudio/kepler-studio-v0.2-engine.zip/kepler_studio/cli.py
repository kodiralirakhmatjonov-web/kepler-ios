from __future__ import annotations
import argparse,json
from pathlib import Path
from .assets import verify_assets, register_asset
from .planner import build_plan
from .transcribe import transcribe
from .inspect import inspect_video
from .review import approve_plan
from .quality import quality_report
from .render import video_render

def main():
    p=argparse.ArgumentParser(prog='kepler-studio',description='Speech-first video compositor with immutable original cards.')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('verify-assets',help='Verify all original assets against SHA-256 registry.')
    aadd=sub.add_parser('add-asset',help='Register a user-provided original image with no redraw.')
    aadd.add_argument('--name',required=True)
    aadd.add_argument('--file',type=Path,required=True)
    aadd.add_argument('--keywords',required=True,help='Comma-separated spoken-topic tags')
    aadd.add_argument('--display',choices=['overlay','cutaway'],default='cutaway')
    aadd.add_argument('--rights',choices=['user_supplied','licensed','third_party_reference_not_for_default_use'],default='user_supplied')
    aadd.add_argument('--disable',action='store_true')
    t=sub.add_parser('transcribe',help='Optional real audio transcription via faster-whisper; requires extra install.')
    t.add_argument('--video',type=Path,required=True)
    t.add_argument('--output',type=Path,required=True)
    t.add_argument('--language',default='uz')
    t.add_argument('--model',default='small')
    t.add_argument('--engine',choices=['faster-whisper','whisperx'],default='faster-whisper')
    q=sub.add_parser('plan',help='Generate evidence-linked overlay plan from real transcript.')
    q.add_argument('--transcript',type=Path,required=True)
    q.add_argument('--output',type=Path,required=True)
    q.add_argument('--mode',choices=['rules','ai'],default='rules')
    q.add_argument('--model',default='gpt-4.1-mini')
    r=sub.add_parser('render',help='Preserve original cards; animate their appearance and disappearance.')
    r.add_argument('--video',type=Path,required=True)
    r.add_argument('--plan',type=Path,required=True)
    r.add_argument('--output',type=Path,required=True)
    r.add_argument('--width',type=int,default=1080);r.add_argument('--height',type=int,default=1920)
    r.add_argument('--preset',default='medium',choices=['ultrafast','veryfast','fast','medium','slow'])
    r.add_argument('--preview',action='store_true',help='Explicitly allow unapproved events for preview ONLY')
    a=sub.add_parser('approve-plan',help='Approve reviewed draft after inspecting timing/semantics')
    a.add_argument('--plan',type=Path,required=True)
    a.add_argument('--output',type=Path,required=True)
    a.add_argument('--confirm-reviewed',action='store_true',required=True)
    a=sub.add_parser('inspect',help='Probe source and extract evenly spaced visual samples')
    a.add_argument('--video',type=Path,required=True)
    a.add_argument('--output',type=Path,required=True)
    a.add_argument('--stills',type=Path)
    a.add_argument('--samples',type=int,default=8)
    a=sub.add_parser('audit',help='Machine-check an approved plan against input')
    a.add_argument('--video',type=Path,required=True)
    a.add_argument('--plan',type=Path,required=True)
    a.add_argument('--output',type=Path,required=True)
    a.add_argument('--preview',action='store_true')
    a=p.parse_args()
    if a.command=='verify-assets':
        print(json.dumps({'originals_verified':verify_assets()},indent=2))
    elif a.command=='add-asset':
        print(str(register_asset(a.name,a.file,[x.strip() for x in a.keywords.split(',') if x.strip()],a.display,a.rights,not a.disable)))
    elif a.command=='transcribe':
        print('Segments:',transcribe(a.video,a.output,model=a.model,language=a.language,engine=a.engine))
    elif a.command=='plan':
        print(json.dumps(build_plan(a.transcript,a.output,mode=a.mode,model=a.model),ensure_ascii=False,indent=2))
    elif a.command=='approve-plan':
        print(json.dumps(approve_plan(a.plan,a.output,confirm_reviewed=a.confirm_reviewed),ensure_ascii=False,indent=2))
    elif a.command=='inspect':
        print(json.dumps(inspect_video(a.video,a.output,a.stills,a.samples),ensure_ascii=False,indent=2))
    elif a.command=='audit':
        print(json.dumps(quality_report(a.video,a.plan,a.output,allow_unapproved=a.preview),ensure_ascii=False,indent=2))
    elif a.command=='render':
        print(json.dumps(video_render(a.video,a.plan,a.output,a.width,a.height,preset=a.preset,allow_unapproved=a.preview),indent=2))
