"""Render ORIGINAL user-supplied pixels with appearance/disappearance only.

PIL is used exclusively to remove fully transparent outer padding in temporary files;
no pixels are repainted or stylized. FFmpeg does all scaling and compositing.
"""
from __future__ import annotations
import json, math, subprocess, tempfile
from pathlib import Path
from PIL import Image
from .assets import ROOT, load_registry, verify_assets


def cmd(args):
    p = subprocess.run([str(x) for x in args], capture_output=True,text=True)
    if p.returncode:
        raise RuntimeError('Command failed: '+' '.join(map(str,args))+'\n'+p.stderr[-4000:])
    return p.stdout


def media_info(video: Path):
    raw = json.loads(cmd(['ffprobe','-v','error','-show_streams','-show_format','-of','json',video]))
    video_stream = next(s for s in raw['streams'] if s['codec_type']=='video')
    return {'width':int(video_stream['width']),'height':int(video_stream['height']),
            'duration':float(raw['format']['duration']),
            'has_audio':any(s['codec_type']=='audio' for s in raw['streams'])}


def trim_transparent(source: Path, target: Path):
    image = Image.open(source).convert('RGBA')
    box = image.getchannel('A').getbbox()
    if not box: raise ValueError('Asset has no non-transparent pixels: '+str(source))
    # Crop only transparent exterior. Original remains byte-for-byte unchanged.
    image.crop(box).save(target)
    return target, (box[2]-box[0],box[3]-box[1])


def prep_asset(source: Path, target:Path):
    if source.suffix.lower()=='.png':return trim_transparent(source,target)
    im=Image.open(source); return source, im.size


def validate_plan(plan, library, duration, allow_unapproved=False):
    events=[];prev_end=-1
    if not isinstance(plan.get('events', []),list):
        raise ValueError('Expected events list')
    if plan.get('mode')=='manual_demo_not_semantic' and not allow_unapproved:
        raise ValueError('Synthetic smoke-test plans cannot be used as final production renders')
    for ev in sorted(plan.get('events',[]),key=lambda x:x['start']):
        name=ev.get('asset')
        if not allow_unapproved and ev.get('approved') is not True:
            raise ValueError('Unapproved event: '+str(name)+'. Use approve-plan or preview mode.')
        if name not in library or not library[name]['enabled']:
            raise ValueError('Asset not approved or missing: '+str(name))
        start,end=float(ev['start']),float(ev['end'])
        if start<0 or end>duration+.01 or end<=start or start<prev_end-.001:
            raise ValueError('Invalid or overlapping event '+name)
        display=ev.get('display',library[name]['display'])
        if ev.get('motion','rise_fade') not in ('fade','rise_fade','slide_up_soft','slide_right_soft'):
            raise ValueError('Unregistered animation preset: '+str(ev.get('motion')))
        if display not in ('overlay','cutaway'):
            raise ValueError('Unsupported display '+display)
        events.append(dict(ev,start=start,end=end,display=display))
        prev_end=end
    return events


def video_render(video:Path, plan_path:Path, output:Path, width=1080,height=1920,fps=30,crf=20,preset='medium',allow_unapproved=False):
    """Letterbox/pad keeps source aspect ratio exactly. Cutaway uses unmodified card on clean neutral BG."""
    verify_assets()
    if width<240 or height<240 or width>4320 or height>7680:raise ValueError('Unsafe output dimensions')
    info=media_info(video)
    plan=json.loads(plan_path.read_text(encoding='utf-8'))
    library=load_registry()
    events=validate_plan(plan,library,info['duration'],allow_unapproved=allow_unapproved)
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='kepler-assets-') as tempdir:
        args=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video)]
        dims=[]
        for n,ev in enumerate(events,1):
            src=(ROOT/library[ev['asset']]['file']).resolve()
            tmp=Path(tempdir)/f'card{n}.png'
            src,size=prep_asset(src,tmp)
            dims.append(size)
            # Input streams start at 0; timestamps are positioned in filter graph.
            args+=['-loop','1','-framerate',str(fps),'-t',str(ev['end']-ev['start']+.08),'-i',str(src)]
        f=[]
        f.append(f'[0:v]fps={fps},scale={width}:{height}:force_original_aspect_ratio=decrease,'
                 f'pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=0x08090B,'
                 'setsar=1,format=yuv420p[vbase]')
        prev='vbase'
        # First introduce any cutaway neutral sheets. These are backgrounds, not redrawn cards.
        for n,ev in enumerate(events):
            if ev['display']=='cutaway':
                name=f'bg{n}'
                f.append(f'[{prev}]drawbox=x=0:y=0:w=iw:h=ih:color=0xF5F5F7:t=fill:'
                         f"enable='between(t,{ev['start']:.3f},{ev['end']:.3f})'[{name}]")
                prev=name
        for n,ev in enumerate(events,1):
            dur=ev['end']-ev['start'];sw,sh=dims[n-1]
            if ev['display']=='overlay':
                maxw=int(width*.86); maxh=int(height*.19)
            else:
                maxw=int(width*.89); maxh=int(height*.68)
            fit=min(maxw/sw,maxh/sh)
            w=int(sw*fit)//2*2;h=int(sh*fit)//2*2
            x=(width-w)//2
            if ev['display']=='overlay':
                y=height-int(height*.095)-h  # Lower safe zone, no face overlay.
                if y < int(height*.64):
                    raise ValueError('Overlay enters protected face zone; choose cutaway.')
            else:y=(height-h)//2
            fade=min(.28,dur/5)
            overlayname=f'card{n}'
            f.append(f'[{n}:v]scale={w}:{h}:flags=lanczos,format=rgba,'
                     f'fade=t=in:st=0:d={fade:.3f}:alpha=1,'
                     f'fade=t=out:st={dur-fade:.3f}:d={fade:.3f}:alpha=1,'
                     f'setpts=PTS-STARTPTS+{ev["start"]:.3f}/TB[{overlayname}]')
            # Subtle motion: 30px vertical rise over 320ms, with easing.
            yexpr=(str(y) if ev.get('motion','rise_fade')=='fade' else
                   f'{y}+{int(height*.016)}*pow(max(0,1-(t-{ev["start"]:.3f})/0.32),2)')
            nextlabel=f'v{n}'
            f.append(f'[{prev}][{overlayname}]overlay=x={x}:y=\'{yexpr}\':'
                     f'eof_action=pass:shortest=0:format=auto:eval=frame:'
                     f"enable='between(t,{ev['start']:.3f},{ev['end']:.3f})'[{nextlabel}]")
            prev=nextlabel
        # Input when no cards: there is no overlay.
        args+=['-filter_complex',';'.join(f),'-map',f'[{prev}]']
        if info['has_audio']:args+=['-map','0:a:0','-c:a','aac','-b:a','160k']
        else:args+=['-an']
        args+=['-c:v','libx264','-preset',preset,'-crf',str(crf),'-pix_fmt','yuv420p',
               '-movflags','+faststart','-r',str(fps),'-t',f'{info["duration"]:.3f}',str(output)]
        cmd(args)
    result=media_info(output)
    assert result['width']==width and result['height']==height
    return {'output':str(output),'source':info,'rendered':result,'events':len(events),
            'original_assets_preserved':True,'upscaling_adds_detail':False}
