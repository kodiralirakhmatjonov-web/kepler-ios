"""Speech-evidence-based decisions. No random overlays or fabricated subtitles."""
from __future__ import annotations
import json, os, re, urllib.request
from pathlib import Path
from .assets import load_registry

MIN_DURATION = 1.6

def segments_from_json(path: Path):
    data = json.loads(path.read_text(encoding='utf-8'))
    if isinstance(data, list):
        items = data
    else:
        items = data.get('segments', [])
    cleaned = []
    for s in items:
        if not isinstance(s,dict) or not s.get('text'):
            continue
        start, end = float(s['start']), float(s['end'])
        if start < 0 or end <= start or end - start > 60: continue
        cleaned.append({'start':start,'end':end,'text':str(s['text']).strip()})
    return sorted(cleaned, key=lambda s:s['start'])


def guard_events(events, segments, library):
    """Reject unsupported, overlapping, invented or unsafely located events."""
    valid, previous_end = [], -10.0
    for e in sorted(events, key=lambda v:float(v.get('start',0))):
        name = e.get('asset')
        if name not in library or not library[name]['enabled']:
            continue
        start = float(e.get('start', -1)); end = float(e.get('end', -1))
        if start < 0 or end - start < MIN_DURATION or end - start > 5 or start < previous_end + 0.7:
            continue
        q = str(e.get('evidence','')).strip()
        # Require literal transcription evidence. No guessing from arbitrary text.
        matches = [s for s in segments if q and q.casefold() in s['text'].casefold() and s['start']-1.0 <= start <= s['end']+1.0]
        if not matches: continue
        valid.append({'asset':name,'start':round(start,2),'end':round(end,2),
                      'evidence':q,'motion':'rise_fade','display':library[name]['display'],
                      'approved':False})
        previous_end = end
    return valid


def rules_plan(segments, library):
    # Baseline only. A genuine semantic model can replace it with --mode ai.
    proposals = []
    for s in segments:
        if s['end'] - s['start'] < .35: continue
        text = s['text'].lower()
        choices = []
        for name, meta in library.items():
            if not meta['enabled']: continue
            matched = [k for k in meta['keywords'] if re.search(r'(?<!\w)'+re.escape(k.lower())+r'(?!\w)',text)]
            if matched: choices.append((max(map(len,matched)), name))
        if not choices: continue
        name = max(choices)[1]
        start = max(s['start'], 0);end = min(s['end'] + .45,start+3.0)
        if end-start < MIN_DURATION: continue
        proposals.append({'asset':name,'start':start,'end':end,'evidence':s['text']})
    return guard_events(proposals,segments,library)


def ai_plan(segments, library, model: str):
    """Optional semantic provider. API key only from environment, never GitHub source."""
    key = os.environ.get('OPENAI_API_KEY')
    if not key: raise RuntimeError('OPENAI_API_KEY not configured. Use --mode rules or provide local plan JSON.')
    safe_assets = {n:{'meaning_tags':m['keywords'],'display':m['display']}
                   for n,m in library.items() if m['enabled']}
    request = {
        'model':model,
        'messages':[
            {'role':'system','content':(
                'You are a precision video editor. Return ONLY a JSON object with events array. '
                'Use each provided asset at most once. Display only when a directly matching spoken phrase '
                'is present at the stated timestamp. The evidence field MUST contain an exact substring '
                'of a single segment text. Do not invent transcript, partnerships, events, or subtitles. '
                'Prefer no overlay over irrelevant overlay. Each event: asset, start, end, evidence. '
                'Each lasts 1.6 to 5 seconds, allow at least 0.7s between events.')},
            {'role':'user','content':json.dumps({'assets':safe_assets,'segments':segments},ensure_ascii=False)}],
        'response_format':{'type':'json_object'},
        'temperature':0.1
    }
    req = urllib.request.Request('https://api.openai.com/v1/chat/completions',
          data=json.dumps(request).encode('utf-8'),
          headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=100) as response:
        raw = json.load(response)
    parsed = json.loads(raw['choices'][0]['message']['content'])
    return guard_events(parsed.get('events',[]),segments,library)


def build_plan(transcript: Path, output: Path, mode='rules', model='gpt-4.1-mini'):
    segs=segments_from_json(transcript)
    if not segs:raise ValueError('No valid speech segments. Cards will not be invented.')
    library=load_registry()
    events=ai_plan(segs,library,model) if mode=='ai' else rules_plan(segs,library)
    plan={'schema_version':1,'source_transcript':str(transcript), 'mode':mode,
          'review_required':True,'assets_are_immutable':True,
          'subtitle_status':'No subtitles unless transcribed and verified.',
          'events':events}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return plan
