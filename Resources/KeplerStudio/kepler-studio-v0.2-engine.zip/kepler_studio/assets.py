"""Immutable asset library. Originals are never drawn on or overwritten."""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_registry(root: Path = ROOT):
    return json.loads((root / 'assets/registry.json').read_text(encoding='utf-8'))['cards']


def verify_assets(root: Path = ROOT):
    cards = load_registry(root)
    checks = []
    for name, meta in cards.items():
        p = (root / meta['file']).resolve()
        if not p.is_relative_to(root.resolve()):
            raise ValueError(f'Unsafe asset path: {name}')
        if not p.is_file():
            raise FileNotFoundError(p)
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != meta['sha256']:
            raise ValueError(f'ORIGINAL_ASSET_CHANGED: {name}. Restore original PNG.')
        checks.append((name, actual[:12]))
    return checks


def register_asset(name: str, source: Path, keywords: list[str], display: str = 'cutaway', rights: str = 'user_supplied', enable: bool = True, root: Path = ROOT):
    """Add a future user supplied component unchanged; fail on collisions."""
    import re, shutil
    if not re.fullmatch(r'[a-z][a-z0-9_]{1,45}', name):
        raise ValueError('Asset ID must be lowercase snake_case and 2–46 characters.')
    if display not in ('overlay','cutaway'):raise ValueError('Invalid display')
    if rights not in ('user_supplied','licensed','third_party_reference_not_for_default_use'):
        raise ValueError('Rights metadata required')
    if source.suffix.lower() not in ('.png','.jpg','.jpeg'):
        raise ValueError('Supported original formats: PNG, JPG, JPEG. No forced format conversion.')
    if not source.is_file():raise FileNotFoundError(source)
    registry_path=root/'assets/registry.json'
    data=json.loads(registry_path.read_text(encoding='utf-8'))
    if name in data['cards']:raise FileExistsError('Registered asset exists: '+name)
    dest=root/'assets/original'/f'{name}{source.suffix.lower()}'
    if dest.exists():raise FileExistsError(dest)
    shutil.copyfile(source,dest) # Byte-for-byte, not redrawn or recompressed
    from PIL import Image
    with Image.open(dest) as im: size=list(im.size)
    data['cards'][name]={'file':str(dest.relative_to(root)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                         'size':size,'keywords':keywords,'display':display,'rights':rights,
                         'enabled':bool(enable),'minimum_semantic_score':0.75}
    registry_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return dest
