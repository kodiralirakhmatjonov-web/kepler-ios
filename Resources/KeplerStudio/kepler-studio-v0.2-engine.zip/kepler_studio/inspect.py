"""Extract on-demand visual evidence. Never invent visual description from missing frames."""
from __future__ import annotations
import json, subprocess
from pathlib import Path
from .render import media_info

def inspect_video(video:Path, output:Path, stills:Path|None=None, samples:int=8):
    if not video.is_file():raise FileNotFoundError(video)
    if samples<1 or samples>30:raise ValueError('samples must be from 1 to 30')
    d=media_info(video)
    result={'video':str(video),'media':d,'images':[],'content_reviewed':False,
            'note':'Frames are for downstream vision analysis; this command does not detect objects or emotions.'}
    if stills is not None:
        stills.mkdir(parents=True,exist_ok=True)
        for n in range(samples):
            t=(n+0.5)*d['duration']/samples
            target=stills/f'sample_{n:02d}.jpg'
            args=['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',f'{t:.3f}',
                  '-i',str(video),'-frames:v','1','-vf',
                  'scale=360:640:force_original_aspect_ratio=decrease',str(target)]
            p=subprocess.run(args,capture_output=True,text=True)
            if p.returncode!=0:raise RuntimeError(p.stderr[-1200:])
            result['images'].append({'at':round(t,3),'file':str(target)})
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result
