"""Optional ASR: faster-whisper baseline or WhisperX; real speech only.

Word-level timing should NOT be claimed when a language alignment model is unavailable.
Neither model downloads in CI. Run locally/server-side with appropriate resource limits.
"""
from __future__ import annotations
import json
from pathlib import Path


def transcribe(video:Path,output:Path,model='small',language='uz',engine='faster-whisper'):
    if engine not in ('faster-whisper','whisperx'):
        raise ValueError('Supported ASR engines: faster-whisper, whisperx')
    if not video.is_file():raise FileNotFoundError(video)
    if engine=='faster-whisper':
        try:from faster_whisper import WhisperModel
        except ImportError as exc:raise RuntimeError('Install optional requirements-asr.txt') from exc
        decoder=WhisperModel(model,device='cpu',compute_type='int8')
        raw, info=decoder.transcribe(str(video),language=language,word_timestamps=True,
                                    beam_size=5,vad_filter=True)
        records=[]
        for item in raw:
            words=[{'start':round(w.start,3),'end':round(w.end,3),'word':w.word}
                   for w in (item.words or []) if w.start is not None and w.end is not None]
            records.append({'start':round(item.start,3),'end':round(item.end,3),
                            'text':item.text.strip(),'words':words})
        lang=info.language
        status='model_estimated_word_timings'
    else:
        try:import whisperx
        except ImportError as exc:raise RuntimeError('Install WhisperX separately; it is not bundled.') from exc
        try:import torch
        except ImportError as exc:raise RuntimeError('WhisperX requires a compatible PyTorch installation.') from exc
        device='cuda' if torch.cuda.is_available() else 'cpu'
        compute_type='float16' if device=='cuda' else 'int8'
        audio=whisperx.load_audio(str(video))
        decoder=whisperx.load_model(model,device,compute_type=compute_type,language=language)
        raw=decoder.transcribe(audio)
        lang=raw.get('language',language)
        status='segment_only_no_alignment_model'
        try:
            align_model, metadata=whisperx.load_align_model(language_code=lang,device=device)
        except (ValueError,RuntimeError,KeyError,TypeError):
            aligned=raw  # Unsupported language: do not hallucinate aligned words.
        else:
            aligned=whisperx.align(raw['segments'],align_model,metadata,audio,device,
                                  return_char_alignments=False)
            status='forced_aligned_words_unverified'
        records=[]
        for seg in aligned.get('segments',[]):
            start,end=seg.get('start'),seg.get('end')
            if start is None or end is None:continue
            words=[{'start':round(w['start'],3),'end':round(w['end'],3),
                    'word':w.get('word','')}
                   for w in seg.get('words',[]) if w.get('start') is not None and w.get('end') is not None]
            records.append({'start':round(start,3),'end':round(end,3),
                            'text':seg.get('text','').strip(),'words':words})
    result={'language':lang,'source_engine':engine,'source_model':model,
            'human_verified':False,'word_timing_status':status,'segments':records}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return len(records)
