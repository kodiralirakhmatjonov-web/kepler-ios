# videoediting — a video editing skill for Claude Code

Edit vertical videos without a video editor. Claude cuts the footage by speech, grades the picture, burns in word-level subtitles and draws infographics — all through ffmpeg, all editable as text, all rebuilt with a single command.

*Read this in [Русский](README.ru.md).*

![Before and after](docs/img/hero.png)

*Left — a frame straight off the phone. Right — the same moment after processing: colour grade, thesis card, word-level subtitles. The sample footage is in Russian; the pipeline is language-agnostic.*

---

## What this is

Conventional editing means a mouse, a timeline and an hour of work per finished minute. This takes a different route: **the edit is described as text**, and Claude turns that description into ffmpeg commands.

The trick is that the video is never analysed pixel by pixel. First a transcript is produced with word-level accuracy, and the entire structure of the video is derived from it — where to cut, what to promote into graphics, where the accents go. Speech provides the skeleton; the picture serves it.

Concrete result: a 1:12 talking-head monologue shot on an iPhone becomes a finished 1:08 video with a grade, 164 subtitle events and 12 infographic cards.

## What it does

| Capability | How |
|---|---|
| Semantic cutting, removing pauses and filler | transcript + `edl.json` edit list |
| Punch-in — changing framing across cuts | `crop` + `scale`, alternating zoom |
| Colour grading | `eq` + `curves` + `vignette`, `.cube` LUT support |
| Word-level subtitles with the active word highlighted | ASS + libass |
| Infographics, cards, diagrams, titles | HTML/CSS → headless Chrome → PNG with alpha → `overlay` |
| Stabilisation | `vidstabdetect` + `vidstabtransform` |
| Loudness normalisation for social platforms | `loudnorm` to −14 LUFS |
| Several videos from one source | one transcript, several `edl.json` files |

**What it does not do on its own**, stated up front: object tracking and masked grading — those need Premiere, DaVinci or After Effects. Frame-accurate cutting, keyframed motion, transitions and cutting to a music beat are not ffmpeg's strengths either, but an optional companion covers them — see *A timeline when you need one* below.

## Quick start

```bash
git clone https://github.com/blazerior/videoediting-claude-skill.git
cd videoediting-claude-skill
```

**Windows:**

```powershell
powershell -ExecutionPolicy Bypass -File scripts/install.ps1
```

**macOS / Linux:**

```bash
bash scripts/install.sh
```

The script copies the skill into `~/.claude/skills/videoediting/` and reports which dependencies are missing. Then open Claude Code in the folder holding your footage:

```
/videoediting edit IMG_1234.MOV for Reels, the topic is burnout
```

Claude will install whatever is missing (ffmpeg, faster-whisper, Chrome), inspect the source, transcribe it and show you the structure **before** rendering anything.

Full installation, including on a machine with nothing on it — [INSTALL.md](INSTALL.md).

## How it works

```mermaid
flowchart TD
    A[Source footage] --> B[ffprobe + scene detection<br/>contact sheet]
    A --> C[faster-whisper<br/>word-level transcript]
    B --> D[Claude looks at frames<br/>and reads the text]
    C --> D
    D --> E[Storyboard<br/>panels over time]
    E --> F[edl.json<br/>the edit list]
    F --> G[build.py base<br/>cut + grade + zoom]
    C --> H[make_ass.py<br/>word-level subtitles]
    E --> I[overlays.json → Chrome<br/>PNG cards with alpha]
    G --> J[build.py final<br/>overlays + subtitles + audio]
    H --> J
    I --> J
    J --> K[Finished video<br/>1080×1920, −14 LUFS]
```

The key detail is that **assembly is split into two stages**. `base` computes the cut and the colour, which is slow. `final` composites graphics and subtitles, which is fast. So cards and titles can be iterated endlessly without recomputing the cut.

The other one: **the entire state of the edit lives in three JSON files.** Want to move a cut — change a number in `edl.json`. Want different copy on a card — change the HTML in `overlays.json`. No binary project files; everything is versioned in git and editable by hand or by Claude.

## What is inside the skill

```
skill/videoediting/
├── SKILL.md                      the workflow and the rules that make or break a video
├── references/
│   ├── setup.md                  installing on a clean machine (Windows/macOS)
│   ├── pipeline.md               8 steps with commands + an acceptance checklist
│   ├── storyboard.md             video formats, 9 panel types, converting timings
│   ├── design-system.md          palette, type scale, safe zones, techniques
│   ├── batch-pipeline.md         many reels as cached stages — and where context goes
│   ├── remotion.md               animated graphics tier via the Remotion plugin
│   ├── fablecut.md               timeline tier via FableCut — and how the two meet
│   ├── ffmpeg-cookbook.md        grades, effects, transitions, audio, encoding
│   └── troubleshooting.md        17 failures, each of which cost an hour of debugging
└── assets/
    ├── tools/                    12 working scripts — copied into the project as-is
    └── templates/                starter edl.json, overlays.json, corrections.json
```

`SKILL.md` is deliberately short — Claude reads it whole and pulls in the reference files only when they are needed, so the context does not fill up with things this particular job never touches.

### The scripts

| Script | What it does |
|---|---|
| `download.py` | fetch source footage from a URL (yt-dlp) — skip it if you already have a local file |
| `transcribe.py` | faster-whisper → `transcript.json` with word-level timings and `.srt` |
| `transcribe_cloud.py` | the same output through the Groq / OpenAI Whisper API — no model download, needs an API key |
| `pauses.py` | lists pauses in the speech — the basis for the edit list |
| `dump_words.py` | every word with its index and recognition confidence — for proofreading |
| `make_ass.py` | word-level ASS subtitles, re-timed onto the post-cut timeline |
| `render_overlays.py` | HTML/CSS → headless Chrome → 1080×1920 PNG with a transparent background |
| `build.py` | assembly: `base` (cut + grade), `final` (overlays + subtitles + audio) |
| `build_vo.py` | same, for a separate voiceover track — footage from several sources fitted to the audio |
| `batch_vo.py` | transcribe every voiceover in a single model load |
| `mute_subs.py` | drop subtitles where a full-screen card is on screen |
| `pipeline.py` | batch driver — every stage over every reel, cached by input hash |

### Editing many reels at once

Doing ten reels the conversational way costs roughly ten times the context of doing one, and most of that buys nothing. `pipeline.py` runs each stage once over the whole project:

```bash
python tools/pipeline.py all
```

```
ingest    : 91 files, 71 vertical
transcribe: 7 new, 0 cached
overlays  : 10 rebuilt, 0 cached
subs      : 10 rebuilt, 0 cached
base      : 10 rebuilt, 0 cached
final     : 10 rebuilt, 0 cached
qa        : work/qa.png — one image for every reel
```

Re-running is free when nothing changed. The `qa` stage stacks every reel into one contact sheet, so ten reels are verified with a single look instead of twenty separate frame checks. Details and the full list of context traps: `references/batch-pipeline.md`.

### Animated graphics (optional)

With the [Remotion plugin](https://www.remotion.dev/docs/ai/claude-code-plugin) installed, React-rendered overlays can be exported with an alpha channel and composited by the same ffmpeg pass. Worth it when the motion itself carries meaning — counters, staged reveals, spring physics. Not worth it for cards that just fade in. See `references/remotion.md`.

### A timeline when you need one (optional)

[FableCut](https://github.com/ronak-create/FableCut) — by Ronak Parmar, MIT licence — is a browser-based non-linear editor that an agent drives over MCP. Its timeline is a single `project.json`: patch it and the open editor hot-reloads in about 150 ms.

It covers precisely what filtergraphs are bad at: frame-accurate trimming by eye, 17 transitions, roughly 25 keyframable properties with easing curves, speed ramps, chroma key. Its `remake-reel` skill breaks a reference video down into shot boundaries, beats, BPM and an energy curve, then rebuilds that structure with your own footage — beat-driven editing that a transcript-first pipeline simply cannot see.

What it does not do: speech recognition, of which it has none, and unattended export — the compositor is the browser, so rendering needs a human click. Speech-driven structure and ten-reel batches therefore stay here. The full split and the hand-off in both directions are written up in `references/fablecut.md`.

```bash
/plugin marketplace add ronak-create/FableCut
```

### The edit list

The edit itself looks like this — plain JSON, edited by hand:

```json
{
  "source": "D:\\video\\IMG_1234.MOV",
  "segments": [
    { "start": 0.00,  "end": 2.11,  "zoom": 1.00,  "t": "hook — opening line" },
    { "start": 2.36,  "end": 6.28,  "zoom": 1.045, "t": "hook continues" },
    { "start": 7.21,  "end": 10.52, "zoom": 1.00,  "t": "myth busted" }
  ]
}
```

Everything between the segments is cut. `zoom` alternates so that each cut reads as a change of angle rather than a mistake.

## What the output looks like

### Colour grading

![Grade](docs/img/grade.png)

*Left the source, right after grading. The face is lifted out of hard backlight, contrast and warmth are added to the skin, and a soft vignette keeps the eye on the subject. Different locations inside one video are reconciled to a common look.*

### Word-level subtitles

![Subtitles](docs/img/subtitles.png)

*The active word is tinted and slightly enlarged. Long lines wrap instead of running off the edge. The position clears the platform UI so Reels buttons never sit on the text.*

### Infographic panel types

![Panel types](docs/img/panels.png)

*Hook title, rebuttal with a strike-through, two-column diagram, list with bullets appearing one at a time, pull quote, big number, CTA. All of them are plain HTML/CSS — you can draw anything.*

### Safe zones

![Safe zones](docs/img/safe-zones.png)

*The rule broken on almost every first attempt: **a card goes above the face, never on it**. The speaker's gaze is half the trust the video earns.*

### The finished video, frame by frame

![Result](docs/img/result.png)

*Eight moments from a 68-second video: hook, thesis, diagram, list, climax, two CTAs. Between the blocks there is deliberately a stretch with no graphics — the viewer needs air.*

## Requirements

| Component | Why | Required |
|---|---|---|
| [Claude Code](https://claude.com/claude-code) | the agent itself | yes |
| ffmpeg (**full build**) | the entire edit | yes |
| Python 3.10+ | the pipeline scripts | yes |
| faster-whisper | word-level transcript | yes, unless you transcribe in the cloud |
| Google Chrome | rendering infographics to PNG | yes, if you want graphics |
| 4 GB of disk space | the speech recognition model | yes, for the local model |
| yt-dlp | pulling footage from a URL (`download.py`) | only when the source is a link |
| A Groq / OpenAI API key | cloud transcription (`transcribe_cloud.py`) | only as an alternative to the local model |

Stripped-down ffmpeg builds will not do — the `subtitles` (libass) and `lut3d` filters are required. There is a check in [INSTALL.md](INSTALL.md).

Runs on Windows, macOS and Linux. Developed and debugged on Windows 11.

## About the name

The skill is called `videoediting` and is invoked with `/videoediting`. The name is deliberate: popular marketing skill packs for Claude Code already claim `video` for AI footage generation (Veo, Sora, HeyGen, Remotion), which is a completely different job, and two skills named `video` in one environment only confuse the agent.

To rename it, change the folder name and the `name:` field on the second line of `SKILL.md`. The name is not referenced anywhere else.

## Limitations and honest caveats

- **Speech recognition gets words wrong even on clean audio.** The `small` model makes roughly ten mistakes per minute, `large-v3` one or two. That is why the pipeline has a dedicated proofreading step and a `corrections.json` file keyed by word index. Do not skip it — an error burned into the subtitles is permanent.
- **The first model download is slow** — 0.5 to 3 GB depending on the model you pick. After that it is cached. `transcribe_cloud.py` skips the download entirely, at the price of an API key.
- **Whisper invents text over silence.** On a quiet opening or a quiet tail it can produce a line nobody said — classically a fabricated subtitler credit on Russian audio — and give it a perfectly ordinary confidence score. Both transcription scripts filter the obvious cases, but the filter is not airtight: read the first and last line of every transcript yourself.
- **A cut placed where the subject is moving** (standing up, fixing their hair) looks like a mistake. The pipeline does not fix this automatically — those spots must be avoided or covered with graphics. Hence the hard rule to review the contact sheet before building the edit list.
- **This does not replace an editor on a complex project.** It is a way to produce a steady stream of similar vertical videos quickly and predictably.

A full list of known failures lives in `skill/videoediting/references/troubleshooting.md`.

## Credits

The pipeline builds on ideas from several open projects:

- [browser-use/video-use](https://github.com/browser-use/video-use) — editing driven by a word-level transcript
- [HUANGCHIHHUNGLeo/claude-real-video](https://github.com/HUANGCHIHHUNGLeo/claude-real-video) — source breakdown, scene detection
- [bradautomates/claude-video](https://github.com/bradautomates/claude-video) — letting the agent look at video frame by frame
- [digitalsamba/claude-code-video-toolkit](https://github.com/digitalsamba/claude-code-video-toolkit) — transition library, the brand-profile idea
- [ronak-create/FableCut](https://github.com/ronak-create/FableCut) — the agent-driven browser timeline the optional editing tier is built around

## Licence

MIT — see [LICENSE](LICENSE).

The screenshots in this README come from a real project and are published with the consent of everyone who appears in them.
