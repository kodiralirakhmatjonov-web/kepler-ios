# Kepler Studio v0.2 engine (media excluded)

This portable source distribution intentionally excludes private original asset photos and third-party brand imagery.
The registry keeps expected names and SHA-256 hashes; supply the EXACT original media files at the registered paths in a private workspace before verify-assets/tests/render. Do not redistribute the originals by default.

Kepler Studio v0.2 requires a Python/FFmpeg environment on a server or runner. The iOS app offers project documentation/ZIP links, not an on-device editing runtime.
