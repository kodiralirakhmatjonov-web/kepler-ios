# Ownership of visual assets

The MIT license in this repository covers **code and documentation only**, not the PNG/JPEG illustrations under `assets/original`.

These files were supplied by the project creator as examples and are not offered for reuse under a general license. Some contain identifiable individuals or third-party marks. A public GitHub repository exposes them to anyone. Confirm permission to publish photos, personal names, and product/trademark materials before uploading.

`booking_reference.jpeg` is disabled by default and is only a visual reference. It must not be presented as an official partnership, endorsement, or live rating.

To keep personal or third-party media private, delete the corresponding asset and its entry in `assets/registry.json` **before publication** or switch to a private GitHub repository.
