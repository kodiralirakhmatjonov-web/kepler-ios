"""Production gates and provenance for Kepler Studio."""
import hashlib, json, tempfile, unittest
from pathlib import Path
from kepler_studio.assets import ROOT,load_registry,verify_assets
from kepler_studio.render import validate_plan
from kepler_studio.review import approve_plan
from kepler_studio.planner import guard_events

class ProductionTests(unittest.TestCase):
    def setUp(self):
        self.lib=load_registry()
        self.ev={'asset':'app','start':1.0,'end':3.5,'evidence':'iumrah ilovasi',
                 'motion':'slide_up_soft','display':'overlay','approved':False}

    def test_unapproved_cannot_become_final(self):
        with self.assertRaisesRegex(ValueError,'Unapproved'):
            validate_plan({'events':[self.ev]},self.lib,9)

    def test_preview_is_explicit(self):
        events=validate_plan({'events':[self.ev]},self.lib,9,allow_unapproved=True)
        self.assertEqual(len(events),1)

    def test_approval_requires_human_flag(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'draft.json';o=Path(td)/'approved.json'
            p.write_text(json.dumps({'events':[self.ev]}))
            with self.assertRaisesRegex(ValueError,'Human approval'):
                approve_plan(p,o,False)
            self.assertFalse(o.exists())
            data=approve_plan(p,o,True)
            self.assertTrue(data['events'][0]['approved'])
            self.assertFalse(json.loads(p.read_text())['events'][0]['approved'])
            self.assertEqual(1,len(validate_plan(data,self.lib,9)))

    def test_unregistered_motion_rejected(self):
        ev=dict(self.ev,approved=True,motion='generate_random_overlay')
        with self.assertRaisesRegex(ValueError,'Unregistered'):
            validate_plan({'events':[ev]},self.lib,9)

    def test_disabled_booking_never_rendered(self):
        ev=dict(self.ev,approved=True,asset='booking_reference')
        with self.assertRaises(ValueError):validate_plan({'events':[ev]},self.lib,9)

    def test_not_spontaneous_semantic_card(self):
        seg=[{'start':1.0,'end':5.0,'text':'Safar qanday boshlandi'}]
        proposal=[dict(self.ev,start=1.0,end=3.0,evidence='No such words')]
        self.assertEqual([],guard_events(proposal,seg,self.lib))

    def test_sources_lock_matches_eight_received_packages(self):
        lock=json.loads((ROOT/'integrations/sources.lock.json').read_text())
        self.assertEqual(8,len(lock['sources']))
        self.assertEqual(5,sum(s['method']=='bundled-curated' for s in lock['sources']))
        for s in lock['sources']:
            self.assertEqual(64,len(s['input_sha256']))
            if s['method']=='bundled-curated':
                self.assertTrue((ROOT/'upstream'/s['id']/'LICENSE').is_file())

    def test_original_hashes_still_verified(self):
        self.assertEqual(4,len(verify_assets()))

if __name__=='__main__':unittest.main()
