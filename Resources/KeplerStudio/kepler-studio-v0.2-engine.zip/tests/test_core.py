import json, unittest
from pathlib import Path
from kepler_studio.assets import ROOT,load_registry,verify_assets
from kepler_studio.planner import rules_plan,guard_events,segments_from_json
from kepler_studio.render import validate_plan

class KeplerCoreTests(unittest.TestCase):
    def setUp(self):self.assets=load_registry()
    def test_original_asset_integrity(self):self.assertEqual(len(verify_assets()),4)
    def test_reject_unverified_transcript_evidence(self):
        seg=[{'start':1,'end':4,'text':'We are talking about something else.'}]
        proposed=[{'asset':'app','start':1,'end':3,'evidence':'Now see our app'}]
        self.assertEqual([],guard_events(proposed,seg,self.assets))
    def test_no_spontaneous_cards(self):
        seg=[{'start':1,'end':4,'text':'Bugun havo yaxshi, salom.'}]
        self.assertEqual([],rules_plan(seg,self.assets))
    def test_speech_matching_and_original_file_selection(self):
        seg=segments_from_json(ROOT/'examples/transcript_example.json')
        events=rules_plan(seg,self.assets)
        self.assertEqual([e['asset'] for e in events],['app','guide','founder'])
        self.assertTrue(all('evidence' in e and not e['approved'] for e in events))
    def test_no_booking_brand_by_default(self):
        seg=[{'start':1,'end':4,'text':'Booking.com katalogi'}]
        self.assertEqual([],rules_plan(seg,self.assets))
    def test_reject_unknown_asset(self):
        with self.assertRaises(ValueError):
            validate_plan({'events':[{'asset':'invented','start':1,'end':3}]},self.assets,10)
    def test_reject_overlapping_assets(self):
        with self.assertRaises(ValueError):
            validate_plan({'events':[{'asset':'app','start':1,'end':4}, {'asset':'guide','start':3,'end':5}]},self.assets,10)
    def test_no_cropping_source_video_to_wrong_aspect(self):
        # Implementation contract checks aspect fit + pad, not aspect-breaking scale.
        src=(ROOT/'kepler_studio/render.py').read_text(encoding='utf-8')
        self.assertIn('force_original_aspect_ratio=decrease',src)
        self.assertIn('pad={width}:{height}',src)
if __name__=='__main__':unittest.main()
