# Motion Design Agent v2.0 — Implementation Plan

**Status:** AWAITING APPROVAL
**Created:** 2026-01-24
**Scope:** Expand from 32 to 53 skills with 14 new token files

---

## Requirements Restatement

Based on your expansion plan, the objectives are:

1. **Add 21 new skills** organized into 8 new categories (transforms, visibility, shape, effects, orchestration, space, specialized, production)
2. **Create 14 new token files** in W3C DTCG format
3. **Update manifest.json** to v2.0.0 with new skill taxonomy
4. **Maintain backward compatibility** — existing 12 original skills unchanged
5. **Follow existing patterns** — SKILL.md frontmatter, references/, token naming conventions
6. **Ensure cross-references** — skills reference each other, not duplicate

---

## Current State Analysis

### Existing Repository Structure
```
motion-design-agent/
├── SKILL.md (orchestrator)
├── manifest.json (v1.2.0)
├── tokens/ (14 files)
├── skills/ (32 skills)
├── presets/ (3 files)
├── templates/ (5 dirs)
└── references/ (4 files)
```

### Existing Skills (32)
- **Core:** motion-principles, accessibility
- **Tokens:** easing, duration
- **Patterns:** transitions, entrance-patterns, exit-patterns, scroll-animations
- **Disney Principles:** anticipation, squash-stretch, follow-through, secondary-action, exaggeration, arc-motion
- **Implementation:** lottie, remotion, tools, code-generation
- **Components:** component-animations, loading-states, gesture-motion, animation-recipes
- **Advanced:** 3d-transforms, motion-blur, frame-timing
- **Quality:** motion-audit, testing-patterns, platform-adaptation
- **Emotion:** emotion-mapping, emotion-selection

### Existing Token Files (14)
- motion.tokens.json, easing.tokens.json, duration.tokens.json, spring.tokens.json
- emotion.tokens.json, components.tokens.json, recipes.tokens.json
- anticipation.tokens.json, squash-stretch.tokens.json, follow-through.tokens.json, exaggeration.tokens.json
- motion-blur.tokens.json, motion-path.tokens.json, depth.tokens.json

---

## Gap Analysis

### Missing from Your Plan (Already Exist)
These skills in your proposal already exist in the repository:
- ✅ `3d-transforms/` → Already exists at `skills/3d-transforms/`
- ✅ `scroll-animations/` → Already exists at `skills/scroll-animations/`
- ✅ `loading-states/` → Already exists at `skills/loading-states/`
- ✅ `motion-blur/` → Already exists at `skills/motion-blur/`
- ✅ `depth.tokens.json` → Already exists at `tokens/depth.tokens.json`

### Truly New Skills Required (21)
From your plan, these are genuinely new:

**Transforms (3):**
- position/ (movement, paths, orbits)
- scale/ (grow, shrink, squash-stretch patterns)
- rotation/ (spin, flip, wobble)

**Visibility (3):**
- opacity/ (fade variations, flash, flicker)
- reveals/ (wipes, masks, draw-on)
- blur/ (extends motion-blur with more types)

**Shape & Path (3):**
- morphing/ (shape interpolation, blob)
- stroke/ (line animation, trim paths)
- masks/ (alpha, luma, track mattes)

**Effects (3):**
- particles/ (emitters, physics, trails)
- distortion/ (warp, glitch, liquify)
- glow-shadow/ (light effects, shadows, reflection)

**Orchestration (3):**
- sequencing/ (stagger, cascade, chain reactions)
- looping/ (cycles, oscillation, cinemagraph)
- procedural/ (noise, generative, randomness)

**Space & Camera (2):**
- camera/ (pan, zoom, dolly, tracking)
- (depth/ already exists)

**Specialized (4):**
- typography/ (kinetic type, character animation)
- ui-micro/ (hover, loaders, feedback states)
- scrollytelling/ (extends scroll-animations)
- attention/ (spotlight, callouts, guides)

**Production (2) — OPTIONAL:**
- compositing/ (blend modes, layering)
- cinematic/ (film effects, color grading)

---

## Implementation Phases

### Phase 1: Foundation (P0 Priority)
**Skills:** position, scale, rotation, sequencing
**Tokens:** position.tokens.json, scale.tokens.json, rotation.tokens.json, sequencing.tokens.json

These are foundational — all other skills depend on them.

**File Creation Order:**
1. `tokens/position.tokens.json`
2. `skills/position/SKILL.md`
3. `skills/position/references/path-types.md`
4. `tokens/scale.tokens.json`
5. `skills/scale/SKILL.md`
6. `skills/scale/references/transform-origin.md`
7. `tokens/rotation.tokens.json`
8. `skills/rotation/SKILL.md`
9. `skills/rotation/references/3d-rotation.md`
10. `tokens/sequencing.tokens.json`
11. `skills/sequencing/SKILL.md`
12. `skills/sequencing/references/stagger-algorithms.md`

### Phase 2: Visibility (P1 Priority)
**Skills:** opacity, reveals, blur (extends motion-blur)
**Tokens:** opacity.tokens.json, reveal.tokens.json, blur.tokens.json

**File Creation Order:**
1. `tokens/opacity.tokens.json`
2. `skills/opacity/SKILL.md`
3. `tokens/reveal.tokens.json`
4. `skills/reveals/SKILL.md`
5. `skills/reveals/references/wipe-patterns.md`
6. `tokens/blur.tokens.json`
7. `skills/blur/SKILL.md` (consolidates motion-blur + new blur types)

### Phase 3: Orchestration (P1 Priority)
**Skills:** looping, procedural
**Tokens:** looping.tokens.json, procedural.tokens.json

**File Creation Order:**
1. `tokens/looping.tokens.json`
2. `skills/looping/SKILL.md`
3. `skills/looping/references/seamless-loop.md`
4. `tokens/procedural.tokens.json`
5. `skills/procedural/SKILL.md`
6. `skills/procedural/references/noise-functions.md`

### Phase 4: Effects (P2 Priority)
**Skills:** particles, distortion, glow-shadow
**Tokens:** particles.tokens.json, distortion.tokens.json, glow-shadow.tokens.json

**File Creation Order:**
1. `tokens/particles.tokens.json`
2. `skills/particles/SKILL.md`
3. `skills/particles/references/emitter-types.md`
4. `tokens/distortion.tokens.json`
5. `skills/distortion/SKILL.md`
6. `skills/distortion/references/glitch-effects.md`
7. `tokens/glow-shadow.tokens.json`
8. `skills/glow-shadow/SKILL.md`

### Phase 5: Space & Camera (P2 Priority)
**Skills:** camera
**Tokens:** camera.tokens.json

**File Creation Order:**
1. `tokens/camera.tokens.json`
2. `skills/camera/SKILL.md`
3. `skills/camera/references/camera-movements.md`

### Phase 6: Shape & Path (P4 Priority)
**Skills:** morphing, stroke, masks
**Tokens:** (use existing motion-path.tokens.json, extend as needed)

**File Creation Order:**
1. `skills/morphing/SKILL.md`
2. `skills/morphing/references/vertex-animation.md`
3. `skills/stroke/SKILL.md`
4. `skills/stroke/references/trim-paths.md`
5. `skills/masks/SKILL.md`
6. `skills/masks/references/matte-types.md`

### Phase 7: Specialized (P3 Priority)
**Skills:** typography, ui-micro, scrollytelling, attention
**Tokens:** typography.tokens.json

**File Creation Order:**
1. `tokens/typography.tokens.json`
2. `skills/typography/SKILL.md`
3. `skills/typography/references/kinetic-type.md`
4. `skills/ui-micro/SKILL.md`
5. `skills/ui-micro/references/hover-patterns.md`
6. `skills/scrollytelling/SKILL.md`
7. `skills/scrollytelling/references/scroll-scrubbing.md`
8. `skills/attention/SKILL.md`
9. `skills/attention/references/spotlight-patterns.md`

### Phase 8: Production (P6 Priority — Optional)
**Skills:** compositing, cinematic
**Tokens:** None needed (use existing)

**File Creation Order:**
1. `skills/compositing/SKILL.md`
2. `skills/compositing/references/blend-modes.md`
3. `skills/cinematic/SKILL.md`
4. `skills/cinematic/references/color-grading.md`

### Phase 9: Manifest & Integration
1. Update `manifest.json` to v2.0.0
2. Update root `SKILL.md` orchestrator
3. Update `CLAUDE.md` with new skills
4. Add cross-references in existing skills
5. Create `presets/` updates for new tokens

---

## File Structure After Expansion

```
motion-design-agent/
├── SKILL.md (updated orchestrator)
├── manifest.json (v2.0.0)
├── CLAUDE.md (updated)
├── EXPANSION-PLAN.md (this file)
│
├── tokens/ (28 files: 14 existing + 14 new)
│   ├── [14 existing files]
│   ├── position.tokens.json (NEW)
│   ├── scale.tokens.json (NEW)
│   ├── rotation.tokens.json (NEW)
│   ├── opacity.tokens.json (NEW)
│   ├── reveal.tokens.json (NEW)
│   ├── blur.tokens.json (NEW)
│   ├── particles.tokens.json (NEW)
│   ├── distortion.tokens.json (NEW)
│   ├── glow-shadow.tokens.json (NEW)
│   ├── sequencing.tokens.json (NEW)
│   ├── looping.tokens.json (NEW)
│   ├── procedural.tokens.json (NEW)
│   ├── camera.tokens.json (NEW)
│   └── typography.tokens.json (NEW)
│
├── skills/ (53 skills: 32 existing + 21 new)
│   ├── [32 existing skills]
│   │
│   ├── position/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/path-types.md
│   │
│   ├── scale/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/transform-origin.md
│   │
│   ├── rotation/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/3d-rotation.md
│   │
│   ├── opacity/ (NEW)
│   │   └── SKILL.md
│   │
│   ├── reveals/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/wipe-patterns.md
│   │
│   ├── blur/ (NEW - consolidates motion-blur)
│   │   └── SKILL.md
│   │
│   ├── morphing/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/vertex-animation.md
│   │
│   ├── stroke/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/trim-paths.md
│   │
│   ├── masks/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/matte-types.md
│   │
│   ├── particles/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/emitter-types.md
│   │
│   ├── distortion/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/glitch-effects.md
│   │
│   ├── glow-shadow/ (NEW)
│   │   └── SKILL.md
│   │
│   ├── sequencing/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/stagger-algorithms.md
│   │
│   ├── looping/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/seamless-loop.md
│   │
│   ├── procedural/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/noise-functions.md
│   │
│   ├── camera/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/camera-movements.md
│   │
│   ├── typography/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/kinetic-type.md
│   │
│   ├── ui-micro/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/hover-patterns.md
│   │
│   ├── scrollytelling/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/scroll-scrubbing.md
│   │
│   ├── attention/ (NEW)
│   │   ├── SKILL.md
│   │   └── references/spotlight-patterns.md
│   │
│   ├── compositing/ (NEW - optional)
│   │   ├── SKILL.md
│   │   └── references/blend-modes.md
│   │
│   └── cinematic/ (NEW - optional)
│       ├── SKILL.md
│       └── references/color-grading.md
│
├── presets/ (updated)
│   ├── framer-motion-presets.ts (add new token imports)
│   ├── gsap-presets.js (add new token imports)
│   └── remotion-m3.ts (add new token imports)
│
└── templates/ (no changes)
```

---

## Token File Specifications

### 1. position.tokens.json
```json
{
  "$schema": "https://designtokens.org/schemas/draft-2/schema.json",
  "$description": "Position and translation tokens for movement animations",

  "motion": {
    "position": {
      "offset": {
        "micro": { "$value": "4px", "$type": "dimension" },
        "small": { "$value": "8px", "$type": "dimension" },
        "medium": { "$value": "16px", "$type": "dimension" },
        "large": { "$value": "32px", "$type": "dimension" },
        "xlarge": { "$value": "64px", "$type": "dimension" },
        "page": { "$value": "100%", "$type": "dimension" }
      },
      "path": {
        "linear": { "$value": "linear", "$type": "string" },
        "arc-radius": { "$value": "50%", "$type": "dimension" },
        "orbit-radius": { "$value": "100px", "$type": "dimension" }
      }
    }
  }
}
```

### 2. scale.tokens.json
```json
{
  "$schema": "https://designtokens.org/schemas/draft-2/schema.json",
  "$description": "Scale transform tokens including squash-stretch values",

  "motion": {
    "scale": {
      "values": {
        "none": { "$value": 0, "$type": "number" },
        "micro": { "$value": 0.95, "$type": "number" },
        "small": { "$value": 0.9, "$type": "number" },
        "medium": { "$value": 0.8, "$type": "number" },
        "normal": { "$value": 1, "$type": "number" },
        "emphasis": { "$value": 1.05, "$type": "number" },
        "large": { "$value": 1.1, "$type": "number" },
        "pop": { "$value": 1.2, "$type": "number" }
      },
      "squash-stretch": {
        "squash": { "$value": { "x": 1.2, "y": 0.8 }, "$type": "object" },
        "stretch": { "$value": { "x": 0.8, "y": 1.2 }, "$type": "object" }
      }
    }
  }
}
```

### 3. rotation.tokens.json
```json
{
  "$schema": "https://designtokens.org/schemas/draft-2/schema.json",
  "$description": "Rotation transform tokens for 2D and 3D rotation",

  "motion": {
    "rotation": {
      "angles": {
        "subtle": { "$value": "3deg", "$type": "dimension" },
        "small": { "$value": "15deg", "$type": "dimension" },
        "quarter": { "$value": "90deg", "$type": "dimension" },
        "half": { "$value": "180deg", "$type": "dimension" },
        "full": { "$value": "360deg", "$type": "dimension" }
      },
      "oscillation": {
        "wobble-amplitude": { "$value": "5deg", "$type": "dimension" },
        "pendulum-amplitude": { "$value": "30deg", "$type": "dimension" }
      }
    }
  }
}
```

### 4. sequencing.tokens.json
```json
{
  "$schema": "https://designtokens.org/schemas/draft-2/schema.json",
  "$description": "Stagger and sequencing tokens for orchestrated animations",

  "motion": {
    "stagger": {
      "micro": { "$value": "30ms", "$type": "duration" },
      "small": { "$value": "50ms", "$type": "duration" },
      "medium": { "$value": "80ms", "$type": "duration" },
      "large": { "$value": "120ms", "$type": "duration" },
      "dramatic": { "$value": "200ms", "$type": "duration" }
    },
    "overlap": {
      "none": { "$value": 0, "$type": "number" },
      "slight": { "$value": 0.2, "$type": "number" },
      "half": { "$value": 0.5, "$type": "number" },
      "heavy": { "$value": 0.8, "$type": "number" }
    }
  }
}
```

### 5-14. (Additional token files as specified in your plan)

---

## SKILL.md Template

Each new skill will follow this template:

```markdown
---
name: [skill-name]
description: [1-line: WHAT it does. WHEN to use it. References tokens and standards.]
---

# [Skill Name]

## Standards Reference

| Standard | Documentation |
|----------|---------------|
| W3C DTCG | designtokens.org |
| Material Design 3 | m3.material.io/styles/motion |

## Quick Reference

Load from: `tokens/[skill-name].tokens.json`

| Token | Value | Use |
|-------|-------|-----|
| ... | ... | ... |

## Patterns

### [Pattern 1]
[Description]

**Implementation:**
```css
/* CSS */
```
```javascript
// GSAP
```
```tsx
// Framer Motion
```

### [Pattern 2]
...

## Selection Guide

```
[Decision tree or flowchart]
```

## Reduced Motion

[Safe alternatives for prefers-reduced-motion]

## Cross-References

- See `[related-skill]/` for [relationship]
- Tokens: `{motion.category.token-name}`

## References

- `references/[detail-file].md` — [Description]
```

---

## Cross-Reference Updates Required

### Existing Skills to Update

1. **easing/SKILL.md**
   - Add references to: position, scale, rotation, opacity

2. **duration/SKILL.md**
   - Add references to: sequencing (stagger intervals)

3. **motion-principles/SKILL.md**
   - Add references to: scale (squash-stretch), sequencing (anticipation/follow-through)

4. **accessibility/SKILL.md**
   - Add reduced-motion sections for all new skills

5. **entrance-patterns/SKILL.md**
   - Add references to: position, scale, sequencing, reveals

6. **exit-patterns/SKILL.md**
   - Add references to: position, scale, opacity

7. **scroll-animations/SKILL.md**
   - Add references to: scrollytelling, sequencing, camera

8. **motion-blur/SKILL.md**
   - Consolidate with new blur/ skill or deprecate in favor of blur/

9. **loading-states/SKILL.md**
   - Add references to: looping, ui-micro

---

## Risks & Mitigations

| Risk | Level | Mitigation |
|------|-------|------------|
| Token namespace collisions | LOW | Use consistent `motion.category.name` pattern |
| Skill duplication | MEDIUM | Review each new skill against existing 32 skills |
| Breaking changes | LOW | All existing token paths remain valid |
| Large manifest update | LOW | Automated validation via schema |
| Cross-reference inconsistencies | MEDIUM | Create reference map, validate during implementation |

---

## Validation Checklist

For each new skill:
- [ ] SKILL.md frontmatter valid (name 1-64 chars, description includes WHAT + WHEN)
- [ ] Token file follows W3C DTCG schema
- [ ] Token naming uses `{motion.category.name}` pattern
- [ ] Cross-references to existing skills added
- [ ] Reduced motion alternatives included
- [ ] Implementation examples for CSS, GSAP, Framer Motion, Remotion
- [ ] References directory if content exceeds 5000 tokens

For manifest update:
- [ ] Version bumped to 2.0.0
- [ ] All new skills listed with correct paths
- [ ] All new tokens listed with correct paths
- [ ] Cross-references section updated

---

## Implementation Order Summary

| Phase | Priority | Skills | Token Files | Dependencies |
|-------|----------|--------|-------------|--------------|
| 1 | P0 | position, scale, rotation, sequencing | 4 | None (foundation) |
| 2 | P1 | opacity, reveals, blur | 3 | Phase 1 |
| 3 | P1 | looping, procedural | 2 | Phase 1 |
| 4 | P2 | particles, distortion, glow-shadow | 3 | Phase 1, 3 |
| 5 | P2 | camera | 1 | Phase 1 |
| 6 | P4 | morphing, stroke, masks | 0 | Phase 1, 2 |
| 7 | P3 | typography, ui-micro, scrollytelling, attention | 1 | Phase 1, 2, 3 |
| 8 | P6 | compositing, cinematic | 0 | All (optional) |
| 9 | - | manifest, orchestrator, cross-refs | 0 | All phases |

---

## Excluded from Scope

Based on analysis, these items from your plan are **NOT needed**:

1. **skew/** — Low usage, can be covered in rotation/ or 3d-transforms/
2. **texture/** — Better as reference in effects skills, not standalone
3. **audio-reactive/** — Niche use case, defer to v2.1
4. **character/** — Niche use case (rigging, walk cycles), defer to v2.1
5. **export/** — Already partially covered in lottie/ and remotion/

---

## Next Steps After Approval

1. Create Phase 1 token files (position, scale, rotation, sequencing)
2. Create Phase 1 SKILL.md files with references
3. Update manifest.json incrementally after each phase
4. Run validation after each phase
5. Proceed to next phase

---

**WAITING FOR CONFIRMATION**: Proceed with this implementation plan? (yes/no/modify)
