# Glitch Effects Reference

Comprehensive glitch effect implementations.

## RGB Channel Separation

### Basic CSS Split

```css
.rgb-split {
  position: relative;
  color: white;
}

.rgb-split::before,
.rgb-split::after {
  content: attr(data-text);
  position: absolute;
  inset: 0;
}

.rgb-split::before {
  color: #ff0000;
  mix-blend-mode: screen;
  animation: rgb-shift-r 0.1s infinite;
}

.rgb-split::after {
  color: #00ffff;
  mix-blend-mode: screen;
  animation: rgb-shift-b 0.12s infinite;
}

@keyframes rgb-shift-r {
  0%, 100% { transform: translate(-2px, 0); }
  50% { transform: translate(2px, 1px); }
}

@keyframes rgb-shift-b {
  0%, 100% { transform: translate(2px, 0); }
  50% { transform: translate(-2px, -1px); }
}
```

### Canvas RGB Split

```javascript
function rgbSplit(ctx, offsetX, offsetY) {
  const { width, height } = ctx.canvas;
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  // Create separate channel arrays
  const red = new Uint8ClampedArray(width * height);
  const green = new Uint8ClampedArray(width * height);
  const blue = new Uint8ClampedArray(width * height);

  for (let i = 0, j = 0; i < data.length; i += 4, j++) {
    red[j] = data[i];
    green[j] = data[i + 1];
    blue[j] = data[i + 2];
  }

  // Offset red channel
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const sx = Math.max(0, Math.min(width - 1, x - offsetX));
      const si = y * width + sx;
      const di = (y * width + x) * 4;
      data[di] = red[si];
    }
  }

  // Offset blue channel
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const sx = Math.max(0, Math.min(width - 1, x + offsetX));
      const si = y * width + sx;
      const di = (y * width + x) * 4;
      data[di + 2] = blue[si];
    }
  }

  ctx.putImageData(imageData, 0, 0);
}
```

## Slice Displacement

### Horizontal Slices

```javascript
function sliceGlitch(ctx, sliceCount, maxOffset, probability) {
  const { width, height } = ctx.canvas;
  const sliceHeight = Math.ceil(height / sliceCount);

  for (let i = 0; i < sliceCount; i++) {
    if (Math.random() > probability) continue;

    const y = i * sliceHeight;
    const h = Math.min(sliceHeight, height - y);
    const offset = (Math.random() - 0.5) * 2 * maxOffset;

    const sliceData = ctx.getImageData(0, y, width, h);
    ctx.clearRect(0, y, width, h);
    ctx.putImageData(sliceData, offset, y);
  }
}
```

### Variable Height Slices

```javascript
function randomSliceGlitch(ctx, count, maxHeight, maxOffset) {
  const { width, height } = ctx.canvas;

  for (let i = 0; i < count; i++) {
    const y = Math.random() * height;
    const h = 1 + Math.random() * maxHeight;
    const offset = (Math.random() - 0.5) * 2 * maxOffset;

    const sliceData = ctx.getImageData(0, y, width, h);
    ctx.putImageData(sliceData, offset, y);
  }
}
```

## Block Corruption

### Random Block Displacement

```javascript
function blockGlitch(ctx, blockSize, probability, maxOffset) {
  const { width, height } = ctx.canvas;
  const cols = Math.ceil(width / blockSize);
  const rows = Math.ceil(height / blockSize);

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      if (Math.random() > probability) continue;

      const x = col * blockSize;
      const y = row * blockSize;
      const w = Math.min(blockSize, width - x);
      const h = Math.min(blockSize, height - y);

      const offsetX = (Math.random() - 0.5) * 2 * maxOffset;
      const offsetY = (Math.random() - 0.5) * 2 * maxOffset;

      const blockData = ctx.getImageData(x, y, w, h);
      ctx.putImageData(blockData, x + offsetX, y + offsetY);
    }
  }
}
```

### Block Swap

```javascript
function blockSwap(ctx, blockSize, swapCount) {
  const { width, height } = ctx.canvas;
  const cols = Math.floor(width / blockSize);
  const rows = Math.floor(height / blockSize);

  for (let i = 0; i < swapCount; i++) {
    // Pick two random blocks
    const x1 = Math.floor(Math.random() * cols) * blockSize;
    const y1 = Math.floor(Math.random() * rows) * blockSize;
    const x2 = Math.floor(Math.random() * cols) * blockSize;
    const y2 = Math.floor(Math.random() * rows) * blockSize;

    // Swap blocks
    const block1 = ctx.getImageData(x1, y1, blockSize, blockSize);
    const block2 = ctx.getImageData(x2, y2, blockSize, blockSize);

    ctx.putImageData(block1, x2, y2);
    ctx.putImageData(block2, x1, y1);
  }
}
```

## Color Corruption

### Channel Swap

```javascript
function channelSwap(ctx, probability) {
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const data = imageData.data;

  for (let i = 0; i < data.length; i += 4) {
    if (Math.random() < probability) {
      // Randomly swap channels
      const swapType = Math.floor(Math.random() * 3);
      let temp;

      switch (swapType) {
        case 0: // R <-> G
          temp = data[i];
          data[i] = data[i + 1];
          data[i + 1] = temp;
          break;
        case 1: // G <-> B
          temp = data[i + 1];
          data[i + 1] = data[i + 2];
          data[i + 2] = temp;
          break;
        case 2: // R <-> B
          temp = data[i];
          data[i] = data[i + 2];
          data[i + 2] = temp;
          break;
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}
```

### Posterize/Quantize

```javascript
function posterize(ctx, levels) {
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const data = imageData.data;
  const step = 255 / (levels - 1);

  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.round(data[i] / step) * step;
    data[i + 1] = Math.round(data[i + 1] / step) * step;
    data[i + 2] = Math.round(data[i + 2] / step) * step;
  }

  ctx.putImageData(imageData, 0, 0);
}
```

## Pixel Sorting

Datamosh-style pixel sorting.

```javascript
function pixelSort(ctx, threshold, direction = 'horizontal') {
  const { width, height } = ctx.canvas;
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  function getBrightness(i) {
    return (data[i] + data[i + 1] + data[i + 2]) / 3;
  }

  if (direction === 'horizontal') {
    for (let y = 0; y < height; y++) {
      let start = -1;

      for (let x = 0; x <= width; x++) {
        const i = (y * width + x) * 4;
        const bright = x < width ? getBrightness(i) : 0;

        if (bright > threshold && start === -1) {
          start = x;
        } else if ((bright <= threshold || x === width) && start !== -1) {
          // Sort segment
          const segment = [];
          for (let sx = start; sx < x; sx++) {
            const si = (y * width + sx) * 4;
            segment.push({
              r: data[si], g: data[si + 1], b: data[si + 2], a: data[si + 3],
              bright: getBrightness(si)
            });
          }

          segment.sort((a, b) => a.bright - b.bright);

          for (let sx = start; sx < x; sx++) {
            const si = (y * width + sx) * 4;
            const pixel = segment[sx - start];
            data[si] = pixel.r;
            data[si + 1] = pixel.g;
            data[si + 2] = pixel.b;
            data[si + 3] = pixel.a;
          }

          start = -1;
        }
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}
```

## Noise Static

### Static Overlay

```javascript
function staticNoise(ctx, intensity, animated = false) {
  const { width, height } = ctx.canvas;
  const imageData = ctx.createImageData(width, height);
  const data = imageData.data;

  for (let i = 0; i < data.length; i += 4) {
    const value = Math.random() * 255;
    data[i] = value;
    data[i + 1] = value;
    data[i + 2] = value;
    data[i + 3] = intensity * 255;
  }

  ctx.globalCompositeOperation = 'overlay';
  ctx.putImageData(imageData, 0, 0);
  ctx.globalCompositeOperation = 'source-over';
}
```

### Scanline Noise

```javascript
function scanlineNoise(ctx, lineHeight, variance) {
  const { width, height } = ctx.canvas;
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  for (let y = 0; y < height; y += lineHeight) {
    const brightness = 1 + (Math.random() - 0.5) * variance;

    for (let dy = 0; dy < lineHeight && y + dy < height; dy++) {
      for (let x = 0; x < width; x++) {
        const i = ((y + dy) * width + x) * 4;
        data[i] = Math.min(255, data[i] * brightness);
        data[i + 1] = Math.min(255, data[i + 1] * brightness);
        data[i + 2] = Math.min(255, data[i + 2] * brightness);
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
}
```

## Combined Glitch Effect

Full glitch with multiple effects.

```javascript
class GlitchEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.sourceCanvas = document.createElement('canvas');
    this.sourceCtx = this.sourceCanvas.getContext('2d');
  }

  capture(source) {
    this.sourceCanvas.width = source.width;
    this.sourceCanvas.height = source.height;
    this.sourceCtx.drawImage(source, 0, 0);
  }

  apply(config = {}) {
    const {
      rgbOffset = 3,
      sliceProbability = 0.3,
      sliceOffset = 20,
      blockProbability = 0.1,
      noisIntensity = 0.05
    } = config;

    // Reset from source
    this.ctx.drawImage(this.sourceCanvas, 0, 0);

    // Apply effects in order
    if (Math.random() < 0.7) {
      rgbSplit(this.ctx, rgbOffset, 0);
    }

    if (Math.random() < 0.5) {
      sliceGlitch(this.ctx, 10, sliceOffset, sliceProbability);
    }

    if (Math.random() < 0.3) {
      blockGlitch(this.ctx, 20, blockProbability, 30);
    }

    staticNoise(this.ctx, noisIntensity);
  }

  animate(fps = 10) {
    setInterval(() => {
      this.apply({
        rgbOffset: 2 + Math.random() * 4,
        sliceProbability: 0.2 + Math.random() * 0.3
      });
    }, 1000 / fps);
  }
}
```

## CSS-Only Glitch Animation

```css
@keyframes glitch-anim {
  0% {
    clip-path: inset(40% 0 61% 0);
    transform: translate(-2px, 2px);
  }
  2% {
    clip-path: inset(92% 0 1% 0);
    transform: translate(2px, -2px);
  }
  4% {
    clip-path: inset(43% 0 1% 0);
    transform: translate(-1px, 1px);
  }
  /* ... more keyframes for variety */
  100% {
    clip-path: inset(40% 0 61% 0);
    transform: translate(0);
  }
}

.glitch-text {
  position: relative;
  animation: glitch-skew 1s infinite linear alternate-reverse;
}

.glitch-text::before,
.glitch-text::after {
  content: attr(data-text);
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: inherit;
}

.glitch-text::before {
  left: 2px;
  text-shadow: -2px 0 red;
  animation: glitch-anim 0.3s infinite linear alternate-reverse;
}

.glitch-text::after {
  left: -2px;
  text-shadow: 2px 0 cyan;
  animation: glitch-anim 0.3s infinite linear alternate-reverse;
  animation-delay: 0.15s;
}

@keyframes glitch-skew {
  0% { transform: skew(0deg); }
  20% { transform: skew(2deg); }
  40% { transform: skew(-1deg); }
  60% { transform: skew(1deg); }
  80% { transform: skew(-2deg); }
  100% { transform: skew(0deg); }
}
```
