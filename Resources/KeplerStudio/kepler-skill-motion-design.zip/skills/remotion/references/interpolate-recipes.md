# Remotion Interpolate Recipes

## Basic Interpolation

```javascript
import { interpolate, useCurrentFrame } from 'remotion';

const frame = useCurrentFrame();

// Opacity fade in (0-30 frames)
const opacity = interpolate(frame, [0, 30], [0, 1]);

// With easing
import { Easing } from 'remotion';

const opacity = interpolate(
  frame,
  [0, 30],
  [0, 1],
  { easing: Easing.bezier(0.05, 0.7, 0.1, 1) }
);
```

## Common Patterns

### Fade In

```javascript
const fadeIn = (frame, startFrame, durationFrames) =>
  interpolate(
    frame,
    [startFrame, startFrame + durationFrames],
    [0, 1],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );
```

### Fade Out

```javascript
const fadeOut = (frame, startFrame, durationFrames) =>
  interpolate(
    frame,
    [startFrame, startFrame + durationFrames],
    [1, 0],
    {
      easing: Easing.bezier(0.3, 0, 0.8, 0.15),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );
```

### Slide Up

```javascript
const slideUp = (frame, startFrame, durationFrames, distance = 20) =>
  interpolate(
    frame,
    [startFrame, startFrame + durationFrames],
    [distance, 0],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );
```

### Scale In

```javascript
const scaleIn = (frame, startFrame, durationFrames) =>
  interpolate(
    frame,
    [startFrame, startFrame + durationFrames],
    [0.95, 1],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );
```

## Combined Animations

### Fade + Slide

```javascript
const FadeSlide = ({ children, delay = 0 }) => {
  const frame = useCurrentFrame();

  const opacity = interpolate(
    frame - delay,
    [0, 8],
    [0, 1],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );

  const translateY = interpolate(
    frame - delay,
    [0, 8],
    [16, 0],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp'
    }
  );

  return (
    <div style={{ opacity, transform: `translateY(${translateY}px)` }}>
      {children}
    </div>
  );
};
```

## Stagger Pattern

```javascript
const StaggeredList = ({ items }) => {
  const frame = useCurrentFrame();
  const staggerDelay = 2; // frames

  return (
    <div>
      {items.map((item, index) => {
        const itemDelay = index * staggerDelay;
        const opacity = interpolate(
          frame - itemDelay,
          [0, 8],
          [0, 1],
          { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
        );
        const y = interpolate(
          frame - itemDelay,
          [0, 8],
          [16, 0],
          { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
        );

        return (
          <div
            key={item.id}
            style={{ opacity, transform: `translateY(${y}px)` }}
          >
            {item.content}
          </div>
        );
      })}
    </div>
  );
};
```

## Extrapolation

```javascript
// Clamp (default behavior with option)
extrapolateLeft: 'clamp',   // Don't go below input range
extrapolateRight: 'clamp',  // Don't go above input range

// Extend (continue the interpolation)
extrapolateLeft: 'extend',
extrapolateRight: 'extend',

// Identity (use input value directly)
extrapolateLeft: 'identity',
extrapolateRight: 'identity',
```

## Token Integration

```javascript
import tokens from '../tokens/motion.tokens.json';
import { Easing } from 'remotion';

const msToFrames = (ms, fps = 30) => Math.round((ms / 1000) * fps);

const getM3Easing = (tokenName) => {
  const [x1, y1, x2, y2] = tokens.motion.easing[tokenName].$value;
  return Easing.bezier(x1, y1, x2, y2);
};

const getM3Duration = (tokenName, fps = 30) => {
  const ms = parseInt(tokens.motion.duration[tokenName].$value);
  return msToFrames(ms, fps);
};

// Usage
const opacity = interpolate(
  frame,
  [0, getM3Duration('medium-1')],
  [0, 1],
  { easing: getM3Easing('emphasized-decelerate') }
);
```
