# Remotion Spring Configurations

## Basic Spring

```javascript
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';

const MyComponent = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const scale = spring({
    frame,
    fps,
    config: {
      damping: 15,
      stiffness: 150,
      mass: 1
    }
  });

  return <div style={{ transform: `scale(${scale})` }} />;
};
```

## Token-Based Springs

```javascript
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import tokens from '../tokens/spring.tokens.json';

const useM3Spring = (tokenName, options = {}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const config = tokens.motion.spring[tokenName].$value;

  return spring({
    frame: frame - (options.delay || 0),
    fps,
    config: {
      damping: config.damping,
      stiffness: config.stiffness,
      mass: config.mass
    },
    from: options.from ?? 0,
    to: options.to ?? 1
  });
};

// Usage
const scale = useM3Spring('enter');
const bounce = useM3Spring('bouncy', { delay: 10 });
```

## Spring Presets

### Standard
Balanced spring for most UI animations.
```javascript
{ damping: 15, stiffness: 150, mass: 1 }
```

### Snappy
Quick, responsive feel for small elements.
```javascript
{ damping: 25, stiffness: 300, mass: 0.5 }
```

### Bouncy
Playful bounce for expressive moments.
```javascript
{ damping: 10, stiffness: 180, mass: 1 }
```

### Gentle
Slow settle for large elements.
```javascript
{ damping: 25, stiffness: 100, mass: 1.2 }
```

### Enter
Matches M3 emphasized-decelerate feel.
```javascript
{ damping: 20, stiffness: 180, mass: 1 }
```

## Spring Parameters Explained

### Damping
How quickly the spring settles.
- Low (5-10): More oscillation, bouncy
- Medium (15-20): Balanced
- High (25+): Quick settle, less bounce

### Stiffness
How "tight" the spring is.
- Low (50-100): Slow, gentle
- Medium (150-200): Balanced
- High (300+): Quick, snappy

### Mass
The "weight" of the animated object.
- Low (0.5): Light, responsive
- Medium (1): Normal
- High (1.5+): Heavy, slower

## Visual Characteristics

| Preset | Feel | Use Case |
|--------|------|----------|
| Standard | Balanced | General UI |
| Snappy | Quick, no bounce | Buttons, controls |
| Bouncy | Playful | Celebrations, fun |
| Gentle | Slow, smooth | Large elements |
| Enter | Natural decel | Entrances |

## From/To Values

```javascript
// Scale from 0 to 1
const scale = spring({ frame, fps, config, from: 0, to: 1 });

// Opacity from 0 to 1
const opacity = spring({ frame, fps, config, from: 0, to: 1 });

// Position from 100 to 0
const y = spring({ frame, fps, config, from: 100, to: 0 });
```

## Combining Springs

```javascript
const AnimatedElement = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const scale = spring({
    frame,
    fps,
    config: { damping: 20, stiffness: 180, mass: 1 }
  });

  const opacity = spring({
    frame,
    fps,
    config: { damping: 25, stiffness: 200, mass: 0.8 }
  });

  const y = spring({
    frame,
    fps,
    config: { damping: 18, stiffness: 160, mass: 1 },
    from: 20,
    to: 0
  });

  return (
    <div style={{
      transform: `scale(${scale}) translateY(${y}px)`,
      opacity
    }}>
      Content
    </div>
  );
};
```

## Spring vs Interpolate

| Spring | Interpolate |
|--------|-------------|
| Physics-based | Keyframe-based |
| Duration determined by config | Explicit duration |
| Natural feel | Precise control |
| Can overshoot | No overshoot (unless designed) |

Use **spring** for:
- Entrances that should feel natural
- Interactive-feeling animations
- Bouncy/playful effects

Use **interpolate** for:
- Precise timing requirements
- Matching specific durations
- Linear or controlled easing
