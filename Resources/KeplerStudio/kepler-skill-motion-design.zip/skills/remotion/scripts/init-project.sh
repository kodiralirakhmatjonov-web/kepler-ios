#!/bin/bash

# Remotion Project Initialization Script
# Creates a new Remotion project with M3 motion tokens

set -e

PROJECT_NAME=${1:-"my-remotion-project"}

echo "Creating Remotion project: $PROJECT_NAME"

# Create project
npx create-video@latest $PROJECT_NAME --template blank

cd $PROJECT_NAME

# Create tokens directory
mkdir -p src/tokens

# Copy motion tokens (adjust path as needed)
echo "Creating motion tokens..."

cat > src/tokens/motion.ts << 'EOF'
import { Easing } from 'remotion';

// M3 Duration Tokens (in milliseconds)
export const duration = {
  'short-1': 50,
  'short-2': 100,
  'short-3': 150,
  'short-4': 200,
  'medium-1': 250,
  'medium-2': 300,
  'medium-3': 350,
  'medium-4': 400,
  'long-1': 450,
  'long-2': 500,
  'long-3': 550,
  'long-4': 600,
} as const;

// M3 Easing Tokens
export const easing = {
  standard: Easing.bezier(0.2, 0, 0, 1),
  emphasized: Easing.bezier(0.2, 0, 0, 1),
  'emphasized-decelerate': Easing.bezier(0.05, 0.7, 0.1, 1),
  'emphasized-accelerate': Easing.bezier(0.3, 0, 0.8, 0.15),
  'standard-decelerate': Easing.bezier(0, 0, 0, 1),
  'standard-accelerate': Easing.bezier(0.3, 0, 1, 1),
  linear: Easing.bezier(0, 0, 1, 1),
} as const;

// Spring Tokens
export const spring = {
  standard: { damping: 15, stiffness: 150, mass: 1 },
  snappy: { damping: 25, stiffness: 300, mass: 0.5 },
  bouncy: { damping: 10, stiffness: 180, mass: 1 },
  gentle: { damping: 25, stiffness: 100, mass: 1.2 },
  enter: { damping: 20, stiffness: 180, mass: 1 },
} as const;

// Utility: Convert ms to frames
export const msToFrames = (ms: number, fps: number = 30): number => {
  return Math.round((ms / 1000) * fps);
};

// Utility: Get duration in frames
export const getDurationFrames = (
  token: keyof typeof duration,
  fps: number = 30
): number => {
  return msToFrames(duration[token], fps);
};
EOF

# Create utility hooks
cat > src/hooks/useM3Animation.ts << 'EOF'
import { useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import { duration, easing, getDurationFrames } from '../tokens/motion';

type DurationToken = keyof typeof duration;
type EasingToken = keyof typeof easing;

interface AnimationOptions {
  duration?: DurationToken;
  easing?: EasingToken;
  delay?: number;
  from?: number;
  to?: number;
}

export const useM3Interpolate = (options: AnimationOptions = {}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const {
    duration: durationToken = 'medium-1',
    easing: easingToken = 'emphasized-decelerate',
    delay = 0,
    from = 0,
    to = 1,
  } = options;

  const durationFrames = getDurationFrames(durationToken, fps);
  const easingFn = easing[easingToken];

  return interpolate(
    frame - delay,
    [0, durationFrames],
    [from, to],
    {
      easing: easingFn,
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );
};
EOF

echo "Project created successfully!"
echo ""
echo "Next steps:"
echo "  cd $PROJECT_NAME"
echo "  npm start"
echo ""
echo "Token usage:"
echo "  import { duration, easing, spring } from './tokens/motion';"
echo "  import { useM3Interpolate } from './hooks/useM3Animation';"
EOF
