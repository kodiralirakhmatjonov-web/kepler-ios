# Story Beat Types for Motion Design

Discrete narrative moments that compose into larger arc structures.

## Beat Taxonomy

### Setup Beat

**Purpose:** Establish context, prepare for action

**Motion profile:**
- Intensity: 0.2-0.4
- Duration: ~150ms
- Easing: standard-decelerate

**Examples:**
- Button slight scale-down before press
- Card subtle lift on hover
- Container border highlight before interaction

**Code pattern:**
```javascript
// Setup beat
gsap.to(element, {
  scale: 0.98,
  opacity: 0.9,
  duration: 0.15,
  ease: 'power1.out'
});
```

### Build Beat

**Purpose:** Increase tension, add complexity

**Motion profile:**
- Intensity: 0.4-0.7
- Duration: ~200ms
- Easing: standard

**Examples:**
- Loading spinner appearing
- Progress indicator filling
- Form validation starting

**Code pattern:**
```javascript
// Build beat
gsap.to(element, {
  scale: 1.02,
  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
  duration: 0.2,
  ease: 'power2.inOut'
});
```

### Payoff Beat

**Purpose:** Deliver the expected result

**Motion profile:**
- Intensity: 0.8-1.0
- Duration: ~250ms
- Easing: spring/emphasized

**Examples:**
- Success checkmark appearing
- Correct answer highlight
- Task completion animation

**Code pattern:**
```javascript
// Payoff beat
gsap.to(element, {
  scale: 1.1,
  backgroundColor: '#4CAF50',
  duration: 0.25,
  ease: 'back.out(2)'
});

// Or with spring
gsap.to(element, {
  scale: 1.1,
  duration: 0.3,
  ease: 'elastic.out(1, 0.5)'
});
```

### Surprise Beat

**Purpose:** Unexpected moment, delight or redirect

**Motion profile:**
- Intensity: 0.9-1.0
- Duration: ~180ms
- Easing: emphasized (sharp attack)

**Examples:**
- Easter egg reveal
- Unexpected reward
- Error shake (negative surprise)

**Code pattern:**
```javascript
// Surprise beat (positive)
gsap.to(element, {
  scale: 1.2,
  rotate: 5,
  duration: 0.18,
  ease: 'power4.out'
});

// Surprise beat (negative)
gsap.to(element, {
  x: '+=10',
  duration: 0.08,
  ease: 'power2.inOut',
  repeat: 3,
  yoyo: true
});
```

### Breathe Beat

**Purpose:** Pause for absorption

**Motion profile:**
- Intensity: 0.1-0.2
- Duration: ~400ms
- Easing: linear (hold)

**Examples:**
- Post-success pause before transition
- Reading moment after content reveal
- Decision point before next step

**Code pattern:**
```javascript
// Breathe beat (subtle pulse)
gsap.to(element, {
  opacity: 0.95,
  scale: 1.01,
  duration: 0.4,
  ease: 'sine.inOut',
  yoyo: true,
  repeat: 1
});
```

### Echo Beat

**Purpose:** Subtle callback to earlier motion

**Motion profile:**
- Intensity: 0.2-0.4
- Duration: ~200ms
- Easing: ease-out

**Examples:**
- Subtle pulse after action
- Icon settles after transform
- Container gentle scale after content load

**Code pattern:**
```javascript
// Echo beat
gsap.to(element, {
  scale: 1,
  duration: 0.2,
  ease: 'power2.out'
});
```

## Beat Sequences

### Success Sequence

```
setup → build → payoff → breathe → echo
150ms   200ms   250ms    400ms   200ms
= 1200ms total
```

### Error Sequence

```
build → surprise → breathe → setup (recovery)
200ms    180ms     400ms      150ms
= 930ms total
```

### Discovery Sequence

```
setup → build → build → surprise → payoff → breathe
150ms   200ms   200ms    180ms     250ms    400ms
= 1380ms total
```

### Quick Feedback Sequence

```
setup → payoff → echo
75ms    150ms    100ms
= 325ms total
```

## Beat Intensity Chart

```
     1.0 ─┼───────────────╮─╭───────────
         │               │ │ payoff
     0.8 ─┼───────────────┼─┤ surprise
         │               │ │
     0.6 ─┼───────────────┼─┤
         │         ╭─────╯ │
     0.4 ─┼─────────┤ build│────────────
         │    ╭────╯      │       echo
     0.2 ─┼────┤ setup    │ breathe ╭──
         │    │           │         │
     0.0 ─┼────┴───────────┴─────────┴──
          0   100  200  300  400  500 ms
```

## Combining Beats

Beats can be chained, overlapped, or parallelized:

### Sequential Beats
```javascript
const tl = gsap.timeline();
tl.add(setupBeat)
  .add(buildBeat)
  .add(payoffBeat);
```

### Overlapping Beats
```javascript
const tl = gsap.timeline();
tl.add(setupBeat)
  .add(buildBeat, '-=0.05') // Overlap 50ms
  .add(payoffBeat, '-=0.1');
```

### Parallel Beats
```javascript
const tl = gsap.timeline();
tl.add(primaryPayoff)
  .add(secondaryEcho, '<'); // Start at same time
```

## Accessibility Considerations

For `prefers-reduced-motion: reduce`:

| Beat | Reduced Alternative |
|------|---------------------|
| setup | Skip or instant |
| build | Minimal or skip |
| payoff | Single opacity change |
| surprise | Icon change only |
| breathe | Hold only (no motion) |
| echo | Skip |
