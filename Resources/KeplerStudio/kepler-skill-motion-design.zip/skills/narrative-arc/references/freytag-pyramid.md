# Freytag's Pyramid for UI Motion

Gustav Freytag's dramatic structure adapted for motion design.

## Classical Structure

```
                    CLIMAX
                     /\
                    /  \
                   /    \
      RISING     /      \     FALLING
      ACTION    /        \    ACTION
               /          \
              /            \
   EXPOSITION               RESOLUTION
```

## UI Motion Adaptation

### Exposition (15% of duration)

**Purpose:** Orient the user, establish context

**Classical drama:** Introduce characters, setting, situation
**UI motion:** Fade in container, establish spatial relationships

**Motion characteristics:**
- Low intensity (0.3)
- Gentle deceleration
- Primarily opacity and subtle position

**Example:** Modal background scrim fades in, establishes depth context

### Rising Action (25% of duration)

**Purpose:** Build engagement, increase complexity

**Classical drama:** Complications arise, tension builds
**UI motion:** Elements enter, content reveals, interactions enable

**Motion characteristics:**
- Increasing intensity (0.4 → 0.7)
- Standard easing, building momentum
- Staggered element entrances

**Example:** Modal content slides up, form fields appear in sequence

### Climax (15% of duration)

**Purpose:** Peak moment, maximum impact

**Classical drama:** Turning point, moment of highest tension
**UI motion:** Primary action completes, key state change

**Motion characteristics:**
- Maximum intensity (1.0)
- Emphasized easing, spring dynamics
- Bold transforms, color shifts

**Example:** Submit button transforms to success state, checkmark animates

### Falling Action (25% of duration)

**Purpose:** Consequences unfold, energy dissipates

**Classical drama:** Results of climax play out
**UI motion:** Secondary animations, ripple effects

**Motion characteristics:**
- Decreasing intensity (0.6 → 0.3)
- Deceleration easing
- Consequence chains, cascades

**Example:** Form collapses, success message expands, related elements update

### Resolution (20% of duration)

**Purpose:** New equilibrium, rest state

**Classical drama:** New normal established
**UI motion:** Settle to final state, cleanup

**Motion characteristics:**
- Low intensity (0.2)
- Smooth ease-out
- Minimal movement, stability signals

**Example:** Page settles, focus returns, ready for next action

## Compressed Structures

### 3-Phase (Micro Arc)

For interactions under 500ms:

```
INCIDENT → CLIMAX → RESOLUTION
  25%       35%       40%
```

Used for: Button presses, toggles, micro-interactions

### 4-Phase (Short Arc)

For interactions 500ms-1000ms:

```
EXPOSITION → RISING → CLIMAX → RESOLUTION
    15%        30%      25%        30%
```

Used for: Modal opens, card expands, dropdowns

### 5-Phase (Full Arc)

For interactions over 1000ms:

```
EXPOSITION → RISING → CLIMAX → FALLING → RESOLUTION
    12%        25%      18%      22%        23%
```

Used for: Page transitions, onboarding sequences, complex flows

## Intensity Mapping

| Phase | Intensity Range | Easing Family |
|-------|-----------------|---------------|
| Exposition | 0.2-0.4 | decelerate |
| Rising Action | 0.4-0.7 | standard |
| Climax | 0.8-1.0 | emphasized/spring |
| Falling Action | 0.4-0.6 | decelerate |
| Resolution | 0.1-0.3 | ease-out |

## Anti-Patterns

### Climax Too Long
- Issue: Exhausts user attention
- Fix: Keep climax brief but impactful (≤20% of total)

### No Resolution
- Issue: Feels unfinished, anxious
- Fix: Always include settling phase

### Monotonic Intensity
- Issue: Feels mechanical, boring
- Fix: Vary intensity across phases

### Missing Exposition
- Issue: Jarring, disorienting
- Fix: Brief context-setting even for fast interactions
