---
name: lottie
description: Lottie animation format specification and usage. Use when exporting animations as Lottie JSON, working with dotLottie packages, or understanding Lottie capabilities and limitations. References LAC Lottie Spec v1.0 and dotLottie v2.0.
---

# Lottie Specification

Industry-standard vector animation format.

## Standards Reference

| Standard | Authority | Version |
|----------|-----------|---------|
| Lottie Spec | Linux Foundation LAC | v1.0 (2024) |
| dotLottie | LottieFiles | v2.0 |
| IANA Registration | IANA | MIME: video/lottie+json |

## Format Details

```
File Extension: .json (legacy), .lot (IANA registered)
MIME Type: video/lottie+json
Compression: None (JSON), gzip optional
```

## Capabilities

- Vector graphics (shapes, paths, masks)
- Keyframe animation
- Easing curves (cubic bezier)
- Layer compositions
- Text layers
- Image assets (embedded or external)
- Expressions (limited)

## Limitations

- No native interactivity (requires external code)
- Limited After Effects feature support
- No state machines (use Rive for that)
- Some effects not supported (3D, certain blurs)

## Creation Tools

| Tool | Export Method |
|------|---------------|
| After Effects | Bodymovin plugin |
| LottieFiles Editor | Native export |
| Lottielab | Native export |
| Figma | Plugins (LottieFiles, Phase) |
| Rive | Export option |

## dotLottie v2.0 Structure

```
.lottie (ZIP archive)
├── manifest.json          # Required
├── animations/
│   ├── animation_1.json
│   └── animation_2.json
├── images/                # Optional
└── themes/                # v2.0
```

## When to Use Lottie vs Rive

| Use Case | Lottie | Rive |
|----------|--------|------|
| Pre-designed playback | Best | Good |
| Interactive elements | Limited | Best |
| After Effects workflow | Best | Manual |
| File size priority | Good | Best (10-15x smaller) |
| State machines | No | Built-in |
| Cross-platform | Excellent | Good |

## Implementation

### Web (lottie-web)
```javascript
import lottie from 'lottie-web';

lottie.loadAnimation({
  container: document.getElementById('container'),
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'animation.json'
});
```

### React
```jsx
import Lottie from 'lottie-react';
import animationData from './animation.json';

<Lottie animationData={animationData} loop={true} />
```

### Remotion
```jsx
import { Lottie } from '@remotion/lottie';
import animationData from './animation.json';

<Lottie animationData={animationData} />
```

See `references/lottie-spec.md` for full specification details.
See `references/dotlottie-spec.md` for packaging format.
See `references/supported-features.md` for AE compatibility matrix.
