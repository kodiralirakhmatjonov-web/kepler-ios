# dotLottie Specification

## Overview

dotLottie is a container format for Lottie animations, providing packaging, theming, and multi-animation support.

## Version

- **Current**: v2.0
- **Maintained by**: LottieFiles
- **File Extension**: .lottie

## File Structure

```
animation.lottie (ZIP archive)
├── manifest.json           # Required
├── animations/
│   ├── animation_1.json
│   └── animation_2.json
├── images/                 # Optional
│   ├── image_0.png
│   └── image_1.jpg
├── themes/                 # v2.0
│   └── dark.json
└── states/                 # v2.0
    └── state_machine.json
```

## manifest.json

```json
{
  "version": "2.0",
  "generator": "LottieFiles",
  "animations": [
    {
      "id": "animation_1",
      "src": "animations/animation_1.json",
      "name": "Loading",
      "loop": true,
      "autoplay": true,
      "direction": 1,
      "speed": 1,
      "themeColor": "#FF0000"
    }
  ],
  "themes": [
    {
      "id": "dark",
      "src": "themes/dark.json"
    }
  ],
  "states": [
    {
      "id": "interactive",
      "src": "states/state_machine.json"
    }
  ]
}
```

## Animation Properties

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| id | string | required | Unique identifier |
| src | string | required | Path to JSON |
| name | string | "" | Display name |
| loop | boolean | false | Loop playback |
| autoplay | boolean | false | Auto-start |
| direction | number | 1 | 1 = forward, -1 = reverse |
| speed | number | 1 | Playback speed |
| themeColor | string | null | Primary theme color |

## Theming (v2.0)

Theme files allow color customization:

```json
{
  "colors": {
    "primary": "#FF0000",
    "secondary": "#00FF00",
    "background": "#FFFFFF"
  }
}
```

Colors are mapped via slot IDs in the animation JSON.

## State Machines (v2.0)

```json
{
  "descriptor": {
    "id": "state_machine",
    "initial": "idle"
  },
  "states": {
    "idle": {
      "animation": "idle_anim",
      "transitions": [
        { "type": "OnPointerEnter", "toState": "hover" }
      ]
    },
    "hover": {
      "animation": "hover_anim",
      "transitions": [
        { "type": "OnPointerExit", "toState": "idle" },
        { "type": "OnPointerDown", "toState": "pressed" }
      ]
    }
  }
}
```

## Benefits Over Plain JSON

| Feature | JSON | dotLottie |
|---------|------|-----------|
| File size | Larger | ~50% smaller (compressed) |
| Multiple animations | Multiple files | Single file |
| Theming | Manual | Built-in |
| State machines | External code | Built-in |
| Image embedding | Base64 (bloat) | Separate files |
| Metadata | Limited | Full manifest |

## Implementation

```javascript
import { DotLottiePlayer } from '@dotlottie/player-component';

// Web component
<dotlottie-player
  src="animation.lottie"
  autoplay
  loop
></dotlottie-player>

// React
import { DotLottieReact } from '@lottiefiles/dotlottie-react';

<DotLottieReact
  src="animation.lottie"
  autoplay
  loop
/>
```
