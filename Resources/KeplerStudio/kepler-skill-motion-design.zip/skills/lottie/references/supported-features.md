# After Effects Feature Support

## Layer Support

| Feature | Supported | Notes |
|---------|-----------|-------|
| Shape Layers | Yes | Full support |
| Solid Layers | Yes | Full support |
| Image Layers | Yes | Embedded or external |
| Text Layers | Partial | Basic text, limited fonts |
| Precomps | Yes | Full support |
| Null Objects | Yes | Full support |
| Adjustment Layers | No | Not supported |
| Camera Layers | Partial | Limited 3D |
| Audio Layers | No | Not supported |

## Shape Layer Features

| Feature | Supported | Notes |
|---------|-----------|-------|
| Rectangle | Yes | |
| Ellipse | Yes | |
| Polystar | Yes | Star, polygon |
| Path | Yes | Bezier paths |
| Fill | Yes | Solid color |
| Stroke | Yes | With dash support |
| Gradient Fill | Yes | Linear, radial |
| Gradient Stroke | Yes | Linear, radial |
| Merge Paths | Partial | Basic merge modes |
| Offset Paths | Yes | |
| Trim Paths | Yes | |
| Repeater | Yes | |
| Round Corners | Yes | |
| Group | Yes | |

## Transform Properties

| Feature | Supported | Notes |
|---------|-----------|-------|
| Position | Yes | |
| Scale | Yes | |
| Rotation | Yes | |
| Opacity | Yes | |
| Anchor Point | Yes | |
| Skew | No | Not supported |
| 3D Transform | Partial | Limited |

## Effects

| Effect | Supported | Notes |
|--------|-----------|-------|
| Drop Shadow | No | Use shape workaround |
| Gaussian Blur | No | Not supported |
| Glow | No | Not supported |
| Fill | Partial | Layer styles limited |
| Stroke | Partial | Layer styles limited |
| Tint | No | |
| Tritone | No | |
| Pro Levels | No | |

## Masks

| Feature | Supported | Notes |
|---------|-----------|-------|
| Add | Yes | |
| Subtract | Yes | |
| Intersect | Yes | |
| Difference | Partial | Limited support |
| Mask Expansion | Yes | |
| Mask Feather | No | Not supported |

## Expressions

| Expression | Supported | Notes |
|------------|-----------|-------|
| Property links | Yes | |
| Wiggle | Partial | Baked to keyframes |
| Time | Partial | Basic |
| Math | Partial | Basic operations |
| loopOut/loopIn | Yes | |
| Complex JS | No | Not supported |
| External data | No | Not supported |

## Text Features

| Feature | Supported | Notes |
|---------|-----------|-------|
| Font family | Partial | Web-safe or embedded |
| Font style | Partial | Bold, italic |
| Font size | Yes | |
| Text color | Yes | |
| Character spacing | Yes | |
| Line spacing | Yes | |
| Text animators | Partial | Basic animators |
| Per-character 3D | No | |

## Best Practices

1. **Use shape layers** instead of effects
2. **Avoid expressions** — bake to keyframes
3. **Flatten complex groups** where possible
4. **Embed fonts** or use web-safe alternatives
5. **Test in lottie-web** during production
6. **Keep frame rate at 30 or 60** fps
7. **Optimize paths** — reduce bezier points
