# Lottie Specification Reference

## Overview

Lottie is a JSON-based animation format created by Airbnb and now maintained by the Linux Foundation Lottie Animation Community (LAC).

## Specification Version

- **Current**: v1.0 (2024)
- **IANA MIME Type**: video/lottie+json
- **File Extension**: .json (legacy), .lot (registered)

## JSON Structure

```json
{
  "v": "5.7.4",        // Bodymovin version
  "fr": 30,            // Frame rate
  "ip": 0,             // In-point (start frame)
  "op": 90,            // Out-point (end frame)
  "w": 1920,           // Width
  "h": 1080,           // Height
  "nm": "Animation",   // Name
  "ddd": 0,            // 3D (0 = false)
  "assets": [],        // External assets
  "layers": []         // Animation layers
}
```

## Layer Types

| Type ID | Type | Description |
|---------|------|-------------|
| 0 | Precomp | Composition reference |
| 1 | Solid | Solid color fill |
| 2 | Image | Image layer |
| 3 | Null | Null/empty layer |
| 4 | Shape | Vector shapes |
| 5 | Text | Text layer |
| 6 | Audio | Audio (limited support) |
| 13 | Camera | 3D camera |

## Supported Easing

Lottie supports cubic bezier easing via keyframe interpolation:

```json
{
  "i": { "x": [0.05], "y": [0.7] },   // In tangent
  "o": { "x": [0.1], "y": [1] }       // Out tangent
}
```

This maps to CSS `cubic-bezier(0.1, 0.7, 0.05, 1)`.

## Shape Types

| Shape | Code | Description |
|-------|------|-------------|
| Rectangle | rc | Rectangular shape |
| Ellipse | el | Ellipse/circle |
| Star | sr | Star/polygon |
| Path | sh | Bezier path |
| Fill | fl | Solid fill |
| Stroke | st | Stroke |
| Gradient Fill | gf | Gradient fill |
| Gradient Stroke | gs | Gradient stroke |
| Group | gr | Shape group |
| Transform | tr | Transform |
| Trim Path | tm | Path trimming |
| Merge | mm | Merge paths |

## Transform Properties

```json
{
  "a": { "a": 0, "k": [0, 0] },     // Anchor point
  "p": { "a": 0, "k": [0, 0] },     // Position
  "s": { "a": 0, "k": [100, 100] }, // Scale (%)
  "r": { "a": 0, "k": 0 },          // Rotation (degrees)
  "o": { "a": 0, "k": 100 }         // Opacity (%)
}
```

## Keyframe Structure

```json
{
  "t": 0,                    // Time (frame)
  "s": [0],                  // Start value
  "e": [100],                // End value (optional)
  "i": { "x": [0.2], "y": [1] },    // In tangent
  "o": { "x": [0.8], "y": [0] },    // Out tangent
  "h": 0                     // Hold (0 = false)
}
```

## Expressions

Limited expression support:
- Property links
- Simple math
- Wiggle (via keyframes)
- Time remapping

NOT supported:
- Complex JavaScript
- External data
- Most After Effects expressions
