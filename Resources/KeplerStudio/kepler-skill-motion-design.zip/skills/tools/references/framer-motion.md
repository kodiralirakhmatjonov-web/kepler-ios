# Framer Motion Reference

## Overview

Framer Motion is a declarative animation library for React with gesture support and layout animations.

## Installation

```bash
npm install framer-motion
```

## Basic Animation

```jsx
import { motion } from 'framer-motion';

// Animate prop
<motion.div
  animate={{ x: 100, opacity: 1 }}
  transition={{ duration: 0.25 }}
/>

// Initial + animate
<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }}
/>
```

## Using M3 Easing

```jsx
import tokens from '../tokens/easing.tokens.json';

const m3Enter = tokens.motion.easing['emphasized-decelerate'].$value;
const m3Exit = tokens.motion.easing['emphasized-accelerate'].$value;

<motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  exit={{ opacity: 0 }}
  transition={{
    duration: 0.25,
    ease: m3Enter
  }}
/>
```

## Variants

```jsx
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.25,
      ease: [0.05, 0.7, 0.1, 1]
    }
  }
};

<motion.ul variants={containerVariants} initial="hidden" animate="visible">
  {items.map(item => (
    <motion.li key={item.id} variants={itemVariants}>
      {item.name}
    </motion.li>
  ))}
</motion.ul>
```

## AnimatePresence

```jsx
import { motion, AnimatePresence } from 'framer-motion';

<AnimatePresence>
  {isVisible && (
    <motion.div
      key="modal"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    />
  )}
</AnimatePresence>
```

## Layout Animation

```jsx
// Automatic layout animation
<motion.div layout>
  {isExpanded && <ExpandedContent />}
</motion.div>

// Shared layout animation
<motion.div layoutId="card-1">
  <Card />
</motion.div>
```

## Spring Animation

```jsx
import tokens from '../tokens/spring.tokens.json';

const springConfig = tokens.motion.spring.enter.$value;

<motion.div
  animate={{ scale: 1 }}
  transition={{
    type: 'spring',
    damping: springConfig.damping,
    stiffness: springConfig.stiffness,
    mass: springConfig.mass
  }}
/>
```

## Gestures

```jsx
<motion.button
  whileHover={{ scale: 1.05 }}
  whileTap={{ scale: 0.95 }}
  transition={{ duration: 0.15 }}
/>

// Drag
<motion.div
  drag
  dragConstraints={{ left: 0, right: 100 }}
  onDragEnd={(e, info) => console.log(info.point)}
/>
```

## Reduced Motion

```jsx
import { useReducedMotion } from 'framer-motion';

const Component = () => {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      animate={{
        opacity: 1,
        y: shouldReduceMotion ? 0 : 20
      }}
      transition={{
        duration: shouldReduceMotion ? 0.1 : 0.25
      }}
    />
  );
};
```

## Hooks

```jsx
// Animation controls
const controls = useAnimation();
await controls.start({ opacity: 1 });

// In view
const ref = useRef(null);
const isInView = useInView(ref);

// Scroll
const { scrollYProgress } = useScroll();
const opacity = useTransform(scrollYProgress, [0, 1], [0, 1]);
```
