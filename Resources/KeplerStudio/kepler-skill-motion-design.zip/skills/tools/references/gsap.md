# GSAP Reference

## Overview

GSAP (GreenSock Animation Platform) is a professional-grade animation library for complex sequences and timeline-based animations.

## Installation

```bash
npm install gsap
```

## Basic Animation

```javascript
import gsap from 'gsap';

// Simple tween
gsap.to('.element', {
  x: 100,
  opacity: 1,
  duration: 0.3,
  ease: 'power2.out'
});

// From tween
gsap.from('.element', {
  y: 20,
  opacity: 0,
  duration: 0.25
});

// FromTo tween
gsap.fromTo('.element',
  { opacity: 0, y: 20 },
  { opacity: 1, y: 0, duration: 0.25 }
);
```

## Using M3 Easing

```javascript
import gsap from 'gsap';
import tokens from '../tokens/easing.tokens.json';

// Register custom ease
const [x1, y1, x2, y2] = tokens.motion.easing['emphasized-decelerate'].$value;
gsap.registerPlugin(CustomEase);
CustomEase.create('m3-enter', `M0,0 C${x1},${y1} ${x2},${y2} 1,1`);

// Or use inline
gsap.to('.element', {
  x: 100,
  ease: `cubic-bezier(${x1},${y1},${x2},${y2})`
});
```

## Timeline

```javascript
const tl = gsap.timeline({
  defaults: { duration: 0.3, ease: 'power2.out' }
});

tl.from('.title', { opacity: 0, y: 20 })
  .from('.subtitle', { opacity: 0, y: 20 }, '-=0.1')
  .from('.cta', { opacity: 0, scale: 0.9 }, '-=0.1');

// Timeline controls
tl.play();
tl.pause();
tl.reverse();
tl.restart();
```

## Position Parameter

```javascript
tl.to('.a', { x: 100 })
  .to('.b', { x: 100 }, '+=0.5')   // 0.5s after previous
  .to('.c', { x: 100 }, '-=0.25')  // 0.25s before previous ends
  .to('.d', { x: 100 }, '<')       // Same start as previous
  .to('.e', { x: 100 }, '<0.1')    // 0.1s after previous starts
  .to('.f', { x: 100 }, 1)         // At 1 second absolute
  .to('.g', { x: 100 }, 'label')   // At label position
```

## ScrollTrigger

```javascript
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);

gsap.to('.element', {
  x: 500,
  scrollTrigger: {
    trigger: '.section',
    start: 'top center',
    end: 'bottom center',
    scrub: true
  }
});
```

## Stagger

```javascript
gsap.from('.item', {
  opacity: 0,
  y: 20,
  stagger: 0.05,  // 50ms between each
  duration: 0.25
});

// Advanced stagger
gsap.from('.item', {
  opacity: 0,
  stagger: {
    each: 0.05,
    from: 'center',  // or 'start', 'end', 'edges', 'random'
    grid: 'auto'     // for grid layouts
  }
});
```

## Callbacks

```javascript
gsap.to('.element', {
  x: 100,
  onStart: () => console.log('Started'),
  onUpdate: () => console.log('Updating'),
  onComplete: () => console.log('Done'),
  onReverseComplete: () => console.log('Reversed')
});
```

## Reduced Motion

```javascript
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

gsap.to('.element', {
  x: prefersReduced ? 0 : 100,
  opacity: 1,
  duration: prefersReduced ? 0.1 : 0.3
});
```

## Common Eases

| GSAP Ease | Similar to |
|-----------|------------|
| power2.out | M3 standard |
| power3.out | M3 emphasized-decelerate |
| power2.in | M3 emphasized-accelerate |
| none | linear |
| back.out(1.7) | Overshoot |
| elastic.out(1, 0.3) | Bouncy |
