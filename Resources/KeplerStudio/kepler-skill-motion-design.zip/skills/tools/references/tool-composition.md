# Tool Composition Patterns

## Overview

Sometimes one tool isn't enough. These patterns combine tools for capabilities neither has alone.

## Lottie + GSAP ScrollTrigger

**Use case:** Designer creates Lottie, you need scroll-driven playback.

```javascript
import lottie from 'lottie-web';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const anim = lottie.loadAnimation({
  container: document.getElementById('lottie'),
  renderer: 'svg',
  loop: false,
  autoplay: false,
  path: 'animation.json'
});

anim.addEventListener('DOMLoaded', () => {
  const totalFrames = anim.totalFrames;

  // Scrub Lottie with ScrollTrigger
  ScrollTrigger.create({
    trigger: '#section',
    start: 'top center',
    end: 'bottom center',
    scrub: true,
    onUpdate: (self) => {
      const frame = Math.floor(self.progress * (totalFrames - 1));
      anim.goToAndStop(frame, true);
    }
  });
});
```

**When to use:** Pre-designed animation that needs scroll control.

**Alternative:** If you need state machines, consider Rive instead.

## Lottie + Framer Motion

**Use case:** Lottie icon in a Framer Motion animated container.

```jsx
import { motion } from 'framer-motion';
import Lottie from 'lottie-react';
import iconAnimation from './icon.json';

const AnimatedButton = () => (
  <motion.button
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    transition={{ duration: 0.15 }}
  >
    <Lottie
      animationData={iconAnimation}
      loop={true}
      style={{ width: 24, height: 24 }}
    />
    <span>Click me</span>
  </motion.button>
);
```

**When to use:** Lottie for the icon, Framer for the container interaction.

## Lottie + Framer Motion (Scroll-Controlled)

```jsx
import { useScroll, useTransform } from 'framer-motion';
import Lottie from 'lottie-react';
import { useRef, useEffect } from 'react';
import animationData from './animation.json';

const ScrollLottie = () => {
  const containerRef = useRef(null);
  const lottieRef = useRef(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start']
  });

  useEffect(() => {
    return scrollYProgress.on('change', (progress) => {
      if (lottieRef.current) {
        const totalFrames = lottieRef.current.getDuration(true);
        const frame = Math.floor(progress * totalFrames);
        lottieRef.current.goToAndStop(frame, true);
      }
    });
  }, [scrollYProgress]);

  return (
    <div ref={containerRef} style={{ height: '200vh' }}>
      <Lottie
        lottieRef={lottieRef}
        animationData={animationData}
        autoplay={false}
        loop={false}
      />
    </div>
  );
};
```

## Rive + Scroll Events

**Use case:** Interactive Rive animation triggered by scroll position.

```jsx
import { useRive, useStateMachineInput } from '@rive-app/react-canvas';
import { useEffect } from 'react';

const ScrollRive = () => {
  const { rive, RiveComponent } = useRive({
    src: 'animation.riv',
    stateMachines: 'ScrollMachine',
    autoplay: true
  });

  const progressInput = useStateMachineInput(
    rive,
    'ScrollMachine',
    'scrollProgress'
  );

  useEffect(() => {
    const handleScroll = () => {
      if (progressInput) {
        const scrollPercent = window.scrollY /
          (document.body.scrollHeight - window.innerHeight);
        progressInput.value = scrollPercent;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [progressInput]);

  return <RiveComponent />;
};
```

**When to use:** Rive state machine responds to scroll-driven input.

## GSAP + Framer Motion

**Use case:** Complex timeline sequences in a Framer Motion React app.

```jsx
import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import gsap from 'gsap';

const ComplexAnimation = ({ isVisible }) => {
  const containerRef = useRef(null);

  useEffect(() => {
    if (isVisible && containerRef.current) {
      // Complex GSAP timeline after Framer entrance
      const tl = gsap.timeline({ delay: 0.3 });
      tl.from('.char', {
        opacity: 0,
        y: 20,
        stagger: 0.03,
        duration: 0.25
      });
    }
  }, [isVisible]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          ref={containerRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {/* GSAP animates these after entrance */}
          {'Hello'.split('').map((char, i) => (
            <span key={i} className="char">{char}</span>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};
```

**When to use:**
- Framer Motion for mount/unmount (AnimatePresence)
- GSAP for complex internal sequences (timelines, staggers)

## Decision: When to Hand Off

| Scenario | Primary Tool | Hand Off To |
|----------|--------------|-------------|
| Designer delivers Lottie, needs scroll | Lottie | GSAP ScrollTrigger |
| Designer delivers Lottie, needs state | — | Rebuild in Rive |
| React app needs timeline | Framer Motion | GSAP for complex sequences |
| Rive needs scroll input | Rive | Vanilla scroll listener |
| Video needs scroll scrub | HTML5 Video | GSAP ScrollTrigger |

## Anti-Patterns

| Don't | Why | Instead |
|-------|-----|---------|
| GSAP for simple React hover | Overkill | Framer Motion or CSS |
| Lottie for interactive button | No state machine | Rive |
| Multiple animation libs on same element | Conflicts | Pick one per element |
| Framer for video scrubbing | Not designed for it | GSAP ScrollTrigger |

## Bundle Size Consideration

| Tool | Size | Notes |
|------|------|-------|
| Framer Motion | ~30kb | Already in most React apps |
| GSAP Core | ~25kb | Add ScrollTrigger: +10kb |
| lottie-web | ~50kb | Consider lottie-light (~25kb) |
| Rive runtime | ~150kb | Worth it for interactivity |

**Recommendation:** If React app already has Framer Motion, add GSAP only for ScrollTrigger or complex timelines. Don't add both for simple animations.
