# Rive Reference

## Overview

Rive is an animation tool and runtime with built-in state machines, making it ideal for interactive animations.

## Key Advantages

- **State machines** — Built-in interactive logic
- **Small file sizes** — 10-15x smaller than Lottie
- **Real-time interactivity** — Native event handling
- **Design tool** — Rive editor for creation

## Installation

```bash
npm install @rive-app/react-canvas
# or
npm install @rive-app/canvas
```

## Basic Usage (React)

```jsx
import { useRive } from '@rive-app/react-canvas';

const MyAnimation = () => {
  const { RiveComponent } = useRive({
    src: 'animation.riv',
    autoplay: true
  });

  return <RiveComponent />;
};
```

## State Machines

```jsx
import { useRive, useStateMachineInput } from '@rive-app/react-canvas';

const InteractiveAnimation = () => {
  const { rive, RiveComponent } = useRive({
    src: 'button.riv',
    stateMachines: 'State Machine 1',
    autoplay: true
  });

  const hoverInput = useStateMachineInput(rive, 'State Machine 1', 'hover');
  const pressInput = useStateMachineInput(rive, 'State Machine 1', 'pressed');

  return (
    <RiveComponent
      onMouseEnter={() => hoverInput && (hoverInput.value = true)}
      onMouseLeave={() => hoverInput && (hoverInput.value = false)}
      onMouseDown={() => pressInput && pressInput.fire()}
    />
  );
};
```

## Input Types

| Type | Description | Usage |
|------|-------------|-------|
| Boolean | True/false state | `input.value = true` |
| Number | Numeric value | `input.value = 0.5` |
| Trigger | Fire once | `input.fire()` |

## Playback Control

```jsx
const { rive } = useRive({ src: 'animation.riv' });

// Play/pause
rive.play();
rive.pause();

// Specific animation
rive.play('walk');
rive.pause('walk');

// Reset
rive.reset();

// Playback direction
rive.play('animation', { direction: -1 }); // reverse
```

## Event Listeners

```jsx
import { useRive } from '@rive-app/react-canvas';
import { EventType } from '@rive-app/canvas';

const { rive } = useRive({
  src: 'animation.riv',
  onStateChange: (event) => {
    console.log('State changed:', event.data);
  }
});

// Rive events
rive.on(EventType.RiveEvent, (event) => {
  console.log('Rive event:', event);
});
```

## When to Use Rive

| Use Case | Rive | Lottie |
|----------|------|--------|
| Interactive buttons | Best | Limited |
| Character animations | Best | Good |
| Loading indicators | Good | Good |
| After Effects workflow | No | Best |
| State-based UI | Best | No |
| Gesture response | Best | External |

## File Size Comparison

| Animation | Lottie | Rive |
|-----------|--------|------|
| Simple icon | 5KB | 0.5KB |
| Complex character | 50KB | 5KB |
| Multi-state button | 20KB | 2KB |

## Text Support

```jsx
const { rive } = useRive({ src: 'text.riv' });

// Update text at runtime
const textRun = rive.artboard.textRun('MyText');
textRun.text = 'Updated text';
```

## Reduced Motion

```jsx
const Component = () => {
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const { RiveComponent } = useRive({
    src: prefersReduced ? 'static.riv' : 'animated.riv',
    autoplay: !prefersReduced
  });

  return <RiveComponent />;
};
```
