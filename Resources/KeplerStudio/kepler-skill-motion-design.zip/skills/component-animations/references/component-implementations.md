# Component Animation Implementations

Detailed code examples for all component animations.

## Button

### Hover State

```css
/* CSS */
.button {
  transition: transform var(--duration-short-3) var(--ease-standard-decelerate),
              box-shadow var(--duration-short-3) var(--ease-standard-decelerate);
}

.button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-elevation-1);
}

/* Elegant variation */
.button--elegant:hover {
  transform: none;
  box-shadow: var(--shadow-elevation-1);
}

/* Playful variation */
.button--playful:hover {
  transform: translateY(-4px) rotate(1deg);
}

/* Bold variation */
.button--bold:hover {
  transform: scale(1.02);
}
```

### Press State

```css
/* CSS */
.button:active {
  transform: scale(0.95);
  transition-duration: var(--duration-short-2);
}

/* Playful with spring */
.button--playful:active {
  transform: scale(0.92);
  transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
}
```

```typescript
// Framer Motion
const buttonVariants = {
  idle: { scale: 1, y: 0 },
  hover: { scale: 1, y: -2 },
  press: {
    scale: 0.95,
    transition: { duration: 0.2, ease: [0.05, 0.7, 0.1, 1] }
  }
};

// Playful variation
const playfulButtonVariants = {
  hover: { scale: 1, y: -4, rotate: 1 },
  press: {
    scale: 0.92,
    transition: { type: 'spring', damping: 10, stiffness: 200 }
  }
};
```

### Focus State

```css
.button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px var(--color-primary-alpha);
  animation: focus-pulse 1.5s ease-in-out infinite;
}

@keyframes focus-pulse {
  0%, 100% { box-shadow: 0 0 0 3px var(--color-primary-alpha); }
  50% { box-shadow: 0 0 0 5px var(--color-primary-alpha-light); }
}

@media (prefers-reduced-motion: reduce) {
  .button:focus-visible {
    animation: none;
  }
}
```

### Loading State

```css
.button--loading {
  position: relative;
  color: transparent;
  pointer-events: none;
}

.button--loading::after {
  content: '';
  position: absolute;
  width: 16px;
  height: 16px;
  border: 2px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

---

## Card

### Hover State

```css
.card {
  transition: transform var(--duration-short-3) var(--ease-standard-decelerate),
              box-shadow var(--duration-short-3) var(--ease-standard-decelerate);
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-elevation-2);
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce) {
  .card:hover {
    transform: none;
    box-shadow: var(--shadow-elevation-2);
  }
}
```

```typescript
// Framer Motion
const cardVariants = {
  idle: {
    y: 0,
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
  },
  hover: {
    y: -4,
    boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
    transition: { duration: 0.15, ease: [0, 0, 0, 1] }
  }
};
```

### Entrance Animation

```typescript
// Framer Motion - Card entrance
const cardEntranceVariants = {
  hidden: { opacity: 0, y: 16, scale: 0.98 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }
  }
};
```

### Dragging State

```typescript
// Framer Motion - Draggable card
<motion.div
  drag
  dragConstraints={constraintsRef}
  whileDrag={{
    scale: 1.02,
    rotate: 2,
    boxShadow: '0 16px 40px rgba(0,0,0,0.15)',
    opacity: 0.9
  }}
/>
```

---

## Modal

### Opening Animation

```css
/* Backdrop */
.modal-backdrop {
  opacity: 0;
  backdrop-filter: blur(0);
  transition: opacity var(--duration-medium-1) var(--ease-standard),
              backdrop-filter var(--duration-medium-1) var(--ease-standard);
}

.modal-backdrop--open {
  opacity: 1;
  backdrop-filter: blur(4px);
}

/* Content */
.modal-content {
  opacity: 0;
  transform: scale(0.95) translateY(16px);
  transition: all var(--duration-medium-1) var(--ease-emphasized-decelerate);
}

.modal-content--open {
  opacity: 1;
  transform: scale(1) translateY(0);
}
```

```typescript
// Framer Motion
const modalVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 16 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: { duration: 0.2, ease: [0.3, 0, 0.8, 0.15] }
  }
};

const backdropVariants = {
  hidden: { opacity: 0, backdropFilter: 'blur(0px)' },
  visible: {
    opacity: 1,
    backdropFilter: 'blur(4px)',
    transition: { duration: 0.25 }
  }
};
```

```typescript
// Remotion
export const Modal: React.FC<{ frame: number; isOpen: boolean }> = ({
  frame,
  isOpen
}) => {
  const progress = spring({
    frame: isOpen ? frame : 30 - frame,
    fps: 30,
    config: { damping: 20, stiffness: 180 }
  });

  return (
    <>
      <div style={{ opacity: progress * 0.5 }} className="backdrop" />
      <div
        style={{
          opacity: progress,
          transform: `scale(${interpolate(progress, [0, 1], [0.95, 1])}) translateY(${interpolate(progress, [0, 1], [16, 0])}px)`
        }}
        className="modal-content"
      >
        {children}
      </div>
    </>
  );
};
```

---

## Toast / Notification

### Success Toast

```css
@keyframes toast-success-enter {
  0% {
    opacity: 0;
    transform: translateY(20px) scale(0.95);
  }
  60% {
    transform: translateY(-2px) scale(1.02);
  }
  100% {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

.toast--success {
  animation: toast-success-enter 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* Checkmark draw animation */
.toast__check {
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
  animation: checkmark-draw 0.2s 0.1s ease-out forwards;
}

@keyframes checkmark-draw {
  to { stroke-dashoffset: 0; }
}
```

### Error Toast

```css
.toast--error {
  animation: toast-enter 0.25s var(--ease-emphasized-decelerate),
             error-shake 0.15s 0.3s ease-out;
}

@keyframes error-shake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-6px); }
  40% { transform: translateX(6px); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(2px); }
}
```

---

## Input / Form Field

### Floating Label

```css
.input-wrapper {
  position: relative;
}

.input-label {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--color-text-secondary);
  transition: all var(--duration-short-3) var(--ease-standard-decelerate);
  pointer-events: none;
  transform-origin: left center;
}

.input:focus + .input-label,
.input:not(:placeholder-shown) + .input-label {
  top: 0;
  transform: translateY(-50%) scale(0.85);
  color: var(--color-primary);
}

.input {
  border: 2px solid var(--color-border);
  transition: border-color var(--duration-short-3) var(--ease-standard-decelerate),
              box-shadow var(--duration-short-3) var(--ease-standard-decelerate);
}

.input:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px var(--color-primary-alpha);
}
```

### Error State

```css
.input--error {
  border-color: var(--color-error);
  animation: input-error-shake 0.15s ease-out;
}

@keyframes input-error-shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-4px); }
  75% { transform: translateX(4px); }
}

.input--error + .input-label {
  color: var(--color-error);
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce) {
  .input--error {
    animation: none;
    box-shadow: 0 0 0 3px var(--color-error-alpha);
  }
}
```

---

## Checkbox

```css
.checkbox {
  position: relative;
  width: 20px;
  height: 20px;
}

.checkbox__box {
  width: 100%;
  height: 100%;
  border: 2px solid var(--color-border);
  border-radius: 4px;
  transition: background-color var(--duration-short-3) var(--ease-standard),
              border-color var(--duration-short-3) var(--ease-standard);
}

.checkbox__check {
  position: absolute;
  stroke: white;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
  fill: none;
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
  transition: stroke-dashoffset var(--duration-short-3) var(--ease-emphasized-decelerate);
}

.checkbox:checked + .checkbox__box {
  background-color: var(--color-primary);
  border-color: var(--color-primary);
}

.checkbox:checked + .checkbox__box .checkbox__check {
  stroke-dashoffset: 0;
}

/* Playful bounce variation */
.checkbox--playful:checked + .checkbox__box {
  animation: checkbox-bounce 0.2s ease-out;
}

@keyframes checkbox-bounce {
  50% { transform: scale(1.15); }
}
```

```typescript
// Framer Motion
const checkboxVariants = {
  unchecked: {
    pathLength: 0,
    opacity: 0
  },
  checked: {
    pathLength: 1,
    opacity: 1,
    transition: { duration: 0.15, ease: [0.05, 0.7, 0.1, 1] }
  }
};

<motion.svg>
  <motion.path
    d="M5 12l5 5 10-10"
    variants={checkboxVariants}
    initial="unchecked"
    animate={isChecked ? "checked" : "unchecked"}
  />
</motion.svg>
```

---

## Switch / Toggle

```css
.switch {
  width: 44px;
  height: 24px;
  background: var(--color-neutral);
  border-radius: 12px;
  transition: background-color var(--duration-short-3) var(--ease-standard);
}

.switch__knob {
  width: 20px;
  height: 20px;
  background: white;
  border-radius: 50%;
  transform: translateX(2px);
  transition: transform var(--duration-short-4) cubic-bezier(0.34, 1.56, 0.64, 1);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.switch:checked {
  background: var(--color-primary);
}

.switch:checked .switch__knob {
  transform: translateX(22px);
}

/* Squash at end - playful variation */
.switch--playful .switch__knob {
  transition: transform var(--duration-short-4) cubic-bezier(0.34, 1.56, 0.64, 1),
              width var(--duration-short-2) var(--ease-standard);
}

.switch--playful:active .switch__knob {
  width: 24px;
}
```

```typescript
// Framer Motion with spring
const switchVariants = {
  off: { x: 2 },
  on: {
    x: 22,
    transition: { type: 'spring', damping: 25, stiffness: 300 }
  }
};
```

---

## Dropdown / Select

```css
.dropdown-menu {
  opacity: 0;
  transform: scaleY(0.95);
  transform-origin: top;
  visibility: hidden;
  transition: opacity var(--duration-short-4) var(--ease-emphasized-decelerate),
              transform var(--duration-short-4) var(--ease-emphasized-decelerate),
              visibility 0s var(--duration-short-4);
}

.dropdown-menu--open {
  opacity: 1;
  transform: scaleY(1);
  visibility: visible;
  transition: opacity var(--duration-short-4) var(--ease-emphasized-decelerate),
              transform var(--duration-short-4) var(--ease-emphasized-decelerate),
              visibility 0s;
}

/* Staggered items */
.dropdown-item {
  opacity: 0;
  transform: translateY(-8px);
}

.dropdown-menu--open .dropdown-item {
  animation: dropdown-item-enter 0.15s var(--ease-emphasized-decelerate) forwards;
}

.dropdown-menu--open .dropdown-item:nth-child(1) { animation-delay: 0ms; }
.dropdown-menu--open .dropdown-item:nth-child(2) { animation-delay: 25ms; }
.dropdown-menu--open .dropdown-item:nth-child(3) { animation-delay: 50ms; }

@keyframes dropdown-item-enter {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

---

## Accordion

```css
.accordion-content {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows var(--duration-medium-1) var(--ease-emphasized-decelerate);
}

.accordion-content--expanded {
  grid-template-rows: 1fr;
}

.accordion-content__inner {
  overflow: hidden;
  opacity: 0;
  transition: opacity var(--duration-short-3) var(--ease-standard);
  transition-delay: 0.1s;
}

.accordion-content--expanded .accordion-content__inner {
  opacity: 1;
}

.accordion-icon {
  transition: transform var(--duration-short-3) var(--ease-standard);
}

.accordion--expanded .accordion-icon {
  transform: rotate(180deg);
}
```

---

## List Items

### Entrance Stagger

```typescript
// Framer Motion
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }
  }
};

<motion.ul variants={containerVariants} initial="hidden" animate="visible">
  {items.map(item => (
    <motion.li key={item.id} variants={itemVariants}>
      {item.content}
    </motion.li>
  ))}
</motion.ul>
```

### Swipe to Dismiss

```typescript
// Framer Motion
<motion.div
  drag="x"
  dragConstraints={{ left: 0, right: 0 }}
  onDragEnd={(_, info) => {
    if (Math.abs(info.offset.x) > 100 || Math.abs(info.velocity.x) > 500) {
      onDismiss();
    }
  }}
  animate={{
    x: isDismissing ? (direction * window.innerWidth) : 0,
    opacity: isDismissing ? 0 : 1,
    rotate: isDismissing ? (direction * 5) : 0
  }}
  transition={{ duration: 0.2, ease: [0.3, 0, 0.8, 0.15] }}
/>
```
