# Design System Motion Principles

## Material Design 3

### Core Philosophy
Motion helps make a UI expressive and easy to use.

### Three Pillars

**1. Informative**
- Shows spatial relationships between elements
- Indicates available actions
- Guides focus and attention

**2. Focused**
- Directs attention to what matters
- Avoids unnecessary distraction
- Supports the primary task

**3. Expressive**
- Adds character and polish
- Celebrates achievements
- Creates emotional connection

### Motion Patterns
- Transitions show spatial relationships
- Elements enter/exit with purpose
- Feedback confirms interactions

## Fluent 2 (Microsoft)

### Core Philosophy
Motion should feel natural and purposeful.

### Four Pillars

**1. Functional**
- Serves a clear purpose
- Aids understanding
- Provides feedback

**2. Natural**
- Mimics physical behavior
- Respects gravity and momentum
- Feels intuitive

**3. Consistent**
- Same actions = same motion
- Predictable patterns
- Learnable behavior

**4. Appealing**
- Adds polish and refinement
- Creates positive impression
- Avoids being gratuitous

### Key Characteristics
- Quick and responsive
- Natural physics
- Confident, not tentative

## Carbon (IBM)

### Core Philosophy
Motion is purposeful, guiding users through tasks efficiently.

### Two Modes

**1. Productive**
- Quick, efficient feedback
- Minimal distraction
- Task-focused environments
- Shorter durations

**2. Expressive**
- More personality
- Marketing/onboarding
- Longer durations
- More dramatic curves

### Guidelines
- Motion should guide, not distract
- Keep animations under 300ms for productive
- Use physical, natural easing
- Support user goals

## Apple Human Interface Guidelines

### Core Philosophy
Motion provides continuity, feedback, and personality.

### Three Pillars

**1. Purpose**
- Every animation needs a reason
- Support task completion
- Avoid decoration

**2. Continuity**
- Maintain context during transitions
- Show where content came from
- Preserve mental model

**3. Fluidity**
- Smooth, responsive feedback
- Natural physics
- No jarring changes

### Key Characteristics
- Subtle and sophisticated
- Physical and believable
- Responsive to touch
- Respects user preferences

## Universal Truths

Across all systems:

| Principle | Description |
|-----------|-------------|
| Purpose | Motion has meaning, not decoration |
| Physics | Respect real-world behavior |
| Speed | Quick enough not to impede |
| Consistency | Predictable patterns |
| Accessibility | Honor reduced motion |
| Performance | 60fps, no jank |
