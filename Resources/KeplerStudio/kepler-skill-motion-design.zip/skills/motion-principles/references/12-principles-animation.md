# Disney's 12 Principles of Animation

## Overview

Developed by Disney animators in the 1930s, these principles remain foundational to all motion design.

## The 12 Principles

### 1. Squash and Stretch
**Definition**: Objects deform to show impact, weight, and flexibility.

**UI Application**:
- Button press (slight squash)
- Bouncing elements
- Elastic responses

```css
.button:active {
  transform: scaleY(0.95) scaleX(1.02);
}
```

### 2. Anticipation
**Definition**: Prepare the audience for an action.

**UI Application**:
- Button hover before click
- Drawer peeking before opening
- Loading indicators

### 3. Staging
**Definition**: Present ideas clearly.

**UI Application**:
- Focus user attention
- Modal backdrop dimming
- Hero section prominence

### 4. Straight Ahead vs. Pose to Pose
**Definition**: Two methods of drawing animation.

**UI Application**:
- Pose to pose = keyframe animation (CSS, GSAP)
- Straight ahead = physics-based (spring animations)

### 5. Follow Through and Overlapping Action
**Definition**: Parts of an object continue after main action stops.

**UI Application**:
- Stagger animations
- Secondary elements following primary
- Hair/cloth physics in characters

```javascript
gsap.from('.items', {
  y: 20,
  opacity: 0,
  stagger: 0.05  // Follow through
});
```

### 6. Slow In and Slow Out
**Definition**: Objects accelerate and decelerate naturally.

**UI Application**:
- Easing curves (ease-in-out, emphasized)
- Never use linear for UI (except continuous)

### 7. Arc
**Definition**: Natural movement follows curved paths.

**UI Application**:
- Element repositioning
- Drag interactions
- Page transitions

### 8. Secondary Action
**Definition**: Additional movement that supports the main action.

**UI Application**:
- Icon animation during button press
- Badge pulse on notification
- Ripple effect

### 9. Timing
**Definition**: Number of frames for an action affects its meaning.

**UI Application**:
- Duration tokens
- Fast = urgent, snappy
- Slow = relaxed, important

### 10. Exaggeration
**Definition**: Push reality to make things clearer.

**UI Application**:
- Error shake animation
- Success celebration
- Scale on hover (1.05 not 1.01)

### 11. Solid Drawing
**Definition**: Forms should have weight and depth.

**UI Application**:
- Shadows and depth
- Consistent light source
- Z-axis transitions

### 12. Appeal
**Definition**: Characters should be pleasing to watch.

**UI Application**:
- Smooth, polished animations
- Consistent personality
- Avoid jarring or annoying motion

## Mapping to UI

| Principle | UI Example |
|-----------|------------|
| Squash/Stretch | Button press |
| Anticipation | Hover states |
| Staging | Modal focus |
| Pose to Pose | Keyframe animation |
| Follow Through | Stagger effects |
| Slow In/Out | Easing curves |
| Arc | Drag paths |
| Secondary Action | Icon animations |
| Timing | Duration tokens |
| Exaggeration | Error shake |
| Solid Drawing | Depth/shadows |
| Appeal | Polish/consistency |
