---
name: motion-principles
description: Motion design philosophy and principles from major design systems. Use when understanding why animations should behave certain ways, learning motion fundamentals, or aligning with design system philosophy. References M3, Carbon, Fluent, and Apple HIG principles.
---

# Motion Principles

Foundational motion philosophy from industry design systems.

## Standards Reference

| System | Documentation |
|--------|---------------|
| Material Design 3 | m3.material.io/styles/motion/overview |
| Fluent 2 | fluent2.microsoft.design/motion |
| Carbon | carbondesignsystem.com/guidelines/motion/overview |
| Apple HIG | developer.apple.com/design/human-interface-guidelines/motion |

## M3 Motion Principles

### Informative
Motion shows spatial relationships between elements and available actions.

### Focused
Motion focuses attention on what's important without distraction.

### Expressive
Motion celebrates moments and adds personality while remaining functional.

## Fluent 2 Principles

### Functional
Motion serves a purpose — guiding users, providing feedback.

### Natural
Motion feels physically plausible and intuitive.

### Consistent
Similar actions use similar motion patterns.

### Appealing
Motion adds polish without being gratuitous.

## Carbon Principles

### Productive Mode
- Efficient, quick feedback
- Minimal distraction
- Task-focused

### Expressive Mode
- More personality
- Longer durations
- Marketing, onboarding contexts

## Apple HIG Principles

### Purpose
Motion should have meaning, not decoration.

### Continuity
Preserve context during transitions.

### Fluidity
Motion should feel smooth and natural.

## Universal Truths

Across all systems:

1. **Motion has purpose** — Never animate for decoration alone
2. **Physical plausibility** — Respect real-world physics
3. **User control** — Respect reduced motion preferences
4. **Consistency** — Similar actions = similar animations
5. **Performance** — 60fps minimum, optimize for jank-free

## Animation Categories

| Category | Purpose | Example |
|----------|---------|---------|
| Feedback | Confirm action | Button press ripple |
| Guidance | Direct attention | Error shake |
| State | Show change | Toggle switch |
| Continuity | Preserve context | Page transition |
| Expression | Add personality | Success celebration |

## Anti-Patterns

Avoid:
- Animation without purpose
- Overly long durations (>600ms for UI)
- Excessive bouncing/overshooting
- Blocking interactions during animation
- Ignoring reduced motion preference

See `references/design-system-principles.md` for detailed comparisons.
See `references/12-principles-animation.md` for Disney's 12 principles.
