# Noise Functions Reference

Implementation details for procedural noise algorithms.

## Perlin Noise

Classic gradient noise algorithm.

### Simplified 1D Perlin

```javascript
function perlin1D(x) {
  const xi = Math.floor(x);
  const xf = x - xi;

  // Gradient at integer points (simplified: just -1 or 1)
  const g0 = hash(xi) > 0.5 ? 1 : -1;
  const g1 = hash(xi + 1) > 0.5 ? 1 : -1;

  // Dot products
  const d0 = g0 * xf;
  const d1 = g1 * (xf - 1);

  // Smooth interpolation
  const t = smoothstep(xf);
  return lerp(d0, d1, t);
}

function smoothstep(t) {
  return t * t * (3 - 2 * t);
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function hash(n) {
  // Simple hash function
  return (Math.sin(n * 127.1) * 43758.5453) % 1;
}
```

### 2D Perlin Noise

```javascript
function perlin2D(x, y) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;

  // Gradients at corners
  const g00 = gradient2D(xi, yi);
  const g10 = gradient2D(xi + 1, yi);
  const g01 = gradient2D(xi, yi + 1);
  const g11 = gradient2D(xi + 1, yi + 1);

  // Dot products
  const d00 = dot(g00, xf, yf);
  const d10 = dot(g10, xf - 1, yf);
  const d01 = dot(g01, xf, yf - 1);
  const d11 = dot(g11, xf - 1, yf - 1);

  // Smooth interpolation
  const tx = smoothstep(xf);
  const ty = smoothstep(yf);

  const nx0 = lerp(d00, d10, tx);
  const nx1 = lerp(d01, d11, tx);

  return lerp(nx0, nx1, ty);
}

function gradient2D(ix, iy) {
  const h = hash2D(ix, iy);
  const angle = h * Math.PI * 2;
  return { x: Math.cos(angle), y: Math.sin(angle) };
}

function dot(g, x, y) {
  return g.x * x + g.y * y;
}
```

## Simplex Noise

Improved algorithm with fewer artifacts.

### Benefits over Perlin
- Fewer directional artifacts
- Faster computation in higher dimensions
- Lower computational complexity

### 2D Simplex (using library)

```javascript
import { createNoise2D } from 'simplex-noise';

const noise2D = createNoise2D();

// Returns value in range [-1, 1]
const value = noise2D(x * frequency, y * frequency);

// Scale to desired range
const scaled = value * amplitude;
```

## Fractal Brownian Motion (fBm)

Layered noise for organic complexity.

```javascript
function fbm(x, y, octaves = 4, lacunarity = 2, persistence = 0.5) {
  let value = 0;
  let amplitude = 1;
  let frequency = 1;
  let maxValue = 0;

  for (let i = 0; i < octaves; i++) {
    value += noise2D(x * frequency, y * frequency) * amplitude;
    maxValue += amplitude;

    amplitude *= persistence;  // Each octave has less influence
    frequency *= lacunarity;   // Each octave is higher frequency
  }

  return value / maxValue; // Normalize to [-1, 1]
}

// Usage
const organic = fbm(x * 0.01, y * 0.01, 6, 2, 0.5);
```

### Octave Presets

| Octaves | Character | Use Case |
|---------|-----------|----------|
| 1 | Smooth, simple | Basic movement |
| 3 | Natural | General organic motion |
| 6 | Detailed | Complex textures |
| 8 | Very detailed | Maximum organic feel |

## Worley/Cellular Noise

Creates organic cell-like patterns.

```javascript
function worley2D(x, y, cellSize = 1) {
  const cellX = Math.floor(x / cellSize);
  const cellY = Math.floor(y / cellSize);

  let minDist = Infinity;

  // Check neighboring cells
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      const cx = cellX + dx;
      const cy = cellY + dy;

      // Random point in cell
      const px = (cx + hash2D(cx, cy)) * cellSize;
      const py = (cy + hash2D(cy, cx)) * cellSize;

      const dist = Math.hypot(x - px, y - py);
      minDist = Math.min(minDist, dist);
    }
  }

  return minDist / cellSize; // Normalize
}
```

## Wiggle Expression (After Effects Style)

```javascript
function wiggle(freq, amp, octaves = 1, ampMult = 0.5, time) {
  let result = 0;
  let currentAmp = amp;
  let currentFreq = freq;

  for (let i = 0; i < octaves; i++) {
    result += noise1D(time * currentFreq) * currentAmp;
    currentAmp *= ampMult;
    currentFreq *= 2;
  }

  return result;
}

// Usage: wiggle(3, 10) - 3 wiggles per second, ±10 pixels
function applyWiggle(element) {
  let time = 0;

  function animate() {
    time += 1/60;

    const x = wiggle(3, 10, 2, 0.5, time);
    const y = wiggle(3, 10, 2, 0.5, time + 100); // Offset for different values

    element.style.transform = `translate(${x}px, ${y}px)`;
    requestAnimationFrame(animate);
  }

  animate();
}
```

## Noise Derivatives

Get direction of noise change for flow fields.

```javascript
function noiseWithDerivatives(x, y, epsilon = 0.001) {
  const value = noise2D(x, y);
  const dx = (noise2D(x + epsilon, y) - noise2D(x - epsilon, y)) / (2 * epsilon);
  const dy = (noise2D(x, y + epsilon) - noise2D(x, y - epsilon)) / (2 * epsilon);

  return { value, dx, dy };
}

// Use for flow field
function flowField(x, y) {
  const { dx, dy } = noiseWithDerivatives(x * 0.01, y * 0.01);
  return { vx: -dy, vy: dx }; // Perpendicular to gradient
}
```

## Time-Based Noise Animation

```javascript
class NoiseAnimator {
  constructor(options = {}) {
    this.noise = createNoise2D();
    this.time = 0;
    this.speed = options.speed || 1;
    this.frequency = options.frequency || 0.05;
    this.amplitude = options.amplitude || 30;
  }

  getValue(dimension = 0) {
    return this.noise(
      this.time * this.frequency,
      dimension * 1000
    ) * this.amplitude;
  }

  getPosition() {
    return {
      x: this.getValue(0),
      y: this.getValue(1),
      rotation: this.getValue(2) / this.amplitude * 5
    };
  }

  update(deltaTime = 1/60) {
    this.time += deltaTime * this.speed;
  }

  animate(element) {
    const update = () => {
      this.update();
      const { x, y, rotation } = this.getPosition();
      element.style.transform = `translate(${x}px, ${y}px) rotate(${rotation}deg)`;
      requestAnimationFrame(update);
    };
    update();
  }
}
```

## Seeded Random for Reproducibility

```javascript
class SeededRandom {
  constructor(seed = 12345) {
    this.seed = seed;
  }

  next() {
    this.seed = (this.seed * 1103515245 + 12345) & 0x7fffffff;
    return this.seed / 0x7fffffff;
  }

  range(min, max) {
    return min + this.next() * (max - min);
  }
}

// Usage
const rng = new SeededRandom(42);
const consistentRandom = rng.next(); // Always same value for seed 42
```

## Libraries

### simplex-noise (npm)
```bash
npm install simplex-noise
```

```javascript
import { createNoise2D, createNoise3D } from 'simplex-noise';

const noise2D = createNoise2D();
const noise3D = createNoise3D(); // For time-varying 2D noise

// Time-based 2D noise
const value = noise3D(x * freq, y * freq, time * speed);
```

### GSAP Random
```javascript
// GSAP has built-in random utilities
gsap.utils.random(-10, 10); // Random in range
gsap.utils.random(["a", "b", "c"]); // Random from array
gsap.utils.shuffle([1, 2, 3, 4, 5]); // Shuffle array
```

## Performance Tips

1. **Pre-compute noise textures** for complex effects
2. **Use lower octaves** for real-time animation
3. **Cache noise values** when possible
4. **Use TypedArrays** for performance
5. **Consider Web Workers** for heavy computation

```javascript
// Pre-computed noise texture
function createNoiseTexture(width, height, frequency) {
  const data = new Float32Array(width * height);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      data[y * width + x] = noise2D(x * frequency, y * frequency);
    }
  }

  return data;
}
```
