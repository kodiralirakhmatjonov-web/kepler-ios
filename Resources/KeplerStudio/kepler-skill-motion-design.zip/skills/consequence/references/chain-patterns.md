# Consequence Chain Patterns

Detailed configurations for cause-effect animation chains.

## Pattern Library

### Button → Modal Flow

```javascript
const buttonToModal = {
  chain: ['direct'],
  stages: [
    {
      name: 'button-feedback',
      element: '.btn',
      animation: {
        scale: [1, 0.95, 1],
        duration: 150
      }
    },
    {
      name: 'scrim-appear',
      element: '.scrim',
      delay: 0,
      animation: {
        opacity: [0, 1],
        duration: 200
      }
    },
    {
      name: 'modal-enter',
      element: '.modal',
      delay: 50, // Slight offset from scrim
      animation: {
        opacity: [0, 1],
        scale: [0.9, 1],
        y: [20, 0],
        duration: 300,
        easing: 'emphasized-decelerate'
      }
    },
    {
      name: 'content-reveal',
      element: '.modal-content',
      delay: 150,
      animation: {
        opacity: [0, 1],
        y: [10, 0],
        stagger: 50,
        duration: 200
      }
    }
  ]
};
```

### Form Submission Cascade

```javascript
const formSubmitCascade = {
  chain: ['cascade', 'branch'],
  stages: [
    // Stage 1: Button press
    {
      name: 'press',
      element: '.submit',
      animation: { scale: 0.95, duration: 50 }
    },
    // Stage 2: Branch - parallel effects
    {
      name: 'processing-start',
      type: 'branch',
      branches: [
        {
          element: '.submit',
          animation: {
            width: 50,
            borderRadius: 25,
            duration: 200
          }
        },
        {
          element: '.spinner',
          animation: {
            opacity: 1,
            rotate: 360,
            duration: 200,
            repeat: -1
          }
        },
        {
          element: '.form-fields',
          animation: {
            opacity: 0.5,
            pointerEvents: 'none'
          }
        }
      ]
    },
    // Stage 3: Success cascade
    {
      name: 'success',
      trigger: 'api-response',
      type: 'cascade',
      cascadeDelay: 50,
      elements: [
        {
          element: '.spinner',
          animation: { opacity: 0, scale: 0.8 }
        },
        {
          element: '.checkmark',
          animation: {
            opacity: 1,
            scale: 1,
            easing: 'back.out(2)'
          }
        },
        {
          element: '.success-message',
          animation: {
            opacity: 1,
            y: 0
          }
        }
      ]
    }
  ]
};
```

### Card Selection Ripple

```javascript
const cardSelectionRipple = {
  chain: ['direct', 'ripple'],
  config: {
    ripple: {
      delayPerPixel: 0.001,
      intensityDecay: 0.15,
      maxDistance: 500
    }
  },
  stages: [
    // Direct: selected card
    {
      name: 'select',
      element: '.card.selected',
      animation: {
        scale: 1.05,
        boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
        zIndex: 10,
        duration: 200
      }
    },
    // Ripple: neighbors react
    {
      name: 'neighbor-react',
      type: 'ripple',
      elements: '.card:not(.selected)',
      from: '.card.selected',
      animation: {
        scale: 0.98,
        opacity: 0.8,
        duration: 150
      }
    }
  ]
};
```

### Notification with Echo

```javascript
const notificationEcho = {
  chain: ['direct', 'echo'],
  stages: [
    // Direct: notification enters
    {
      name: 'enter',
      element: '.notification',
      animation: {
        x: [100, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'emphasized-decelerate'
      }
    },
    // Echo: reminder pulse after 2s
    {
      name: 'reminder',
      type: 'echo',
      delay: 2000,
      intensityMultiplier: 0.3,
      animation: {
        scale: [1, 1.02, 1],
        boxShadow: [
          '0 0 0 0 rgba(33, 150, 243, 0)',
          '0 0 0 8px rgba(33, 150, 243, 0.3)',
          '0 0 0 0 rgba(33, 150, 243, 0)'
        ],
        duration: 600
      }
    }
  ]
};
```

### Multi-Condition Enable

```javascript
const convergentEnable = {
  chain: ['convergent'],
  conditions: [
    { name: 'email-valid', element: '.email-input' },
    { name: 'password-valid', element: '.password-input' },
    { name: 'terms-accepted', element: '.terms-checkbox' }
  ],
  consequence: {
    element: '.submit-btn',
    animation: {
      opacity: [0.5, 1],
      scale: [0.95, 1],
      filter: ['grayscale(1)', 'grayscale(0)'],
      duration: 300,
      easing: 'spring'
    }
  },
  partialFeedback: {
    // Show progress as conditions are met
    perCondition: {
      animation: {
        boxShadow: 'add-glow-segment'
      }
    }
  }
};
```

### Drag Reorder Chain

```javascript
const dragReorderChain = {
  chain: ['direct', 'ripple', 'direct'],
  stages: [
    // Pickup
    {
      name: 'pickup',
      trigger: 'drag-start',
      element: '.dragging',
      animation: {
        scale: 1.05,
        boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
        rotate: 2,
        duration: 150
      }
    },
    // Neighbors shift (continuous during drag)
    {
      name: 'shift',
      trigger: 'drag-over',
      type: 'ripple',
      elements: '.list-item:not(.dragging)',
      animation: {
        y: (el, context) => context.isAfter ? 60 : 0,
        duration: 200,
        easing: 'spring'
      }
    },
    // Drop
    {
      name: 'drop',
      trigger: 'drag-end',
      element: '.dragging',
      animation: {
        scale: 1,
        boxShadow: 'none',
        rotate: 0,
        duration: 300,
        easing: 'spring'
      }
    }
  ]
};
```

### Accordion Expand Cascade

```javascript
const accordionCascade = {
  chain: ['direct', 'cascade'],
  stages: [
    // Header click
    {
      name: 'header-activate',
      element: '.accordion-header.active',
      animation: {
        backgroundColor: 'var(--active-bg)',
        duration: 150
      }
    },
    // Icon rotate
    {
      name: 'icon-rotate',
      element: '.accordion-header.active .icon',
      animation: {
        rotate: 180,
        duration: 200
      }
    },
    // Content expand
    {
      name: 'content-expand',
      element: '.accordion-content.active',
      animation: {
        height: 'auto',
        opacity: 1,
        duration: 300,
        easing: 'emphasized'
      }
    },
    // Siblings collapse (cascade)
    {
      name: 'siblings-collapse',
      type: 'cascade',
      elements: '.accordion-content:not(.active)',
      cascadeDelay: 30,
      animation: {
        height: 0,
        opacity: 0,
        duration: 200
      }
    }
  ]
};
```

## Chain Composition Utilities

```javascript
// Chain executor
class ChainExecutor {
  constructor(config) {
    this.config = config;
    this.timeline = gsap.timeline();
  }

  execute() {
    this.config.stages.forEach((stage, index) => {
      const delay = stage.delay || 0;
      const position = index === 0 ? 0 : `+=${delay / 1000}`;

      switch (stage.type) {
        case 'branch':
          this.executeBranch(stage, position);
          break;
        case 'ripple':
          this.executeRipple(stage, position);
          break;
        case 'cascade':
          this.executeCascade(stage, position);
          break;
        case 'echo':
          this.executeEcho(stage, position);
          break;
        default:
          this.executeDirect(stage, position);
      }
    });

    return this.timeline;
  }

  executeDirect(stage, position) {
    this.timeline.to(
      stage.element,
      { ...stage.animation, duration: stage.animation.duration / 1000 },
      position
    );
  }

  executeBranch(stage, position) {
    stage.branches.forEach(branch => {
      this.timeline.to(
        branch.element,
        { ...branch.animation, duration: branch.animation.duration / 1000 },
        position
      );
    });
  }

  executeRipple(stage, position) {
    const origin = document.querySelector(stage.from);
    this.timeline.to(
      stage.elements,
      {
        ...stage.animation,
        duration: stage.animation.duration / 1000,
        stagger: {
          each: 0.03,
          from: origin,
          grid: 'auto'
        }
      },
      position
    );
  }

  executeCascade(stage, position) {
    this.timeline.to(
      stage.elements.map(e => e.element),
      {
        ...stage.elements[0].animation,
        stagger: stage.cascadeDelay / 1000
      },
      position
    );
  }

  executeEcho(stage, position) {
    const echoPosition = `+=${stage.delay / 1000}`;
    const echoAnimation = {
      ...stage.animation,
      duration: stage.animation.duration / 1000
    };

    // Scale down by intensity multiplier
    if (stage.intensityMultiplier) {
      if (echoAnimation.scale) {
        echoAnimation.scale = echoAnimation.scale.map(
          s => 1 + (s - 1) * stage.intensityMultiplier
        );
      }
    }

    this.timeline.to(stage.element || this.config.stages[0].element, echoAnimation, echoPosition);
  }
}
```
