---
name: platform-adaptation
description: Adapt motion patterns for different platforms, devices, and reading directions. Use when implementing animations that need to work across mobile, desktop, RTL languages, and different OS conventions.
---

# Platform Adaptation

Motion patterns that adapt to platform conventions, device capabilities, and internationalization requirements.

## Platform-Specific Conventions

### iOS / Apple

| Pattern | iOS Convention | Implementation |
|---------|---------------|----------------|
| Page transition | Push from right | translateX: 100% to 0 |
| Back navigation | Slide to right | translateX: 0 to 100% |
| Modal | Slide from bottom | translateY: 100% to 0 |
| Action sheet | Slide from bottom | Spring physics |
| Pull-to-refresh | Rubber-band effect | Elastic overshoot |

### Android / Material

| Pattern | Android Convention | Implementation |
|---------|-------------------|----------------|
| Page transition | Shared axis | Fade + scale |
| Back navigation | Fade out | Fade through |
| Modal | Slide from bottom | Container transform |
| FAB | Scale from center | emphasized-decelerate |
| Snackbar | Slide from bottom | Quick ease-out |

### Web / Desktop

| Pattern | Desktop Convention | Implementation |
|---------|-------------------|----------------|
| Hover states | Immediate feedback | 100-150ms transitions |
| Modals | Fade + scale | Center of viewport |
| Tooltips | Fade in with delay | 200ms delay, 100ms transition |
| Dropdowns | Fade + slide down | Origin from trigger |

## RTL (Right-to-Left) Adaptation

For languages like Arabic, Hebrew, Farsi, and Urdu, horizontal animations must be mirrored.

### What to Mirror

| Animation Type | LTR | RTL |
|---------------|-----|-----|
| Slide in | from left | from right |
| Slide out | to right | to left |
| Page push | from right | from left |
| Arrow motion | right arrow | left arrow |
| Progress bar | left to right | right to left |
| Carousel swipe | left = prev | left = next |

### What NOT to Mirror

| Animation Type | Behavior | Rationale |
|---------------|----------|-----------|
| Vertical motion | Same | Up/down is universal |
| Rotation | Same | Clockwise is universal |
| Scale | Same | Center-out is universal |
| Opacity | Same | Fade is directionless |
| Z-depth | Same | Toward/away is universal |

### CSS Implementation

```css
/* Base animation (LTR) */
.slide-in {
  animation: slide-in-ltr 300ms ease-out;
}

@keyframes slide-in-ltr {
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
}

/* RTL override */
[dir="rtl"] .slide-in {
  animation-name: slide-in-rtl;
}

@keyframes slide-in-rtl {
  from { transform: translateX(100%); }
  to { transform: translateX(0); }
}
```

### JavaScript Direction Helper

```javascript
function getDirectionMultiplier() {
  return document.dir === 'rtl' ? -1 : 1;
}

function slideIn(element, options = {}) {
  const dir = getDirectionMultiplier();
  return gsap.from(element, {
    x: (options.distance || 100) * -dir,
    opacity: 0,
    duration: 0.3,
    ease: 'power2.out'
  });
}
```

## Device Capability Adaptation

```javascript
const capabilities = {
  gpu: detectGPU(),
  memory: navigator.deviceMemory || 4,
  connection: navigator.connection?.effectiveType || '4g',
  cores: navigator.hardwareConcurrency || 4
};

function getAnimationQuality() {
  if (capabilities.memory < 2) return 'minimal';
  if (capabilities.memory < 4) return 'reduced';
  if (capabilities.gpu === 'low-end') return 'standard';
  return 'full';
}
```

## Common Mistakes

1. **Forgetting RTL** - Test all horizontal animations in RTL mode
2. **Mirroring everything** - Vertical and scale should NOT mirror
3. **Hardcoded directions** - Use logical properties and direction multipliers
4. **Platform mismatch** - iOS users expect iOS conventions
5. **Ignoring capabilities** - Low-end devices need simpler animations

## Related Skills

- `transitions/` - Page transition patterns
- `accessibility/` - Reduced motion for all platforms
- `testing-patterns/` - RTL testing strategies
- `tools/` - Platform-specific tool usage

See `references/` for complete Framer Motion and Remotion RTL implementations.
