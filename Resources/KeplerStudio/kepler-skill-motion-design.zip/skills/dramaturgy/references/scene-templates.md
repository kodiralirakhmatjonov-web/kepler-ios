# Scene Templates

Pre-configured scene compositions for common UI patterns.

## Modal Scenes

### Standard Modal Open

```javascript
const standardModalOpen = {
  name: 'standard-modal-open',
  totalDuration: 450,
  scenes: [
    {
      name: 'scrim',
      type: 'establishing',
      duration: 200,
      elements: [
        {
          selector: '.scrim',
          animation: {
            opacity: [0, 1],
            ease: 'power2.out'
          }
        }
      ]
    },
    {
      name: 'container',
      type: 'establishing',
      offset: -50, // Overlap with scrim
      duration: 300,
      elements: [
        {
          selector: '.modal',
          animation: {
            opacity: [0, 1],
            scale: [0.95, 1],
            y: [20, 0],
            ease: 'emphasized-decelerate'
          }
        }
      ]
    },
    {
      name: 'content',
      type: 'development',
      offset: 100,
      duration: 200,
      stagger: 50,
      elements: [
        { selector: '.modal-header' },
        { selector: '.modal-body' },
        { selector: '.modal-footer' }
      ],
      animation: {
        opacity: [0, 1],
        y: [10, 0],
        ease: 'power2.out'
      }
    }
  ]
};
```

### Confirmation Modal

```javascript
const confirmationModal = {
  name: 'confirmation-modal',
  totalDuration: 500,
  scenes: [
    {
      name: 'alert',
      type: 'confrontation',
      duration: 300,
      elements: [
        {
          selector: '.modal',
          animation: {
            opacity: [0, 1],
            scale: [0.9, 1.02, 1],
            ease: 'back.out(1.5)'
          }
        }
      ]
    },
    {
      name: 'emphasis',
      type: 'confrontation',
      offset: 200,
      duration: 200,
      elements: [
        {
          selector: '.destructive-action',
          animation: {
            boxShadow: ['0 0 0 0 rgba(244,67,54,0)', '0 0 0 4px rgba(244,67,54,0.3)'],
            ease: 'power2.out'
          }
        }
      ]
    }
  ]
};
```

## Page Transition Scenes

### Shared Axis Transition

```javascript
const sharedAxisTransition = {
  name: 'shared-axis-horizontal',
  totalDuration: 500,
  scenes: [
    {
      name: 'exit',
      type: 'transition',
      duration: 200,
      elements: [
        {
          selector: '.current-page',
          animation: {
            opacity: [1, 0],
            x: [0, -30],
            ease: 'emphasized-accelerate'
          }
        }
      ]
    },
    {
      name: 'enter',
      type: 'establishing',
      offset: 100,
      duration: 300,
      elements: [
        {
          selector: '.next-page',
          animation: {
            opacity: [0, 1],
            x: [30, 0],
            ease: 'emphasized-decelerate'
          }
        }
      ]
    }
  ]
};
```

### Fade Through Transition

```javascript
const fadeThroughTransition = {
  name: 'fade-through',
  totalDuration: 400,
  scenes: [
    {
      name: 'fade-out',
      type: 'transition',
      duration: 150,
      elements: [
        {
          selector: '.current-content',
          animation: {
            opacity: [1, 0],
            scale: [1, 0.95],
            ease: 'power2.in'
          }
        }
      ]
    },
    {
      name: 'fade-in',
      type: 'establishing',
      offset: 100,
      duration: 250,
      elements: [
        {
          selector: '.next-content',
          animation: {
            opacity: [0, 1],
            scale: [1.05, 1],
            ease: 'power2.out'
          }
        }
      ]
    }
  ]
};
```

## Notification Scenes

### Toast Notification

```javascript
const toastNotification = {
  name: 'toast',
  totalDuration: 4000,
  scenes: [
    {
      name: 'entrance',
      type: 'establishing',
      duration: 300,
      elements: [
        {
          selector: '.toast',
          animation: {
            opacity: [0, 1],
            y: [20, 0],
            ease: 'emphasized-decelerate'
          }
        }
      ]
    },
    {
      name: 'hold',
      type: 'development',
      offset: 300,
      duration: 3000,
      elements: []
    },
    {
      name: 'attention',
      type: 'confrontation',
      offset: 2500,
      duration: 500,
      elements: [
        {
          selector: '.toast',
          animation: {
            scale: [1, 1.02, 1],
            ease: 'power2.inOut'
          }
        }
      ]
    },
    {
      name: 'exit',
      type: 'resolution',
      offset: 3500,
      duration: 300,
      elements: [
        {
          selector: '.toast',
          animation: {
            opacity: [1, 0],
            y: [0, -10],
            ease: 'power2.in'
          }
        }
      ]
    }
  ]
};
```

## Dashboard Scenes

### Dashboard Load

```javascript
const dashboardLoad = {
  name: 'dashboard-load',
  totalDuration: 1200,
  scenes: [
    {
      name: 'skeleton',
      type: 'establishing',
      duration: 200,
      elements: [
        {
          selector: '.skeleton',
          animation: {
            opacity: [0, 1],
            ease: 'power2.out'
          }
        }
      ]
    },
    {
      name: 'header',
      type: 'development',
      offset: 100,
      duration: 300,
      elements: [
        {
          selector: '.header',
          animation: {
            opacity: [0, 1],
            y: [10, 0],
            ease: 'power2.out'
          }
        }
      ]
    },
    {
      name: 'cards',
      type: 'development',
      offset: 250,
      duration: 400,
      stagger: 50,
      pattern: 'wave',
      elements: [
        { selector: '.card-1' },
        { selector: '.card-2' },
        { selector: '.card-3' },
        { selector: '.card-4' }
      ],
      animation: {
        opacity: [0, 1],
        y: [20, 0],
        ease: 'emphasized-decelerate'
      }
    },
    {
      name: 'data-appear',
      type: 'resolution',
      offset: 600,
      duration: 300,
      elements: [
        {
          selector: '.chart-line',
          animation: {
            strokeDashoffset: [100, 0],
            ease: 'power2.out'
          }
        }
      ]
    }
  ]
};
```

## Form Scenes

### Form Submission Success

```javascript
const formSuccess = {
  name: 'form-success',
  totalDuration: 800,
  scenes: [
    {
      name: 'button-transform',
      type: 'development',
      duration: 200,
      elements: [
        {
          selector: '.submit-btn',
          animation: {
            width: [120, 50],
            borderRadius: [4, 25],
            ease: 'power2.inOut'
          }
        }
      ]
    },
    {
      name: 'loading',
      type: 'development',
      offset: 150,
      duration: 300,
      elements: [
        {
          selector: '.spinner',
          animation: {
            opacity: [0, 1],
            rotate: [0, 360],
            ease: 'linear'
          }
        }
      ]
    },
    {
      name: 'success',
      type: 'resolution',
      offset: 400,
      duration: 300,
      elements: [
        {
          selector: '.spinner',
          animation: {
            opacity: [1, 0],
            scale: [1, 0.8],
            ease: 'power2.in'
          }
        },
        {
          selector: '.checkmark',
          animation: {
            opacity: [0, 1],
            scale: [0.5, 1],
            ease: 'back.out(2)'
          }
        }
      ]
    },
    {
      name: 'form-fade',
      type: 'resolution',
      offset: 600,
      duration: 200,
      elements: [
        {
          selector: '.form-fields',
          animation: {
            opacity: [1, 0.5],
            ease: 'power2.out'
          }
        }
      ]
    }
  ]
};
```

## Scene Executor

```javascript
class SceneExecutor {
  constructor(template) {
    this.template = template;
    this.timeline = gsap.timeline();
  }

  build() {
    this.template.scenes.forEach(scene => {
      const position = scene.offset
        ? `${scene.offset / 1000}`
        : '+=0';

      if (scene.stagger && scene.elements.length > 1) {
        this.timeline.from(
          scene.elements.map(e => e.selector),
          {
            ...scene.animation,
            duration: scene.duration / 1000,
            stagger: scene.stagger / 1000
          },
          position
        );
      } else {
        scene.elements.forEach(element => {
          this.timeline.fromTo(
            element.selector,
            this.getFromState(element.animation || scene.animation),
            {
              ...this.getToState(element.animation || scene.animation),
              duration: scene.duration / 1000,
              ease: (element.animation || scene.animation).ease
            },
            position
          );
        });
      }
    });

    return this.timeline;
  }

  getFromState(animation) {
    const from = {};
    Object.entries(animation).forEach(([key, value]) => {
      if (Array.isArray(value)) from[key] = value[0];
    });
    return from;
  }

  getToState(animation) {
    const to = {};
    Object.entries(animation).forEach(([key, value]) => {
      if (Array.isArray(value)) to[key] = value[value.length - 1];
    });
    return to;
  }

  play() {
    return this.build().play();
  }
}
```
