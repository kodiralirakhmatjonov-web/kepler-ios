# Act Composition

Multi-scene dramatic structures for extended motion experiences.

## Three-Act Structure

The classic dramatic structure adapted for UI.

### Overview

```
╔════════════════════════════════════════════════════════════════╗
║                     THREE-ACT STRUCTURE                        ║
╠════════════════════════════════════════════════════════════════╣
║  ACT 1: SETUP      ACT 2: CONFRONTATION    ACT 3: RESOLUTION  ║
║    (25%)                 (50%)                  (25%)          ║
║                                                                ║
║  • Establish       • Main interaction      • Confirm outcome   ║
║  • Introduce       • Challenges            • Settle            ║
║  • Orient          • Progress              • Transition out    ║
╚════════════════════════════════════════════════════════════════╝
```

### Act 1: Setup (25% of total)

**Purpose:** Establish context, introduce what's happening

**Scenes:**
1. Establishing - Orient user to new context
2. Development - Introduce interactive elements

**Motion characteristics:**
- Gentle deceleration
- Low to medium intensity
- Clear spatial relationships

```javascript
const act1Setup = {
  duration: '25%',
  scenes: [
    {
      type: 'establishing',
      weight: 0.6,
      motion: {
        intensity: 0.4,
        easing: 'emphasized-decelerate'
      }
    },
    {
      type: 'development',
      weight: 0.4,
      motion: {
        intensity: 0.5,
        easing: 'standard'
      }
    }
  ]
};
```

### Act 2: Confrontation (50% of total)

**Purpose:** Main interaction, challenges, progress

**Scenes:**
1. Development - Build complexity
2. Confrontation - Peak challenge/decision
3. Development - Work toward resolution

**Motion characteristics:**
- Building intensity
- Responsive feedback
- Clear progress indicators

```javascript
const act2Confrontation = {
  duration: '50%',
  scenes: [
    {
      type: 'development',
      weight: 0.35,
      motion: {
        intensity: 0.6,
        easing: 'standard'
      }
    },
    {
      type: 'confrontation',
      weight: 0.3,
      motion: {
        intensity: 0.8,
        easing: 'emphasized'
      }
    },
    {
      type: 'development',
      weight: 0.35,
      motion: {
        intensity: 0.6,
        easing: 'standard-decelerate'
      }
    }
  ]
};
```

### Act 3: Resolution (25% of total)

**Purpose:** Confirm outcome, settle, transition

**Scenes:**
1. Resolution - Show result
2. Transition - Bridge to next state

**Motion characteristics:**
- Decelerating
- Settling
- Clear conclusion signals

```javascript
const act3Resolution = {
  duration: '25%',
  scenes: [
    {
      type: 'resolution',
      weight: 0.7,
      motion: {
        intensity: 0.5,
        easing: 'ease-out'
      }
    },
    {
      type: 'transition',
      weight: 0.3,
      motion: {
        intensity: 0.3,
        easing: 'standard'
      }
    }
  ]
};
```

## Micro-Act Structure

Condensed two-phase structure for component interactions.

```
╔═══════════════════════════════════╗
║         MICRO-ACT                 ║
╠═══════════════════════════════════╣
║  SETUP (40%)    PAYOFF (60%)      ║
║                                   ║
║  • Anticipation  • Delivery       ║
║  • Prepare       • Satisfaction   ║
╚═══════════════════════════════════╝
```

```javascript
const microAct = {
  totalDuration: 400,
  phases: [
    {
      name: 'setup',
      duration: 160,
      motion: {
        intensity: 0.4,
        easing: 'ease-in'
      }
    },
    {
      name: 'payoff',
      duration: 240,
      motion: {
        intensity: 0.7,
        easing: 'spring'
      }
    }
  ]
};
```

## Application Examples

### Onboarding Flow (Three-Act)

```javascript
const onboardingActs = {
  act1: {
    name: 'Welcome',
    duration: 3000,
    scenes: [
      { type: 'establishing', content: 'Logo reveal' },
      { type: 'development', content: 'Welcome message' }
    ]
  },
  act2: {
    name: 'Tour',
    duration: 8000,
    scenes: [
      { type: 'development', content: 'Feature 1' },
      { type: 'confrontation', content: 'Try it yourself' },
      { type: 'development', content: 'Feature 2' },
      { type: 'confrontation', content: 'Complete task' },
      { type: 'development', content: 'Feature 3' }
    ]
  },
  act3: {
    name: 'Ready',
    duration: 2000,
    scenes: [
      { type: 'resolution', content: 'Success state' },
      { type: 'transition', content: 'Enter app' }
    ]
  }
};
```

### Checkout Flow (Three-Act)

```javascript
const checkoutActs = {
  act1: {
    name: 'Cart Review',
    duration: 1500,
    scenes: [
      { type: 'establishing', content: 'Cart summary' },
      { type: 'development', content: 'Item details' }
    ]
  },
  act2: {
    name: 'Payment',
    duration: 5000,
    scenes: [
      { type: 'development', content: 'Shipping form' },
      { type: 'confrontation', content: 'Payment form' },
      { type: 'development', content: 'Review order' }
    ]
  },
  act3: {
    name: 'Confirmation',
    duration: 2000,
    scenes: [
      { type: 'resolution', content: 'Success animation' },
      { type: 'transition', content: 'Order details' }
    ]
  }
};
```

### Modal Interaction (Micro-Act)

```javascript
const modalMicroAct = {
  setup: {
    duration: 150,
    elements: [
      { el: '.scrim', animation: 'fade-in' },
      { el: '.modal', animation: 'scale-up' }
    ]
  },
  payoff: {
    duration: 250,
    elements: [
      { el: '.modal-content', animation: 'slide-up-fade' },
      { el: '.focus-ring', animation: 'appear' }
    ]
  }
};
```

## Intensity Mapping

How intensity flows through acts:

```
     1.0 ─┼───────────────────────────────────────────────
         │                   ╭─╮
     0.8 ─┼───────────────────┤ ├──────────────────────────
         │               ╭───╯ ╰───╮
     0.6 ─┼───────────────┤         ├──────────────────────
         │           ╭───╯         ╰───╮
     0.4 ─┼───────────┤                 ├──────────────────
         │       ╭───╯                 ╰───╮
     0.2 ─┼───────┤                         ╰──────────────
         │
     0.0 ─┼────────────────────────────────────────────────
              ACT 1      ACT 2          ACT 3
```

## Act Timing Calculator

```javascript
function calculateActTiming(totalDuration, actStructure = '3-act') {
  const structures = {
    '3-act': { act1: 0.25, act2: 0.50, act3: 0.25 },
    '5-act': { act1: 0.10, act2: 0.20, act3: 0.40, act4: 0.20, act5: 0.10 },
    'micro': { setup: 0.40, payoff: 0.60 }
  };

  const distribution = structures[actStructure];
  const timing = {};

  Object.entries(distribution).forEach(([act, weight]) => {
    timing[act] = totalDuration * weight;
  });

  return timing;
}

// Example
calculateActTiming(10000, '3-act');
// { act1: 2500, act2: 5000, act3: 2500 }
```

## Transition Between Acts

### Act 1 → Act 2

```javascript
const act1to2Transition = {
  name: 'setup-to-confrontation',
  duration: 300,
  motion: {
    intensity: { from: 0.4, to: 0.6 },
    tempo: { from: 'measured', to: 'standard' },
    animation: 'fade-through'
  }
};
```

### Act 2 → Act 3

```javascript
const act2to3Transition = {
  name: 'confrontation-to-resolution',
  duration: 400,
  motion: {
    intensity: { from: 0.8, to: 0.5 },
    tempo: { from: 'standard', to: 'decelerating' },
    animation: 'settle'
  }
};
```

## Anti-Patterns

### Act 2 Too Long

**Problem:** User fatigue, lost narrative thread
**Solution:** Break into clear sub-scenes with progress indicators

### Skipping Act 1

**Problem:** Disorientation, confusion
**Solution:** Always have brief establishing moment

### Weak Act 3

**Problem:** Unsatisfying conclusion
**Solution:** Clear resolution motion, hold final state

### Inconsistent Intensity

**Problem:** Jarring transitions between acts
**Solution:** Use transition scenes to bridge intensity changes
