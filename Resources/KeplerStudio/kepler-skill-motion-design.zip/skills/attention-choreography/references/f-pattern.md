# F-Pattern Implementation

Detailed implementation guide for F-pattern reading choreography.

## Pattern Overview

The F-pattern describes how users scan text-heavy pages:

```
╔══════════════════════════════════════╗
║ ████████████████████████████████     ║ ← First horizontal sweep
║ ████████████████████                 ║
║ █████████████████████████            ║ ← Second horizontal sweep
║ ███████████████                      ║
║ █████                                ║ ← Vertical scan
║ ████                                 ║
║ ███                                  ║
║ ██                                   ║
╚══════════════════════════════════════╝
```

## Animation Sequence

### Zone Priority

| Zone | Grid Position | Stagger Delay | Intensity |
|------|---------------|---------------|-----------|
| Top-left | rows 1-2, cols 1-2 | 0ms | 1.0 |
| Top-right | rows 1-2, cols 3-4 | 60ms | 0.85 |
| Mid-left | rows 3-4, cols 1-2 | 120ms | 0.7 |
| Mid-right | rows 3-4, cols 3-4 | 180ms | 0.55 |
| Bottom | rows 5+, col 1 | 240ms | 0.4 |

### Implementation

```javascript
const fPatternAnimation = {
  zones: [
    {
      name: 'top-left',
      selector: '[data-zone="top-left"]',
      delay: 0,
      animation: {
        from: { opacity: 0, y: 20 },
        to: { opacity: 1, y: 0 },
        duration: 400,
        easing: 'emphasized-decelerate'
      }
    },
    {
      name: 'top-right',
      selector: '[data-zone="top-right"]',
      delay: 60,
      animation: {
        from: { opacity: 0, y: 15 },
        to: { opacity: 1, y: 0 },
        duration: 350,
        easing: 'standard-decelerate'
      }
    },
    {
      name: 'mid-left',
      selector: '[data-zone="mid-left"]',
      delay: 120,
      animation: {
        from: { opacity: 0, y: 15 },
        to: { opacity: 1, y: 0 },
        duration: 300,
        easing: 'standard-decelerate'
      }
    },
    {
      name: 'mid-right',
      selector: '[data-zone="mid-right"]',
      delay: 180,
      animation: {
        from: { opacity: 0, y: 10 },
        to: { opacity: 1, y: 0 },
        duration: 250,
        easing: 'standard'
      }
    },
    {
      name: 'bottom',
      selector: '[data-zone="bottom"]',
      delay: 240,
      animation: {
        from: { opacity: 0 },
        to: { opacity: 1 },
        duration: 200,
        easing: 'standard'
      }
    }
  ]
};
```

### Zone Detection Algorithm

```javascript
function detectFPatternZone(element, container) {
  const containerRect = container.getBoundingClientRect();
  const elRect = element.getBoundingClientRect();

  // Normalize to 0-1 range
  const normalX = (elRect.left - containerRect.left) / containerRect.width;
  const normalY = (elRect.top - containerRect.top) / containerRect.height;

  // Zone thresholds
  const horizontalMid = 0.5;
  const verticalThirds = [0.33, 0.66];

  // Determine zone
  if (normalY < verticalThirds[0]) {
    // Top third
    return normalX < horizontalMid ? 'top-left' : 'top-right';
  } else if (normalY < verticalThirds[1]) {
    // Middle third
    return normalX < horizontalMid ? 'mid-left' : 'mid-right';
  } else {
    // Bottom third - only left matters in F-pattern
    return 'bottom';
  }
}
```

### Content Type Adjustments

| Content Type | Adjustment |
|--------------|------------|
| Headlines | Prioritize in top-left |
| Navigation | Fast entrance in top-right |
| Body text | Subtle reveal in mid zones |
| Sidebar | De-prioritize in bottom |

```javascript
function adjustForContentType(element, baseConfig) {
  const contentType = element.dataset.contentType;

  const adjustments = {
    headline: { intensityBoost: 0.2, durationBoost: 1.2 },
    navigation: { speedBoost: 0.8, intensityBoost: 0 },
    body: { speedBoost: 1.1, intensityBoost: -0.1 },
    sidebar: { speedBoost: 1.2, intensityBoost: -0.2 }
  };

  const adj = adjustments[contentType] || {};

  return {
    ...baseConfig,
    duration: baseConfig.duration * (adj.speedBoost || 1),
    intensity: Math.max(0.2, baseConfig.intensity + (adj.intensityBoost || 0))
  };
}
```

## React Implementation

```tsx
import { motion, useAnimation } from 'framer-motion';
import { useEffect } from 'react';

const fPatternVariants = {
  hidden: {},
  visible: (custom: { zone: string; delay: number }) => ({
    transition: {
      delayChildren: custom.delay / 1000,
      staggerChildren: 0.03
    }
  })
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3, ease: [0.05, 0.7, 0.1, 1] }
  }
};

function FPatternContainer({ children }) {
  return (
    <div className="f-pattern-grid">
      {/* Top-left zone */}
      <motion.div
        className="zone zone--top-left"
        custom={{ zone: 'top-left', delay: 0 }}
        variants={fPatternVariants}
        initial="hidden"
        animate="visible"
      >
        {children.filter(c => c.props['data-zone'] === 'top-left')}
      </motion.div>

      {/* Top-right zone */}
      <motion.div
        className="zone zone--top-right"
        custom={{ zone: 'top-right', delay: 60 }}
        variants={fPatternVariants}
        initial="hidden"
        animate="visible"
      >
        {children.filter(c => c.props['data-zone'] === 'top-right')}
      </motion.div>

      {/* Continue for other zones... */}
    </div>
  );
}
```

## GSAP Implementation

```javascript
function playFPatternEntrance() {
  const tl = gsap.timeline();

  // Top-left: Headlines, branding
  tl.from('[data-zone="top-left"]', {
    y: 20,
    opacity: 0,
    duration: 0.4,
    stagger: 0.05,
    ease: 'power2.out'
  });

  // Top-right: Navigation, secondary
  tl.from('[data-zone="top-right"]', {
    y: 15,
    opacity: 0,
    duration: 0.35,
    stagger: 0.04,
    ease: 'power2.out'
  }, '-=0.25');

  // Mid-left: Main content start
  tl.from('[data-zone="mid-left"]', {
    y: 15,
    opacity: 0,
    duration: 0.3,
    stagger: 0.04,
    ease: 'power2.out'
  }, '-=0.2');

  // Mid-right: Secondary content
  tl.from('[data-zone="mid-right"]', {
    y: 10,
    opacity: 0,
    duration: 0.25,
    stagger: 0.03,
    ease: 'power2.out'
  }, '-=0.15');

  // Bottom: Tertiary content
  tl.from('[data-zone="bottom"]', {
    opacity: 0,
    duration: 0.2,
    stagger: 0.02,
    ease: 'power1.out'
  }, '-=0.1');

  return tl;
}
```

## Attention Decay Visualization

```
     1.0 ─┼─●──────────────────────────────────────────
         │  \
     0.8 ─┼───●────────────────────────────────────────
         │    \
     0.6 ─┼─────●──────────────────────────────────────
         │      \
     0.4 ─┼───────●────────────────────────────────────
         │         \
     0.2 ─┼──────────●─────────────────────────────────
         │
     0.0 ─┼────────────────────────────────────────────
          TL    TR    ML    MR    Bottom
```

## Best Practices

1. **Headlines in top-left** - Most attention
2. **CTAs in terminal position** - F-pattern end point
3. **Decrease animation intensity** down the page
4. **Keep top third fast** - First impression
5. **Subtle bottom animations** - Don't distract from content
