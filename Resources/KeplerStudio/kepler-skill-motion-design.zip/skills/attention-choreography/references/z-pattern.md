# Z-Pattern Implementation

Detailed implementation guide for Z-pattern reading choreography.

## Pattern Overview

The Z-pattern describes how users scan sparse, image-heavy pages:

```
╔══════════════════════════════════════╗
║ ●─────────────────────────────────●  ║
║  \                               /   ║
║   \                             /    ║
║    \                           /     ║
║     \                         /      ║
║      \         ●─────────────/       ║
║       \       /                      ║
║        \     /                       ║
║         \   /                        ║
║          \ /                         ║
║ ●─────────●──────────────────────●   ║
╚══════════════════════════════════════╝

1. Top-left (Logo/Brand)
2. Top-right (Nav/Search)
3. Center (Hero content)
4. Bottom-left (Secondary info)
5. Bottom-right (CTA)
```

## Animation Sequence

### Zone Priority

| Zone | Purpose | Stagger Delay | Emphasis |
|------|---------|---------------|----------|
| Top-left | Brand identity | 0ms | High |
| Top-right | Navigation | 50ms | Medium |
| Center | Hero content | 120ms | Highest |
| Bottom-left | Supporting | 200ms | Low |
| Bottom-right | CTA | 280ms | High |

### Implementation

```javascript
const zPatternAnimation = {
  path: [
    {
      zone: 'top-left',
      delay: 0,
      intensity: 0.9,
      animation: {
        opacity: [0, 1],
        scale: [0.95, 1],
        duration: 350,
        easing: 'emphasized-decelerate'
      }
    },
    {
      zone: 'top-right',
      delay: 50,
      intensity: 0.7,
      animation: {
        opacity: [0, 1],
        x: [20, 0],
        duration: 300,
        easing: 'standard-decelerate'
      }
    },
    {
      zone: 'center',
      delay: 120,
      intensity: 1.0,
      animation: {
        opacity: [0, 1],
        scale: [0.9, 1],
        y: [30, 0],
        duration: 450,
        easing: 'emphasized-decelerate'
      }
    },
    {
      zone: 'bottom-left',
      delay: 200,
      intensity: 0.5,
      animation: {
        opacity: [0, 1],
        y: [15, 0],
        duration: 250,
        easing: 'standard'
      }
    },
    {
      zone: 'bottom-right',
      delay: 280,
      intensity: 0.95,
      animation: {
        opacity: [0, 1],
        scale: [0.9, 1],
        duration: 400,
        easing: 'back.out(1.7)'
      }
    }
  ]
};
```

### Zone Detection

```javascript
function detectZPatternZone(element, container) {
  const containerRect = container.getBoundingClientRect();
  const elRect = element.getBoundingClientRect();

  // Element center
  const centerX = (elRect.left + elRect.width/2 - containerRect.left) / containerRect.width;
  const centerY = (elRect.top + elRect.height/2 - containerRect.top) / containerRect.height;

  // Zone boundaries
  const topThreshold = 0.35;
  const bottomThreshold = 0.65;
  const leftThreshold = 0.35;
  const rightThreshold = 0.65;

  if (centerY < topThreshold) {
    return centerX < 0.5 ? 'top-left' : 'top-right';
  } else if (centerY > bottomThreshold) {
    return centerX < 0.5 ? 'bottom-left' : 'bottom-right';
  } else {
    return 'center';
  }
}
```

## Landing Page Optimization

### Hero Section (Center Zone)

Maximum impact animation for the hero:

```javascript
const heroAnimation = gsap.timeline();

// Background/image
heroAnimation.from('.hero-bg', {
  scale: 1.1,
  opacity: 0,
  duration: 0.8,
  ease: 'power2.out'
});

// Headline
heroAnimation.from('.hero-headline', {
  y: 40,
  opacity: 0,
  duration: 0.5,
  ease: 'power2.out'
}, '-=0.4');

// Subheadline
heroAnimation.from('.hero-subheadline', {
  y: 30,
  opacity: 0,
  duration: 0.4,
  ease: 'power2.out'
}, '-=0.25');

// CTA buttons
heroAnimation.from('.hero-cta', {
  y: 20,
  opacity: 0,
  scale: 0.95,
  duration: 0.35,
  stagger: 0.1,
  ease: 'back.out(1.5)'
}, '-=0.2');
```

### CTA Zone (Bottom-Right)

Emphasis animation for conversion:

```javascript
const ctaAnimation = gsap.timeline({ delay: 0.28 });

// Primary CTA
ctaAnimation.from('.primary-cta', {
  opacity: 0,
  scale: 0.9,
  duration: 0.4,
  ease: 'back.out(2)'
});

// Attention pulse (optional)
ctaAnimation.to('.primary-cta', {
  boxShadow: '0 0 0 8px rgba(33, 150, 243, 0.3)',
  duration: 0.5,
  ease: 'power2.out',
  yoyo: true,
  repeat: 1
}, '+=0.5');
```

## React Implementation

```tsx
function ZPatternLanding() {
  return (
    <motion.div className="landing-page">
      {/* Top-left: Brand */}
      <motion.header
        className="zone--top-left"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.35, ease: [0.05, 0.7, 0.1, 1] }}
      >
        <Logo />
      </motion.header>

      {/* Top-right: Nav */}
      <motion.nav
        className="zone--top-right"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.05, duration: 0.3 }}
      >
        <Navigation />
      </motion.nav>

      {/* Center: Hero */}
      <motion.section
        className="zone--center hero"
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{
          delay: 0.12,
          duration: 0.45,
          ease: [0.05, 0.7, 0.1, 1]
        }}
      >
        <HeroContent />
      </motion.section>

      {/* Bottom-left: Features */}
      <motion.section
        className="zone--bottom-left"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.25 }}
      >
        <Features />
      </motion.section>

      {/* Bottom-right: CTA */}
      <motion.section
        className="zone--bottom-right"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{
          delay: 0.28,
          duration: 0.4,
          type: 'spring',
          stiffness: 200,
          damping: 15
        }}
      >
        <CallToAction />
      </motion.section>
    </motion.div>
  );
}
```

## Diagonal Flow Emphasis

Connect the Z-path with subtle visual connectors:

```javascript
function animateZPath() {
  const tl = gsap.timeline();

  // Optional: Draw Z-path connector
  tl.from('.z-path-svg path', {
    strokeDashoffset: 1000,
    duration: 1.2,
    ease: 'power2.inOut'
  });

  // Animate along path
  tl.to('.focus-indicator', {
    motionPath: {
      path: '.z-path-svg path',
      align: '.z-path-svg path',
      alignOrigin: [0.5, 0.5]
    },
    duration: 1.2,
    ease: 'power2.inOut'
  }, 0);

  return tl;
}
```

## Attention Flow Visualization

```
Zone Intensity Over Time:

     1.0 ─┼────●───────────●────────────────────●──
         │    │           │                    │
     0.8 ─┼────┤           │                    │──
         │    │           │                    │
     0.6 ─┼────┤───●───────│────────────────────│──
         │    │   │       │                    │
     0.4 ─┼────┤───┤───────│───────●────────────│──
         │    │   │       │       │            │
     0.2 ─┼────┤───┤───────┤───────┤────────────│──
         │    │   │       │       │            │
     0.0 ─┼────┴───┴───────┴───────┴────────────┴──
          0   TL  TR     Center   BL          BR
               50  120     200        280ms
```

## Best Practices

1. **Brand first** - Logo/identity in top-left
2. **Hero dominates** - Center zone gets most attention
3. **CTA last but strong** - Terminal position with emphasis
4. **Sparse layouts** - Z-pattern breaks down with dense content
5. **Clear diagonal** - Visual elements should guide the eye
