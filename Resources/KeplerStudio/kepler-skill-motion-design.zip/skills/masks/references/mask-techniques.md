# Mask Techniques Reference

Advanced masking implementations and techniques.

## SVG Masks vs CSS Masks

### When to Use Each

| Feature | SVG Mask | CSS clip-path | CSS mask |
|---------|----------|---------------|----------|
| Soft edges | ✓ | ✗ | ✓ |
| Gradient masks | ✓ | ✗ | ✓ |
| Animation | Limited | ✓ | Limited |
| Complex shapes | ✓ | ✓ | ✓ |
| Performance | Moderate | Best | Moderate |
| Browser support | Excellent | Good | Good |

### SVG Mask Example

```html
<svg width="0" height="0">
  <defs>
    <mask id="gradient-mask">
      <rect width="100%" height="100%" fill="url(#mask-gradient)"/>
    </mask>
    <linearGradient id="mask-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="white"/>
      <stop offset="100%" stop-color="black"/>
    </linearGradient>
  </defs>
</svg>

<style>
.masked-element {
  mask: url(#gradient-mask);
}
</style>
```

### CSS clip-path Shapes

```css
/* Basic shapes */
.circle { clip-path: circle(50% at center); }
.ellipse { clip-path: ellipse(50% 30% at center); }
.polygon { clip-path: polygon(50% 0%, 100% 100%, 0% 100%); }
.inset { clip-path: inset(10% 20% 30% 40%); }

/* With rounded corners */
.rounded-inset {
  clip-path: inset(10% round 20px);
}

/* Path */
.custom-path {
  clip-path: path('M0,0 L100,0 L100,100 L0,100 Z');
}
```

## Animated Circle Reveal

### From Click Position

```javascript
class ClickReveal {
  constructor(element, options = {}) {
    this.element = element;
    this.duration = options.duration || 600;
    this.easing = options.easing || 'cubic-bezier(0.4, 0, 0.2, 1)';
  }

  reveal(event) {
    const rect = this.element.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;

    // Calculate radius needed to cover entire element
    const corners = [
      { x: 0, y: 0 },
      { x: 100, y: 0 },
      { x: 100, y: 100 },
      { x: 0, y: 100 }
    ];

    const maxDistance = Math.max(...corners.map(c =>
      Math.hypot(c.x - x, c.y - y)
    ));

    this.element.animate([
      { clipPath: `circle(0% at ${x}% ${y}%)` },
      { clipPath: `circle(${maxDistance}% at ${x}% ${y}%)` }
    ], {
      duration: this.duration,
      easing: this.easing,
      fill: 'forwards'
    });
  }

  hide(event) {
    const rect = this.element.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;

    const corners = [
      { x: 0, y: 0 },
      { x: 100, y: 0 },
      { x: 100, y: 100 },
      { x: 0, y: 100 }
    ];

    const maxDistance = Math.max(...corners.map(c =>
      Math.hypot(c.x - x, c.y - y)
    ));

    this.element.animate([
      { clipPath: `circle(${maxDistance}% at ${x}% ${y}%)` },
      { clipPath: `circle(0% at ${x}% ${y}%)` }
    ], {
      duration: this.duration,
      easing: this.easing,
      fill: 'forwards'
    });
  }
}
```

## Polygon Animations

### Morphing Polygons

```javascript
class PolygonMorph {
  constructor(element) {
    this.element = element;
  }

  // Common shapes
  static shapes = {
    triangle: 'polygon(50% 0%, 100% 100%, 0% 100%)',
    square: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)',
    pentagon: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)',
    hexagon: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)',
    star: 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)',
    cross: 'polygon(35% 0%, 65% 0%, 65% 35%, 100% 35%, 100% 65%, 65% 65%, 65% 100%, 35% 100%, 35% 65%, 0% 65%, 0% 35%, 35% 35%)'
  };

  morphTo(shapeName, duration = 600) {
    const targetShape = PolygonMorph.shapes[shapeName];

    this.element.animate([
      { clipPath: getComputedStyle(this.element).clipPath },
      { clipPath: targetShape }
    ], {
      duration,
      easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
      fill: 'forwards'
    });
  }

  // Animate through sequence
  sequence(shapes, interval = 1000) {
    let index = 0;

    const next = () => {
      this.morphTo(shapes[index]);
      index = (index + 1) % shapes.length;
    };

    next();
    setInterval(next, interval);
  }
}
```

### Dynamic Polygon Generation

```javascript
function generatePolygon(sides, rotation = 0, radius = 50) {
  const points = [];
  const angleStep = (Math.PI * 2) / sides;
  const rotationRad = rotation * Math.PI / 180;

  for (let i = 0; i < sides; i++) {
    const angle = i * angleStep + rotationRad - Math.PI / 2;
    const x = 50 + Math.cos(angle) * radius;
    const y = 50 + Math.sin(angle) * radius;
    points.push(`${x}% ${y}%`);
  }

  return `polygon(${points.join(', ')})`;
}

// Animate rotation
function animatePolygonRotation(element, sides, duration = 2000) {
  const startTime = performance.now();

  function animate(time) {
    const progress = ((time - startTime) % duration) / duration;
    const rotation = progress * 360;

    element.style.clipPath = generatePolygon(sides, rotation);
    requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}
```

## Gradient Masks

### Animated Gradient Wipe

```javascript
class GradientWipe {
  constructor(element, options = {}) {
    this.element = element;
    this.direction = options.direction || 'right';
    this.softness = options.softness || 10;
  }

  getGradientAngle() {
    const angles = {
      right: 90,
      left: 270,
      down: 180,
      up: 0,
      'diagonal-down': 135,
      'diagonal-up': 45
    };
    return angles[this.direction] || 90;
  }

  reveal(duration = 600) {
    const angle = this.getGradientAngle();
    const startTime = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      const pos = eased * (100 + this.softness);

      this.element.style.maskImage = `
        linear-gradient(
          ${angle}deg,
          black ${pos - this.softness}%,
          transparent ${pos}%
        )
      `;

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        this.element.style.maskImage = 'none';
      }
    };

    this.element.style.maskImage = `
      linear-gradient(${angle}deg, black 0%, transparent 0%)
    `;

    requestAnimationFrame(animate);
  }

  hide(duration = 600) {
    const angle = this.getGradientAngle() + 180;
    const startTime = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      const pos = eased * (100 + this.softness);

      this.element.style.maskImage = `
        linear-gradient(
          ${angle}deg,
          transparent ${pos - this.softness}%,
          black ${pos}%
        )
      `;

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }
}
```

### Radial Spotlight

```javascript
class SpotlightMask {
  constructor(element, options = {}) {
    this.element = element;
    this.spotlightSize = options.size || 20;
    this.softness = options.softness || 10;
  }

  follow(event) {
    const rect = this.element.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;

    this.element.style.maskImage = `
      radial-gradient(
        circle at ${x}% ${y}%,
        black ${this.spotlightSize}%,
        transparent ${this.spotlightSize + this.softness}%
      )
    `;
  }

  bind() {
    this.element.addEventListener('mousemove', (e) => this.follow(e));
    this.element.addEventListener('mouseleave', () => {
      this.element.style.maskImage = 'none';
    });
  }

  animate(fromX, fromY, toX, toY, duration = 1000) {
    const startTime = performance.now();

    const update = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      const x = fromX + (toX - fromX) * eased;
      const y = fromY + (toY - fromY) * eased;

      this.element.style.maskImage = `
        radial-gradient(
          circle at ${x}% ${y}%,
          black ${this.spotlightSize}%,
          transparent ${this.spotlightSize + this.softness}%
        )
      `;

      if (progress < 1) {
        requestAnimationFrame(update);
      }
    };

    requestAnimationFrame(update);
  }
}
```

## Text Clipping

### Image Through Text

```html
<div class="text-clip-container">
  <div class="background-image"></div>
  <div class="text-mask">REVEAL</div>
</div>

<style>
.text-clip-container {
  position: relative;
}

.background-image {
  position: absolute;
  inset: 0;
  background: url('image.jpg') center/cover;
  clip-path: url(#text-clip-path);
}

.text-mask {
  font-size: 100px;
  font-weight: bold;
  color: transparent;
}
</style>
```

### Animated Text Reveal

```javascript
class TextMaskReveal {
  constructor(container, options = {}) {
    this.container = container;
    this.text = options.text || container.textContent;
    this.mode = options.mode || 'character'; // 'character', 'word', 'line'
    this.stagger = options.stagger || 50;
  }

  setup() {
    this.container.innerHTML = '';
    this.elements = [];

    const split = this.splitText();

    split.forEach((item, index) => {
      const wrapper = document.createElement('span');
      wrapper.style.display = 'inline-block';
      wrapper.style.overflow = 'hidden';

      const inner = document.createElement('span');
      inner.textContent = item;
      inner.style.display = 'inline-block';
      inner.style.transform = 'translateY(100%)';

      wrapper.appendChild(inner);
      this.container.appendChild(wrapper);

      if (item === ' ') {
        wrapper.innerHTML = '&nbsp;';
      }

      this.elements.push(inner);
    });
  }

  splitText() {
    switch (this.mode) {
      case 'character':
        return this.text.split('');
      case 'word':
        return this.text.split(' ').flatMap((word, i, arr) =>
          i < arr.length - 1 ? [word, ' '] : [word]
        );
      case 'line':
        return this.text.split('\n');
      default:
        return [this.text];
    }
  }

  reveal() {
    this.elements.forEach((el, i) => {
      el.animate([
        { transform: 'translateY(100%)' },
        { transform: 'translateY(0%)' }
      ], {
        duration: 400,
        delay: i * this.stagger,
        easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
        fill: 'forwards'
      });
    });
  }

  hide() {
    this.elements.forEach((el, i) => {
      el.animate([
        { transform: 'translateY(0%)' },
        { transform: 'translateY(-100%)' }
      ], {
        duration: 300,
        delay: i * (this.stagger * 0.5),
        easing: 'cubic-bezier(0.4, 0, 1, 1)',
        fill: 'forwards'
      });
    });
  }
}
```

## Composite Masks

### Multi-Shape Reveal

```javascript
class CompositeReveal {
  constructor(element) {
    this.element = element;
    this.shapes = [];
  }

  addCircle(x, y, radius) {
    this.shapes.push({ type: 'circle', x, y, radius, currentRadius: 0 });
  }

  generateMask() {
    if (this.shapes.length === 0) {
      return 'none';
    }

    const gradients = this.shapes.map((shape, i) => {
      if (shape.type === 'circle') {
        return `radial-gradient(circle at ${shape.x}% ${shape.y}%, black ${shape.currentRadius}%, transparent ${shape.currentRadius}%)`;
      }
      return '';
    }).filter(Boolean);

    return gradients.join(', ');
  }

  reveal(duration = 1000) {
    const startTime = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      this.shapes.forEach((shape, i) => {
        const delay = i * 0.1;
        const adjustedProgress = Math.max(0, Math.min(1, (eased - delay) / (1 - delay)));
        shape.currentRadius = shape.radius * adjustedProgress;
      });

      this.element.style.maskImage = this.generateMask();
      this.element.style.webkitMaskComposite = 'destination-over';

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }
}

// Usage
const composite = new CompositeReveal(element);
composite.addCircle(30, 30, 50);
composite.addCircle(70, 70, 60);
composite.addCircle(50, 50, 80);
composite.reveal();
```

## Performance Optimization

### Using will-change

```css
.masked-element {
  will-change: clip-path;
}

/* Remove after animation */
.masked-element.animation-complete {
  will-change: auto;
}
```

### Prefer clip-path over mask

```javascript
// clip-path is GPU-accelerated
element.style.clipPath = 'circle(50%)';

// mask can be slower
element.style.maskImage = 'radial-gradient(...)';
```

### Debounce interactive masks

```javascript
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// For mouse-following masks
element.addEventListener('mousemove', debounce((e) => {
  updateMaskPosition(e);
}, 16)); // ~60fps
```
