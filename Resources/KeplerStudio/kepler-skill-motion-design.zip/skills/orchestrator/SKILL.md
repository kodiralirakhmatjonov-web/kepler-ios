---
name: orchestrator
description: Autonomous decision engine for generating complete animations from high-level descriptions. Use when you need to parse natural language animation requests, apply narrative intentionality, resolve parameters, select Disney principles, and output production-ready code with story coherence.
---

# Motion Orchestrator

Autonomous decision engine for generating complete animations from high-level descriptions. The orchestrator parses input, applies narrative intentionality, resolves parameters via unified pipeline, selects appropriate Disney principles, and outputs production-ready code.

## Orchestration Pipeline (v3.0 — Narrative + Resolution)

```
Input Description
       │
       ▼
┌──────────────────┐
│   Input Parser   │ → Extract: element, action, emotion, brand, platform
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Intent Parser   │ → What PURPOSE? (clarify/guide/confirm/warn/celebrate/reveal)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Journey State   │ → Where emotionally? (curious/engaged/accomplished)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Narrative Arc   │ → What story phase? (exposition/rising/climax/resolution)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Scene Composer   │ → Dramaturgical structure (beats, pauses, rhythm)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Attention Path   │ → Reading order (F-pattern/Z-pattern/center-out)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Consequence     │ → Cause-effect chains (direct/ripple/cascade/echo)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│   Microstate     │ → Component state machines (idle→active→success)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Recipe Matcher   │ → Find matching recipe or compose new
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│Parameter Resolver│ → Merge recipe + emotion + brand + platform
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│Principle Select  │ → Which Disney principles apply?
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│Conflict Resolver │ → Handle competing requirements
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Code Generator   │ → Output for target platform
└────────┬─────────┘
         │
         ▼
   Complete Animation with Story
```

## Narrative Layer (v3.0)

### Intent Detection

Parse semantic purpose from the request:

| Keywords | Intent | Speed | Intensity |
|----------|--------|-------|-----------|
| explain, show, reveal | `clarify` | measured | 0.4 |
| lead, direct, point | `guide` | deliberate | 0.5 |
| done, saved, submitted | `confirm` | responsive | 0.6 |
| error, danger, alert | `warn` | urgent | 0.8 |
| success, complete, win | `celebrate` | expressive | 1.0 |
| unveil, discover, unlock | `reveal` | dramatic | 0.7 |

### Journey State Detection

Determine user's emotional position:

| Context | Journey State | Next States |
|---------|---------------|-------------|
| First interaction | `curious` | engaged, confused |
| Active engagement | `engaged` | accomplished, frustrated |
| Task completed | `accomplished` | delighted, engaged |
| Multiple successes | `delighted` | neutral |

### Arc Phase Selection

Map to Freytag's pyramid for UI:

| Duration | Arc Preset | Phases |
|----------|------------|--------|
| <400ms | `micro` | incident → climax → resolution |
| 400-800ms | `short` | exposition → rising → climax → resolution |
| 800-2000ms | `medium` | all five phases |
| >2000ms | `extended` | full with sub-beats |

### Consequence Chain Selection

| Pattern | Timing | Use Case |
|---------|--------|----------|
| `direct` | 0ms | Immediate feedback |
| `ripple` | 30ms/step | Radiating effects |
| `cascade` | 50ms/step | Sequential flow |
| `echo` | 200ms | Delayed reflection |

## Phase 1: Input Parser

### Element Detection

| Keywords | Element Type |
|----------|--------------|
| button, btn, cta | `button` |
| card, tile, panel | `card` |
| modal, dialog, overlay | `modal` |
| list, items, grid | `list` |
| toast, notification | `toast` |
| menu, dropdown | `dropdown` |

### Action Detection

| Keywords | Action Type |
|----------|-------------|
| click, press, tap | `press` |
| hover, mouse over | `hover` |
| enter, appear, show | `entrance` |
| exit, leave, close | `exit` |
| error, fail | `error` |
| success, complete | `success` |

### Emotion Detection

| Keywords | Emotion |
|----------|---------|
| bouncy, fun, playful | `playful` |
| elegant, refined, subtle | `professional` |
| celebratory, exciting | `celebratory` |
| calming, gentle | `calming` |
| urgent, important | `urgent` |

## Phase 2: Parameter Resolution

### Resolution Order

```
Recipe (base) → Emotion (modifier) → Brand (constraint) → Platform (adaptation) → Bounds → Accessibility (override)
```

### Resolution Algorithm

```typescript
function resolveParameters(
  recipe: Recipe,
  emotions: WeightedEmotion[],
  brand: Brand,
  platform: Platform,
  context: Context
): ResolvedParams {
  // 1. Start with recipe base
  let duration = recipe.duration;
  let easing = recipe.easing;
  let exaggeration = recipe.exaggeration ?? 1.0;

  // 2. Blend emotions (weighted average for numeric, dominant for discrete)
  const blendedEmotion = blendEmotions(emotions);

  // 3. Apply blended emotion as modifier
  if (blendedEmotion) {
    duration *= blendedEmotion.durationMultiplier;
    easing = blendedEmotion.easing ?? easing;
    exaggeration *= blendedEmotion.exaggerationBoost ?? 1.0;
  }

  // 4. Apply brand constraints (caps, not multipliers)
  if (brand) {
    exaggeration = Math.min(exaggeration, brand.maxExaggeration);
    if (!brand.allowsSquashStretch) squashStretch = "none";
  }

  // 5. Apply platform adaptation
  duration *= platform.durationMultiplier;

  // 6. Clamp to bounds
  duration = clamp(duration, platform.minDuration, platform.maxDuration);

  // 7. Accessibility override (bypasses all above)
  if (context.reducedMotion) {
    return recipe.reducedMotion ?? DEFAULT_REDUCED_MOTION;
  }

  return { duration, easing, exaggeration, ... };
}
```

### Platform Multipliers

| Platform | Duration | Max | Min |
|----------|----------|-----|-----|
| web | 1.0× | 600ms | 50ms |
| video | 0.6× | 400ms | 50ms |
| mobile | 1.1× | 500ms | 50ms |

### Resolution Checklist

- [ ] Emotions blended before applying (prevents stacking)
- [ ] Brand constraints enforced (caps exaggeration, disables features)
- [ ] Platform multiplier applied
- [ ] Duration clamped to bounds
- [ ] Reduced motion checked last (overrides all)

## Phase 3: Principle Selection

### Decision Tree

```
Does it bounce or impact?
  Yes -> SQUASH-STRETCH
  No  -> Skip

Does it move through space?
  Yes -> ARC-MOTION
  No  -> Linear path OK

Is it a significant action?
  Yes -> ANTICIPATION (15-25% of total)
  No  -> Skip

Are there secondary elements?
  Yes -> FOLLOW-THROUGH (10-30% stagger)
  No  -> Single element
```

## Phase 4: Conflict Resolution

### Priority Rules

1. **Accessibility > Everything** - Reduced motion always wins
2. **Brand > Emotion** - Brand consistency trumps momentary emotion
3. **Context > Defaults** - Device capability limits animations
4. **Duration Conflicts** - Average within brand bounds

```typescript
function resolveConflicts(params: Parameters, context: Context): Parameters {
  if (context.reducedMotion) {
    params = applyReducedMotionLimits(params);
  }
  params = clampToBrandLimits(params, context.brand);
  params = clampToDeviceLimits(params, context.device);
  return params;
}
```

## Phase 5: Output Generation

### Platform Selection

| Platform | Output Format |
|----------|---------------|
| CSS | Keyframes + transitions + media queries |
| GSAP | Timeline with tweens |
| Framer Motion | Variants + transitions |
| Remotion | Interpolate functions + spring |

## Autonomous Generation Workflow

When generating animations autonomously:

1. **Parse the request** using keyword detection
2. **Match to recipe** or compose from principles
3. **Apply emotion** if specified or inferred
4. **Apply brand** constraints
5. **Check accessibility** requirements
6. **Generate code** for all platforms
7. **Include reduced motion** alternative
8. **Document token references**

### Decision Checklist

- [ ] Element type identified
- [ ] Action type identified
- [ ] Platform identified (web/video/mobile)
- [ ] Emotion determined (explicit or inferred)
- [ ] Emotions blended if multiple
- [ ] Parameters resolved via resolution pipeline
- [ ] Brand constraints applied (caps, not stacking)
- [ ] Duration within platform bounds (50-600ms web, 50-400ms video)
- [ ] **Intent parsed** (clarify/guide/confirm/warn/celebrate/reveal)
- [ ] **Journey state identified** (curious/engaged/accomplished)
- [ ] **Narrative arc selected** (micro/short/medium/extended)
- [ ] **Attention path planned** (F-pattern/Z-pattern/center-out)
- [ ] **Consequence chain defined** (direct/ripple/cascade/echo)
- [ ] **Microstate machine configured** (component states + transitions)
- [ ] Disney principles selected
- [ ] Conflicts resolved
- [ ] Code generated for target platform
- [ ] Reduced motion included
- [ ] Performance considerations noted
- [ ] Determinism verified (same inputs = same outputs)

## Related Skills

### Core
- `choice-resolution/` - Unified parameter resolution pipeline
- `motion-principles/` - Disney 12 principles
- `easing/` - Easing curve selection
- `duration/` - Duration token selection
- `accessibility/` - Reduced motion requirements
- `animation-recipes/` - Recipe definitions and selection
- `emotion-mapping/` - Emotion-to-parameter mapping
- `platform-adaptation/` - Platform-specific adjustments
- `tools/` - Platform-specific code generation

### Narrative (v3.0)
- `intent/` - Semantic motion purpose
- `emotional-journey/` - User emotional state machine
- `narrative-arc/` - Story structure for motion
- `dramaturgy/` - Scene composition and pacing
- `attention-choreography/` - Reading order and gaze paths
- `consequence/` - Cause-effect animation chains
- `microstate/` - Component state orchestration

See `references/` for complete recipe matching tables and emotion mapping.
