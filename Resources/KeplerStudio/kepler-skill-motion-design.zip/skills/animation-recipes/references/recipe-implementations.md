# Recipe Implementations

Complete code examples for all animation recipes across platforms.

## Button Press

### CSS
```css
.button {
  transition: transform var(--duration-short-4) var(--ease-emphasized-decelerate);
}
.button:active {
  transform: scale(0.95);
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce) {
  .button:active {
    opacity: 0.8;
    transform: none;
    transition: opacity 50ms;
  }
}
```

### Framer Motion
```typescript
const buttonVariants = {
  idle: { scale: 1 },
  pressed: {
    scale: 0.95,
    transition: { duration: 0.2, ease: [0.05, 0.7, 0.1, 1] }
  }
};
```

### GSAP
```javascript
gsap.to(button, {
  scale: 0.95,
  duration: 0.2,
  ease: 'power3.out'
});
```

### Remotion
```typescript
const scale = interpolate(
  frame,
  [0, 6],
  [1, 0.95],
  { easing: Easing.bezier(0.05, 0.7, 0.1, 1) }
);
```

---

## Success Notification

### CSS
```css
@keyframes success-enter {
  0% {
    opacity: 0;
    transform: scale(0.8) translateY(20px);
  }
  50% {
    transform: scale(1.05) translateY(-2px);
  }
  100% {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.notification-success {
  animation: success-enter 300ms cubic-bezier(0.34, 1.56, 0.64, 1);
}

@media (prefers-reduced-motion: reduce) {
  .notification-success {
    animation: none;
    opacity: 1;
    transition: opacity 100ms;
  }
}
```

### Framer Motion
```typescript
const successVariants = {
  hidden: { opacity: 0, scale: 0.8, y: 20 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      type: 'spring',
      damping: 10,
      stiffness: 180
    }
  }
};
```

---

## Error Shake

### CSS
```css
@keyframes error-shake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-8px); }
  40% { transform: translateX(8px); }
  60% { transform: translateX(-6px); }
  80% { transform: translateX(4px); }
}

.input-error {
  animation: error-shake 150ms ease-out;
  border-color: var(--color-error);
}

@media (prefers-reduced-motion: reduce) {
  .input-error {
    animation: none;
    box-shadow: 0 0 0 2px var(--color-error);
  }
}
```

### Framer Motion
```typescript
const shakeVariants = {
  shake: {
    x: [0, -8, 8, -6, 4, 0],
    transition: { duration: 0.15 }
  }
};
```

### GSAP
```javascript
gsap.to(element, {
  keyframes: [
    { x: -8, duration: 0.03 },
    { x: 8, duration: 0.03 },
    { x: -6, duration: 0.03 },
    { x: 4, duration: 0.03 },
    { x: 0, duration: 0.03 }
  ]
});
```

---

## Modal Entrance

### CSS
```css
.modal-backdrop {
  opacity: 0;
  transition: opacity var(--duration-medium-1) var(--ease-standard);
}
.modal-backdrop.open {
  opacity: 1;
  backdrop-filter: blur(4px);
}

.modal-content {
  opacity: 0;
  transform: scale(0.95) translateY(16px);
  transition: all var(--duration-medium-1) var(--ease-emphasized-decelerate);
}
.modal-content.open {
  opacity: 1;
  transform: scale(1) translateY(0);
}

@media (prefers-reduced-motion: reduce) {
  .modal-content {
    transform: none;
    transition: opacity 100ms;
  }
}
```

### Framer Motion
```typescript
const modalVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 16 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: { duration: 0.2, ease: [0.3, 0, 0.8, 0.15] }
  }
};
```

---

## Page Transition

### Framer Motion (Next.js/React Router)
```typescript
const pageVariants = {
  initial: (direction: number) => ({
    x: direction > 0 ? 30 : -30,
    opacity: 0
  }),
  animate: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.3, ease: [0.05, 0.7, 0.1, 1] }
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -30 : 30,
    opacity: 0,
    transition: { duration: 0.3, ease: [0.3, 0, 0.8, 0.15] }
  })
};
```

### Remotion
```typescript
export const PageTransition: React.FC<{
  frame: number;
  direction: 'forward' | 'backward';
}> = ({ frame, direction }) => {
  const exitX = direction === 'forward' ? -30 : 30;
  const enterX = direction === 'forward' ? 30 : -30;

  const x = interpolate(frame, [0, 9], [enterX, 0], {
    easing: Easing.bezier(0.05, 0.7, 0.1, 1),
    extrapolateRight: 'clamp'
  });

  const opacity = interpolate(frame, [0, 6], [0, 1], {
    extrapolateRight: 'clamp'
  });

  return <div style={{ transform: `translateX(${x}px)`, opacity }} />;
};
```

---

## List Stagger

### Framer Motion
```typescript
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }
  }
};
```

### GSAP
```javascript
gsap.from('.list-item', {
  opacity: 0,
  y: 16,
  duration: 0.25,
  ease: 'power3.out',
  stagger: {
    each: 0.05,
    from: 'start'
  }
});
```

### Remotion
```typescript
const getStaggerDelay = (index: number, fps: number) =>
  Math.round((index * 50 / 1000) * fps);

export const ListItem: React.FC<{ frame: number; index: number }> =
  ({ frame, index }) => {
    const delay = getStaggerDelay(index, 30);
    const localFrame = Math.max(0, frame - delay);

    const opacity = interpolate(localFrame, [0, 8], [0, 1], {
      extrapolateRight: 'clamp'
    });
    const y = interpolate(localFrame, [0, 8], [16, 0], {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateRight: 'clamp'
    });

    return <div style={{ opacity, transform: `translateY(${y}px)` }} />;
  };
```

---

## Card Hover

### CSS
```css
.card {
  transition: transform var(--duration-short-3) var(--ease-standard-decelerate),
              box-shadow var(--duration-short-3) var(--ease-standard-decelerate);
}

.card:hover {
  transform: translateY(-4px) scale(1.02);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
}

@media (prefers-reduced-motion: reduce) {
  .card:hover {
    transform: none;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  }
}
```

---

## Hero Reveal

### Framer Motion
```typescript
const heroContainerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1, delayChildren: 0 }
  }
};

const heroItemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: [0.05, 0.7, 0.1, 1] }
  }
};

const ctaVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.35, ease: [0.05, 0.7, 0.1, 1], delay: 0.35 }
  }
};
```

---

## Form Animations

### Input Focus (CSS)
```css
.input-wrapper {
  position: relative;
}

.input-label {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  transition: all var(--duration-short-3) var(--ease-standard-decelerate);
  pointer-events: none;
}

.input:focus + .input-label,
.input:not(:placeholder-shown) + .input-label {
  top: 0;
  transform: translateY(-50%) scale(0.85);
  color: var(--color-primary);
}

.input {
  border: 2px solid var(--color-border);
  transition: border-color var(--duration-short-3) var(--ease-standard-decelerate),
              box-shadow var(--duration-short-3) var(--ease-standard-decelerate);
}

.input:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px var(--color-primary-alpha);
}
```

### Checkbox Toggle (CSS)
```css
.checkbox-check {
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
  transition: stroke-dashoffset var(--duration-short-3) var(--ease-emphasized-decelerate);
}

.checkbox:checked + .checkbox-visual .checkbox-check {
  stroke-dashoffset: 0;
}

@media (prefers-reduced-motion: reduce) {
  .checkbox-check {
    transition: none;
    stroke-dashoffset: 0;
    opacity: 0;
  }
  .checkbox:checked + .checkbox-visual .checkbox-check {
    opacity: 1;
  }
}
```

### Switch Toggle

```css
.switch-knob {
  transition: transform var(--duration-short-4) cubic-bezier(0.34, 1.56, 0.64, 1);
}

.switch:checked .switch-knob {
  transform: translateX(20px);
}

.switch-track {
  transition: background-color var(--duration-short-3) var(--ease-standard);
}
```

```typescript
// Framer Motion with spring
const switchVariants = {
  off: { x: 0 },
  on: {
    x: 20,
    transition: {
      type: 'spring',
      damping: 25,
      stiffness: 300
    }
  }
};
```

---

## Combining Recipes

Multiple recipes can be combined for complex interactions:

```typescript
// Example: Modal with staggered list content
const modalWithList = {
  backdrop: recipes.modal.backdrop,
  container: {
    ...recipes.modal.entrance,
    transition: {
      ...recipes.modal.entrance.transition,
      when: 'beforeChildren'
    }
  },
  content: recipes.listStagger
};
```
