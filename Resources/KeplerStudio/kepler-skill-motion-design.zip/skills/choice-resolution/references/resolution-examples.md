# Choice Resolution Examples

Worked examples showing the full resolution pipeline from inputs to final animation parameters.

## Example 1: Video Payment Success

A payment confirmation animation for a video about a fintech app.

### Inputs

| Layer | Value |
|-------|-------|
| Recipe | `success-notification` |
| Emotions | `celebratory` (70%), `trustworthy` (30%) |
| Brand | `professional` |
| Platform | `video` |
| Context | `{ reducedMotion: false }` |

### Resolution Steps

**Step 1: Recipe Base**
```json
{
  "duration": 300,
  "easing": "spring-bouncy",
  "exaggeration": 1.0,
  "squash-stretch": "subtle",
  "follow-through": "medium",
  "secondary-effects": ["glow"]
}
```

**Step 2: Blend Emotions**
```
celebratory (0.7):
  - duration-multiplier: 1.2
  - exaggeration-boost: 1.0 (expressive)
  - particles: true

trustworthy (0.3):
  - duration-multiplier: 1.1
  - exaggeration-boost: 0.5 (subtle)
  - particles: false

Blended result:
  - duration-multiplier: (1.2 × 0.7) + (1.1 × 0.3) = 1.17
  - exaggeration: weighted toward celebratory
  - easing: spring-bouncy (from dominant celebratory)
  - particles: true (union - either enables)
```

**Step 3: Apply Emotion Modifier**
```json
{
  "duration": 300 × 1.17 = 351,
  "easing": "spring-bouncy",
  "exaggeration": 1.0 × 1.0 = 1.0,
  "squash-stretch": "subtle",
  "secondary-effects": ["glow", "particles"]
}
```

**Step 4: Apply Brand Constraints**
```
professional:
  - max-exaggeration: "subtle" (0.5)
  - allows-squash-stretch: false
  - allows-particles: false

After brand:
  - exaggeration: min(1.0, 0.5) = 0.5
  - squash-stretch: "none"
  - secondary-effects: ["glow"] (particles removed)
```

**Step 5: Apply Platform Adaptation**
```
video:
  - duration-multiplier: 0.6
  - max-duration: 400ms

duration: 351 × 0.6 = 210.6ms
```

**Step 6: Clamp to Bounds**
```
video bounds: 50-400ms
210.6ms → 211ms (rounded, within bounds) ✓
```

**Step 7: Accessibility Check**
```
reducedMotion: false → proceed with resolved values
```

### Final Output

```json
{
  "duration": 211,
  "easing": "spring-bouncy",
  "exaggeration": 0.5,
  "squash-stretch": "none",
  "follow-through": "medium",
  "secondary-effects": ["glow"]
}
```

---

## Example 2: Playful Button Press on Mobile

A button animation for a children's educational app.

### Inputs

| Layer | Value |
|-------|-------|
| Recipe | `button-press` |
| Emotion | `playful` |
| Brand | `playful` |
| Platform | `mobile` |
| Context | `{ reducedMotion: false }` |

### Resolution Steps

**Step 1: Recipe Base**
```json
{
  "duration": 200,
  "easing": "emphasized-decelerate",
  "exaggeration": 0.5,
  "squash-stretch": "subtle",
  "anticipation": "micro"
}
```

**Step 2: Apply Emotion (single, no blending)**
```
playful:
  - duration-multiplier: 1.1
  - exaggeration: "expressive" (1.0)
  - squash-stretch: "medium"
  - easing: "spring-bouncy"
```

**Step 3: After Emotion**
```json
{
  "duration": 200 × 1.1 = 220,
  "easing": "spring-bouncy",
  "exaggeration": 0.5 × 1.0 = 0.5,
  "squash-stretch": "medium",
  "anticipation": "small"
}
```

**Step 4: Apply Brand Constraints**
```
playful brand:
  - max-exaggeration: "expressive" (1.0)
  - allows-squash-stretch: true
  - allows-bounce: true

No constraints applied (all within limits)
```

**Step 5: Apply Platform**
```
mobile:
  - duration-multiplier: 1.1
  - max-duration: 500ms

duration: 220 × 1.1 = 242ms
```

**Step 6: Clamp**
```
242ms within 50-500ms ✓
```

### Final Output

```json
{
  "duration": 242,
  "easing": "spring-bouncy",
  "exaggeration": 0.5,
  "squash-stretch": "medium",
  "anticipation": "small"
}
```

---

## Example 3: Reduced Motion Override

Same inputs as Example 2, but with reduced motion preference.

### Inputs

| Layer | Value |
|-------|-------|
| Recipe | `button-press` |
| Emotion | `playful` |
| Brand | `playful` |
| Platform | `mobile` |
| Context | `{ reducedMotion: true }` |

### Resolution

**Steps 1-6: Same as Example 2**

**Step 7: Accessibility Override**
```
reducedMotion: true → return recipe's reduced-motion fallback
```

### Final Output

```json
{
  "type": "opacity",
  "duration": 50,
  "opacity-change": 0.2
}
```

The reduced motion variant bypasses ALL other resolution steps.

---

## Example 4: Conflicting Emotions (Security Alert)

An alert that needs to feel urgent but trustworthy.

### Inputs

| Layer | Value |
|-------|-------|
| Recipe | `error-shake` |
| Emotions | `urgent` (60%), `trustworthy` (40%) |
| Brand | `professional` |
| Platform | `web` |

### Emotion Blending

```
urgent (0.6):
  - duration-multiplier: 0.8
  - exaggeration: "moderate" (0.75)
  - easing: "emphasized-accelerate"

trustworthy (0.4):
  - duration-multiplier: 1.1
  - exaggeration: "subtle" (0.5)
  - easing: "standard-decelerate"

Blended:
  - duration-multiplier: (0.8 × 0.6) + (1.1 × 0.4) = 0.92
  - easing: "emphasized-accelerate" (dominant emotion)
  - exaggeration: (0.75 × 0.6) + (0.5 × 0.4) = 0.65
```

### Final Output

```json
{
  "duration": 138,
  "easing": "emphasized-accelerate",
  "exaggeration": 0.5,
  "amplitude": 4,
  "iterations": 2
}
```

Note: Exaggeration was capped at 0.5 (subtle) by the professional brand constraint.

---

## Example 5: Duration Stacking Without Resolution (Anti-Pattern)

This example shows what happens WITHOUT unified resolution.

### Problematic Stacking

```
Recipe duration:     300ms
× celebratory:       × 1.2 = 360ms
× first-visit:       × 1.2 = 432ms
× welcoming:         × 1.2 = 518ms
× mysterious blend:  × 1.5 = 777ms ← EXCEEDS M3 MAX (600ms)
```

### With Unified Resolution

```
Recipe duration:     300ms
Blend emotions:      celebratory + welcoming → 1.15× multiplier
Apply once:          300 × 1.15 = 345ms
Context modifier:    first-visit → applied to exaggeration, not duration
Clamp to bounds:     345ms (within 50-600ms) ✓
```

The resolution system prevents unbounded stacking by:
1. Blending emotions before applying (single multiplier)
2. Moving context modifiers to non-duration parameters
3. Final bounds clamping as safety net

---

## Example 6: Video Intro Timing

Demonstrating video-specific timing rules.

### Input

| Layer | Value |
|-------|-------|
| Recipe | `hero-reveal` |
| Emotion | `welcoming` |
| Brand | `friendly` |
| Platform | `video` |

### Recipe Base

```json
{
  "sequence": [
    { "element": "background", "delay": 0, "type": "fade" },
    { "element": "headline", "delay": 100, "type": "slide-up" },
    { "element": "subhead", "delay": 200, "type": "slide-up" },
    { "element": "cta", "delay": 350, "type": "scale-in" }
  ],
  "total-duration": 350
}
```

### After Video Platform Adaptation

```
duration-multiplier: 0.6

New delays:
- background: 0ms (unchanged - immediate start)
- headline: 60ms
- subhead: 120ms
- cta: 210ms

New total: 210ms (within 400ms video max)
```

### Key Video Rules Applied

1. ✓ Content starts on first frame (no dead air)
2. ✓ Total duration under 400ms
3. ✓ Transitions compressed to ~3-6 frames each

---

## Common Blend Recipes

| Scenario | Blend | Result Character |
|----------|-------|------------------|
| Payment success | celebratory 70% + trustworthy 30% | Joyful but reliable |
| Security alert | urgent 60% + trustworthy 40% | Quick but reassuring |
| Kids app | playful 60% + calming 40% | Fun without overstimulation |
| Enterprise onboarding | professional 50% + welcoming 50% | Warm but credible |
| Game achievement | celebratory 80% + energetic 20% | Maximum excitement |
| Form error | frustrated 40% + trustworthy 60% | Corrective but supportive |

---

## Debugging Tips

When animations don't feel right:

1. **Too slow for video?** Check platform multiplier (should be 0.6×)
2. **Too bouncy for professional?** Brand constraint should cap squash-stretch
3. **Inconsistent outputs?** Check for unblended emotion stacking
4. **Particles appearing when forbidden?** Brand filter not applied after emotion union
5. **Exceeds M3 bounds?** Final clamp step may be missing
