# Intent to Parameter Mapping

Complete reference for translating semantic intent to animation parameters.

## Primary Intent Matrix

| Intent | Duration Mult | Intensity | Easing | Spring Config | Haptic |
|--------|---------------|-----------|--------|---------------|--------|
| clarify | 1.2 | 0.4 | standard-decelerate | gentle | none |
| guide | 1.1 | 0.5 | emphasized-decelerate | standard | light |
| confirm | 0.9 | 0.6 | spring-standard | snappy | medium |
| warn | 0.85 | 0.8 | emphasized-accelerate | sharp | heavy |
| celebrate | 1.3 | 1.0 | spring-bouncy | bouncy | success |
| reveal | 1.4 | 0.7 | ease-in-out-slow | gentle | light |

## Intent to Motion Property Mapping

### Clarify

```json
{
  "duration": { "multiplier": 1.2, "base": "medium-1" },
  "easing": "standard-decelerate",
  "properties": {
    "opacity": { "from": 0, "to": 1 },
    "transform": {
      "translateY": { "from": "10px", "to": "0" },
      "scale": { "from": 0.98, "to": 1 }
    }
  },
  "spring": null,
  "secondary": false
}
```

### Guide

```json
{
  "duration": { "multiplier": 1.1, "base": "medium-2" },
  "easing": "emphasized-decelerate",
  "properties": {
    "boxShadow": { "pulse": true, "color": "accent" },
    "transform": { "scale": { "pulse": [1, 1.02, 1] } }
  },
  "attention": "high",
  "secondary": {
    "pointer": true,
    "highlight": true
  }
}
```

### Confirm

```json
{
  "duration": { "multiplier": 0.9, "base": "short-4" },
  "easing": "spring",
  "spring": {
    "stiffness": 300,
    "damping": 15,
    "mass": 1
  },
  "properties": {
    "transform": { "scale": { "sequence": [0.95, 1.05, 1] } },
    "backgroundColor": { "flash": "success" }
  },
  "haptic": "light-impact"
}
```

### Warn

```json
{
  "duration": { "multiplier": 0.85, "base": "short-4" },
  "easing": "emphasized-accelerate",
  "properties": {
    "transform": {
      "translateX": { "shake": [-10, 10, -10, 10, 0] }
    },
    "borderColor": { "to": "error" }
  },
  "repetitions": 2,
  "haptic": "heavy-impact",
  "accessibility": {
    "requiresTextAlternative": true,
    "requiresIconAlternative": true
  }
}
```

### Celebrate

```json
{
  "duration": { "multiplier": 1.3, "base": "medium-2" },
  "easing": "spring",
  "spring": {
    "stiffness": 200,
    "damping": 8,
    "mass": 1
  },
  "properties": {
    "transform": { "scale": { "sequence": [0, 1.3, 1] } },
    "opacity": { "from": 0, "to": 1 }
  },
  "secondary": {
    "particles": true,
    "glow": true,
    "confetti": "optional"
  },
  "haptic": "success"
}
```

### Reveal

```json
{
  "duration": { "multiplier": 1.4, "base": "medium-2" },
  "easing": "ease-in-out-slow",
  "properties": {
    "opacity": { "from": 0, "to": 1 },
    "filter": { "blur": { "from": "10px", "to": "0" } },
    "transform": {
      "scale": { "from": 0.9, "to": 1 },
      "translateY": { "from": "20px", "to": "0" }
    }
  },
  "anticipation": {
    "enabled": true,
    "duration": 0.25
  }
}
```

## Secondary Intent Matrix

| Intent | Duration Mult | Intensity | Primary Motion |
|--------|---------------|-----------|----------------|
| connect | 1.0 | 0.5 | morph, shared-element |
| orient | 1.1 | 0.4 | parallax, perspective |
| indicate | 0.8 | 0.25 | subtle-pulse, color-shift |
| dismiss | 0.7 | 0.35 | fade-out, slide-away |
| group | 1.0 | 0.4 | synchronized, boundary |
| separate | 0.9 | 0.5 | explode, stagger-diverge |

## Context Modifier Application

### First-Time User

```javascript
function applyFirstTimeModifier(params) {
  return {
    ...params,
    duration: params.duration * 1.15,
    intensity: Math.min(params.intensity * 1.15, 1.0),
    secondary: {
      ...params.secondary,
      enabled: true
    }
  };
}
```

### Repeat Action

```javascript
function applyRepeatModifier(params) {
  return {
    ...params,
    duration: params.duration * 0.85,
    intensity: params.intensity * 0.8,
    secondary: {
      ...params.secondary,
      enabled: false
    }
  };
}
```

### Reduced Motion

```javascript
function applyReducedMotion(intent) {
  const reducedMap = {
    clarify: { opacity: true, transform: false },
    guide: { highlight: true, motion: false },
    confirm: { color: true, scale: false },
    warn: { color: true, icon: true, shake: false },
    celebrate: { icon: true, particles: false },
    reveal: { opacity: true, blur: false }
  };
  return reducedMap[intent];
}
```

## Emotion to Intent Affinity

| Emotion | Primary Intent | Secondary Intent |
|---------|----------------|------------------|
| celebratory | celebrate | confirm |
| calming | clarify | guide |
| urgent | warn | confirm |
| playful | confirm | celebrate |
| professional | clarify | confirm |
| trustworthy | confirm | clarify |
| frustrated | warn | guide |
| delightful | celebrate | reveal |
| welcoming | reveal | guide |

## Intent Sequencing Rules

### Valid Sequences

| Start | Valid Next |
|-------|------------|
| clarify | guide, confirm |
| guide | confirm, clarify |
| confirm | celebrate, clarify |
| warn | guide, clarify |
| celebrate | (terminal) |
| reveal | clarify, guide |

### Transition Timing

| From → To | Gap Duration |
|-----------|--------------|
| clarify → guide | 100ms |
| guide → confirm | 0ms (immediate) |
| confirm → celebrate | 50ms |
| warn → guide | 200ms |
| reveal → clarify | 150ms |
