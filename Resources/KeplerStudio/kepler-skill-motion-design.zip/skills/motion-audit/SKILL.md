---
name: motion-audit
description: Comprehensive checklist for auditing animations against Disney principles, accessibility standards, performance budgets, and brand consistency. Use when reviewing animation implementations.
---

# Motion Audit Checklist

Systematic review process for ensuring animations meet quality standards across Disney principles, accessibility, performance, and brand.

## Audit Process

1. **Identify** - List all animated elements
2. **Categorize** - Classify by type and importance
3. **Evaluate** - Check against each criteria
4. **Document** - Record findings and recommendations
5. **Prioritize** - Rank issues by severity

## Disney Principles Checklist

### Core Principles

- [ ] **Squash & Stretch** - Applied to impacts, volume preserved
- [ ] **Anticipation** - Wind-up before major actions (15-25%)
- [ ] **Staging** - One clear focal point per animation
- [ ] **Follow-Through** - Secondary elements lag behind
- [ ] **Slow In/Out** - Proper easing (no linear)
- [ ] **Arcs** - Physical objects move in arcs
- [ ] **Secondary Action** - Supporting animations at 30-50%
- [ ] **Timing** - Durations match token scale
- [ ] **Exaggeration** - Appropriate for brand
- [ ] **Appeal** - Motion feels polished

## Accessibility Checklist

### Reduced Motion
- [ ] `prefers-reduced-motion` is respected
- [ ] Alternative exists (opacity fade, instant)
- [ ] No essential information only in animation

### Timing & Seizures
- [ ] No flashing > 3 times/second
- [ ] User can pause/stop animations
- [ ] Duration allows content to be read

### Focus & Navigation
- [ ] Focus states are animated appropriately
- [ ] Keyboard navigation is smooth
- [ ] Screen readers announce changes

## Performance Checklist

### Frame Rate
- [ ] Maintains 60fps on target devices
- [ ] No jank during scroll animations
- [ ] Low-end device testing performed

### Paint & Layout
- [ ] Uses transform/opacity only (GPU)
- [ ] No layout thrashing (width, height, top, left)
- [ ] `will-change` used sparingly

### Bundle Size
- [ ] Animation library is code-split
- [ ] Lottie files are optimized
- [ ] No unused animation utilities

## Brand Consistency Checklist

### Token Usage
- [ ] All durations from token scale
- [ ] All easings from token library
- [ ] No hardcoded magic numbers

### Personality
- [ ] Motion matches brand adjectives
- [ ] Consistent across touchpoints
- [ ] Appropriate for audience

## Issue Severity Levels

| Level | Impact | Example | Action |
|-------|--------|---------|--------|
| **Critical** | Blocks users | Seizure-inducing flash | Immediate fix |
| **Major** | Degrades experience | 60fps to 15fps | Fix before release |
| **Minor** | Suboptimal | Linear easing | Fix when possible |
| **Enhancement** | Improvement | Add anticipation | Consider for future |

## Audit Frequency

| Trigger | Scope | Depth |
|---------|-------|-------|
| Every PR | Changed components | Quick check |
| Sprint end | New features | Full audit |
| Quarterly | Entire product | Comprehensive |
| Major release | Critical paths | Deep dive |

## Related Skills

- `motion-principles/` - Disney 12 principles reference
- `accessibility/` - WCAG compliance details
- `testing-patterns/` - Automated testing for audits
- `tools/` - Tool-specific audit considerations

See `references/` for audit scoring templates and ESLint/Stylelint rules.
