# Emotional State Transitions

Complete reference for valid state transitions and their motion characteristics.

## Transition Matrix

| From ↓ / To → | neutral | curious | engaged | focused | confused | frustrated | accomplished | delighted | anticipating |
|---------------|---------|---------|---------|---------|----------|------------|--------------|-----------|--------------|
| **neutral** | - | ✓ | ✓ | - | - | - | - | - | - |
| **curious** | ✓ | - | ✓ | - | ✓ | - | - | - | - |
| **engaged** | - | ✓ | - | ✓ | - | ✓ | ✓ | - | ✓ |
| **focused** | - | - | ✓ | - | - | ✓ | ✓ | - | - |
| **confused** | - | ✓ | ✓ | - | - | ✓ | - | - | - |
| **frustrated** | ✓ | - | ✓ | - | - | - | - | - | - |
| **accomplished** | ✓ | ✓ | ✓ | - | - | - | - | ✓ | - |
| **delighted** | ✓ | - | ✓ | - | - | - | ✓ | - | - |
| **anticipating** | - | - | ✓ | - | - | ✓ | ✓ | ✓ | - |

## Transition Details

### neutral → curious

**Trigger:** New content discovered, exploration begins

**Motion:**
```javascript
{
  type: 'reveal',
  duration: 400,
  easing: 'emphasized-decelerate',
  properties: {
    opacity: { from: 0, to: 1 },
    scale: { from: 0.95, to: 1 },
    y: { from: 20, to: 0 }
  }
}
```

**Valence change:** Neutral → Positive

---

### curious → engaged

**Trigger:** Task started, user begins interaction

**Motion:**
```javascript
{
  type: 'guide',
  duration: 300,
  easing: 'standard',
  properties: {
    highlight: true,
    pulseOnce: true
  }
}
```

**Valence change:** Remains positive

---

### engaged → accomplished

**Trigger:** Action successful, task completed

**Motion:**
```javascript
{
  type: 'confirm',
  duration: 250,
  easing: 'spring',
  spring: { stiffness: 300, damping: 15 },
  properties: {
    scale: { sequence: [1, 1.1, 1] },
    backgroundColor: 'success'
  }
}
```

**Valence change:** Remains positive (higher arousal)

---

### engaged → frustrated

**Trigger:** Action failed, error encountered

**Motion:**
```javascript
{
  type: 'warn',
  duration: 400,
  easing: 'emphasized-accelerate',
  properties: {
    shake: { x: [-10, 10], iterations: 2 },
    borderColor: 'error'
  }
}
```

**Valence change:** Positive → Negative

**Recovery required:** Yes

---

### frustrated → engaged

**Trigger:** Recovery offered, user retries

**Motion:**
```javascript
{
  type: 'guide',
  duration: 350,
  easing: 'ease-out',
  delay: 200, // Breathing room
  properties: {
    saturate: { from: 0.8, to: 1 },
    highlight: 'recovery-path'
  }
}
```

**Valence change:** Negative → Positive

---

### accomplished → delighted

**Trigger:** Milestone reached, exceptional success

**Motion:**
```javascript
{
  type: 'celebrate',
  duration: 600,
  easing: 'spring',
  spring: { stiffness: 200, damping: 8 },
  properties: {
    scale: { sequence: [1, 1.3, 1.1] },
    glow: true,
    particles: true
  }
}
```

**Valence change:** Remains positive (peak arousal)

---

### delighted → accomplished

**Trigger:** Celebration complete (auto-timeout)

**Motion:**
```javascript
{
  type: 'settle',
  duration: 400,
  easing: 'ease-out',
  properties: {
    scale: { to: 1 },
    glow: { to: 0 }
  }
}
```

**Valence change:** Remains positive (reduced arousal)

---

### engaged → focused

**Trigger:** Deep work entered, concentration mode

**Motion:**
```javascript
{
  type: 'indicate',
  duration: 200,
  easing: 'standard',
  properties: {
    ambient: 'reduce',
    distractions: 'suppress'
  }
}
```

**Valence change:** Positive → Neutral

---

### engaged → anticipating

**Trigger:** Loading started, async operation

**Motion:**
```javascript
{
  type: 'indicate',
  duration: 150,
  properties: {
    spinner: true,
    progress: true
  }
}
```

**Valence change:** Positive → Neutral

---

### anticipating → accomplished

**Trigger:** Async complete successfully

**Motion:**
```javascript
{
  type: 'confirm',
  duration: 300,
  easing: 'spring',
  properties: {
    spinner: { to: 'checkmark' },
    scale: { sequence: [1, 1.1, 1] }
  }
}
```

**Valence change:** Neutral → Positive

---

### anticipating → frustrated

**Trigger:** Async failed, timeout

**Motion:**
```javascript
{
  type: 'warn',
  duration: 300,
  properties: {
    spinner: { to: 'error-icon' },
    shake: true
  }
}
```

**Valence change:** Neutral → Negative

## Transition Timing

### Minimum Dwell Times

| State | Min Dwell | Reason |
|-------|-----------|--------|
| curious | 500ms | Allow exploration |
| engaged | 100ms | Quick interactions OK |
| focused | 5000ms | Don't interrupt deep work |
| frustrated | 0ms | Allow immediate recovery |
| delighted | 1500ms | Let joy register |

### Maximum Dwell Times

| State | Max Dwell | Action |
|-------|-----------|--------|
| frustrated | 3000ms | Force show recovery |
| delighted | 3000ms | Auto-settle to accomplished |
| anticipating | 10000ms | Show timeout option |

## Parallel States

Some states can coexist:

| Primary State | Can Coexist With |
|---------------|------------------|
| Any | focus (accessibility) |
| engaged | anticipating (partial load) |
| accomplished | anticipating (next action) |

## State Priority

When multiple transitions are valid, prioritize:

1. **Safety:** frustrated always takes precedence
2. **Recovery:** clarified > confused
3. **Progress:** accomplished > engaged
4. **Delight:** delighted if milestone, else accomplished
