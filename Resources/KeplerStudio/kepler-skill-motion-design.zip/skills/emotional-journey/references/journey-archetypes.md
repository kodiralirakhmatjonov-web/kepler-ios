# Journey Archetypes

Common emotional journeys through digital experiences.

## Archetype Overview

| Archetype | Path | Duration | Key Challenge |
|-----------|------|----------|---------------|
| Onboarding | neutral → curious → engaged → accomplished → delighted | 3-5 min | Maintain curiosity |
| Checkout | engaged → focused → anticipating → accomplished | 1-3 min | Minimize frustration |
| Error Recovery | engaged → frustrated → clarified → engaged | 10-30 sec | Quick resolution |
| Discovery | neutral → curious → engaged → curious → delighted | Variable | Reward exploration |
| Deep Work | engaged → focused → accomplished | 10+ min | Minimize distraction |
| Learning | curious → confused → clarified → engaged → accomplished | Variable | Clear explanations |

## Detailed Archetypes

### Onboarding Journey

**Path:** neutral → curious → engaged → accomplished → delighted

**Motion strategy:** Progressive revelation with celebration

**Phase breakdown:**

```
neutral (0%)
    │
    ▼ [welcome animation]
curious (10%)
    │
    ▼ [guided tour steps]
engaged (40%)
    │
    ▼ [first task complete]
accomplished (80%)
    │
    ▼ [milestone celebration]
delighted (100%)
```

**Implementation:**

```javascript
const onboardingJourney = {
  welcome: {
    from: 'neutral',
    to: 'curious',
    motion: {
      type: 'reveal',
      duration: 600,
      elements: ['logo', 'headline', 'cta'],
      stagger: 100
    }
  },

  tourStep: {
    from: 'curious',
    to: 'engaged',
    motion: {
      type: 'guide',
      spotlight: true,
      tooltip: true,
      duration: 400
    }
  },

  firstSuccess: {
    from: 'engaged',
    to: 'accomplished',
    motion: {
      type: 'confirm',
      duration: 300,
      celebration: 'mini'
    }
  },

  complete: {
    from: 'accomplished',
    to: 'delighted',
    motion: {
      type: 'celebrate',
      duration: 800,
      confetti: true,
      badge: true
    }
  }
};
```

---

### Checkout Journey

**Path:** engaged → focused → anticipating → accomplished

**Motion strategy:** Clear confirmation with minimal distraction

**Phase breakdown:**

```
engaged (0%)
    │
    ▼ [enter checkout]
focused (20%)
    │
    ▼ [form completion - reduced motion]
anticipating (80%)
    │
    ▼ [payment processing]
accomplished (100%)
```

**Implementation:**

```javascript
const checkoutJourney = {
  enterCheckout: {
    from: 'engaged',
    to: 'focused',
    motion: {
      type: 'indicate',
      duration: 200,
      dimAmbient: true,
      motionReduction: 0.5
    }
  },

  formInteraction: {
    state: 'focused',
    motion: {
      type: 'confirm',
      duration: 100, // Quick, unobtrusive
      intensity: 0.3 // Subtle
    }
  },

  submitPayment: {
    from: 'focused',
    to: 'anticipating',
    motion: {
      type: 'indicate',
      spinner: true,
      disableInputs: true
    }
  },

  paymentSuccess: {
    from: 'anticipating',
    to: 'accomplished',
    motion: {
      type: 'confirm',
      duration: 400,
      checkmark: true,
      celebration: 'subtle'
    }
  }
};
```

---

### Error Recovery Journey

**Path:** engaged → frustrated → clarified → engaged → accomplished

**Motion strategy:** Calm guidance to resolution

**Critical timing:** Keep frustrated state under 3 seconds

**Implementation:**

```javascript
const errorRecoveryJourney = {
  errorOccurs: {
    from: 'engaged',
    to: 'frustrated',
    motion: {
      type: 'warn',
      duration: 400,
      shake: true,
      maxDwell: 3000
    }
  },

  showHelp: {
    from: 'frustrated',
    to: 'clarified',
    motion: {
      type: 'clarify',
      delay: 500, // Brief pause first
      duration: 300,
      highlight: 'solution'
    }
  },

  userRetries: {
    from: 'clarified',
    to: 'engaged',
    motion: {
      type: 'guide',
      duration: 250,
      saturate: 1.0 // Restore normal
    }
  },

  retrySuccess: {
    from: 'engaged',
    to: 'accomplished',
    motion: {
      type: 'confirm',
      duration: 350,
      relief: true // Slightly extended celebration
    }
  }
};
```

---

### Discovery Journey

**Path:** neutral → curious → engaged → curious → delighted

**Motion strategy:** Reward exploration with surprise

**Implementation:**

```javascript
const discoveryJourney = {
  initialExplore: {
    from: 'neutral',
    to: 'curious',
    motion: {
      type: 'reveal',
      teatrical: true,
      duration: 500
    }
  },

  engageContent: {
    from: 'curious',
    to: 'engaged',
    motion: {
      type: 'guide',
      breadcrumbs: true
    }
  },

  discoverMore: {
    from: 'engaged',
    to: 'curious',
    motion: {
      type: 'reveal',
      surprise: true,
      duration: 400
    }
  },

  findGem: {
    from: 'curious',
    to: 'delighted',
    motion: {
      type: 'celebrate',
      easterEgg: true,
      duration: 600
    }
  }
};
```

---

### Deep Work Journey

**Path:** engaged → focused → accomplished

**Motion strategy:** Minimal distraction

**Implementation:**

```javascript
const deepWorkJourney = {
  enterFocus: {
    from: 'engaged',
    to: 'focused',
    motion: {
      type: 'indicate',
      duration: 200,
      dimInterface: true,
      hideNonEssential: true
    }
  },

  whileFocused: {
    state: 'focused',
    motion: {
      reduction: 0.5, // Half intensity
      confirmOnly: true, // Only confirm actions
      noAmbient: true
    }
  },

  completeWork: {
    from: 'focused',
    to: 'accomplished',
    motion: {
      type: 'confirm',
      duration: 250,
      celebration: 'subtle',
      restoreInterface: true
    }
  }
};
```

---

### Learning Journey

**Path:** curious → confused → clarified → engaged → accomplished

**Motion strategy:** Clear explanations at confusion points

**Implementation:**

```javascript
const learningJourney = {
  beginLesson: {
    from: 'neutral',
    to: 'curious',
    motion: {
      type: 'reveal',
      progressive: true,
      duration: 400
    }
  },

  hitObstacle: {
    from: 'curious',
    to: 'confused',
    motion: {
      type: 'indicate',
      highlight: 'help-available',
      duration: 200
    }
  },

  getHelp: {
    from: 'confused',
    to: 'clarified',
    motion: {
      type: 'clarify',
      expand: true,
      duration: 350,
      ahaEffect: true
    }
  },

  continueLesson: {
    from: 'clarified',
    to: 'engaged',
    motion: {
      type: 'guide',
      nextStep: true
    }
  },

  completeLesson: {
    from: 'engaged',
    to: 'accomplished',
    motion: {
      type: 'confirm',
      badge: true,
      progress: true
    }
  }
};
```

## Anti-Patterns

### Stuck in Frustrated

**Problem:** User remains frustrated too long
**Solution:** Force recovery path after 3 seconds

### Skipping Curious

**Problem:** Jump straight to engaged without discovery
**Solution:** Brief reveal/preview before task start

### Over-Celebrating

**Problem:** Delighted for trivial actions
**Solution:** Reserve full celebration for milestones

### No Recovery Path

**Problem:** Frustrated with no visible way out
**Solution:** Always show help/retry in frustrated state
