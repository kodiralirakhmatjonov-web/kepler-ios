# Path Types Reference

Detailed documentation for path-based motion patterns.

## Linear Motion

Straight-line movement between two points.

**When to Use:**
- Mechanical, precise UI elements
- Sliders, progress bars
- Drag operations
- Scroll-linked animations

**Characteristics:**
- No curvature
- Constant velocity when combined with linear easing
- Can feel robotic if not paired with appropriate easing

**Implementation:**
```css
transform: translateX(100px);
/* or */
transform: translate(100px, 50px);
```

## Arc Motion

Curved path that adds natural, organic feel to movement.

**When to Use:**
- Moving between significantly different positions
- Shared element transitions (M3 container transform)
- Any movement that should feel "alive"
- Objects affected by physics/gravity

**Arc Control Points:**

| Token | Control Point | Effect |
|-------|---------------|--------|
| `arc-subtle` | 0.1 | Barely curved, hint of arc |
| `arc-medium` | 0.25 | Natural curve, visible arc |
| `arc-pronounced` | 0.5 | Dramatic curve, theatrical |

**CSS Approximation:**
CSS cannot natively do arc motion. Use multiple keyframes:

```css
@keyframes arcMotion {
  0% {
    transform: translate(0, 0);
  }
  50% {
    transform: translate(50px, -25px); /* peak of arc */
  }
  100% {
    transform: translate(100px, 0);
  }
}
```

**GSAP MotionPath:**
```javascript
gsap.to(element, {
  motionPath: {
    path: [
      { x: 0, y: 0 },
      { x: 50, y: -50 }, // control point
      { x: 100, y: 20 }  // destination
    ],
    curviness: 1.5
  },
  duration: 0.5
});
```

**Framer Motion:**
```tsx
// Using keyframes for arc approximation
<motion.div
  animate={{
    x: [0, 50, 100],
    y: [0, -50, 20]
  }}
  transition={{
    duration: 0.5,
    times: [0, 0.4, 1], // peak at 40%
    ease: "easeInOut"
  }}
/>
```

## Bezier Path Motion

Custom curved paths defined by bezier control points.

**When to Use:**
- Precise path control needed
- Following specific design curves
- Logo animations, SVG path following

**SVG Path Example:**
```javascript
gsap.to(element, {
  motionPath: {
    path: "M0,0 C50,-100 150,-100 200,0", // cubic bezier
    align: "self",
    autoRotate: true
  },
  duration: 1
});
```

## Orbit Motion

Circular or elliptical motion around a center point.

**Parameters:**
- `radius` — Distance from center
- `speed` — Duration of one complete orbit
- `direction` — Clockwise or counter-clockwise
- `startAngle` — Initial position (0-360)

**Circular Orbit:**
```javascript
// Pure CSS
@keyframes orbit {
  from {
    transform: rotate(0deg) translateX(var(--radius)) rotate(0deg);
  }
  to {
    transform: rotate(360deg) translateX(var(--radius)) rotate(-360deg);
  }
}

// Counter-rotation keeps element upright
```

**Elliptical Orbit:**
```javascript
gsap.to(element, {
  motionPath: {
    path: "M0,0 a100,60 0 1,1 0,0.1", // 100px wide, 60px tall ellipse
    autoRotate: false
  },
  duration: 4,
  repeat: -1,
  ease: "none"
});
```

## Spiral Path

Orbit with decreasing/increasing radius.

**Spiral Inward:**
```javascript
gsap.to(element, {
  motionPath: {
    path: generateSpiralPath(100, 0, 5), // start 100px, end 0, 5 rotations
  },
  duration: 3
});

function generateSpiralPath(startRadius, endRadius, turns) {
  const points = [];
  const steps = turns * 36; // 36 points per turn

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const radius = startRadius + (endRadius - startRadius) * t;
    const angle = t * turns * Math.PI * 2;
    points.push({
      x: Math.cos(angle) * radius,
      y: Math.sin(angle) * radius
    });
  }

  return points;
}
```

## Figure-Eight Path

Infinity symbol motion pattern.

```javascript
gsap.to(element, {
  motionPath: {
    path: "M0,0 C50,-50 50,-50 100,0 C150,50 150,50 100,100 C50,150 50,150 0,100 C-50,50 -50,50 0,0",
  },
  duration: 4,
  repeat: -1,
  ease: "none"
});
```

## Random Walk / Brownian Motion

Pseudo-random movement for organic feel.

```javascript
function randomWalk(element, amplitude = 20, duration = 2) {
  function moveToRandom() {
    gsap.to(element, {
      x: `+=${(Math.random() - 0.5) * amplitude}`,
      y: `+=${(Math.random() - 0.5) * amplitude}`,
      duration: duration,
      ease: "sine.inOut",
      onComplete: moveToRandom
    });
  }
  moveToRandom();
}
```

## Sine Wave Path

Horizontal movement with vertical sine wave oscillation.

```javascript
gsap.to(element, {
  x: 200,
  duration: 2,
  ease: "none",
  modifiers: {
    y: (y) => Math.sin(gsap.getProperty(element, "x") * 0.05) * 30
  }
});
```

## Zig-Zag Path

Sharp angular path motion.

```javascript
gsap.to(element, {
  motionPath: {
    path: [
      { x: 0, y: 0 },
      { x: 50, y: 50 },
      { x: 100, y: 0 },
      { x: 150, y: 50 },
      { x: 200, y: 0 }
    ],
    curviness: 0 // sharp corners
  },
  duration: 1
});
```

## M3 Container Transform Path

Material Design 3's shared element transition uses arc motion:

1. Element scales and moves simultaneously
2. Horizontal and vertical axes may use different timing
3. Path naturally arcs due to combined transforms

```tsx
// Framer Motion shared layout
<motion.div
  layoutId="shared-element"
  transition={{
    type: "spring",
    stiffness: 300,
    damping: 30
  }}
/>
```

## Performance Considerations

1. **Use `transform`** — Hardware accelerated
2. **Avoid `top/left`** — Triggers layout
3. **Use `will-change: transform`** — Hint for optimization
4. **Limit concurrent paths** — Each path animation uses resources
5. **Consider reduced motion** — Disable complex paths for accessibility
