# Template Variables Reference

Complete reference for template interpolation variables used in code generation.

## Template Syntax

The template engine uses a Mustache-like syntax to generate platform-specific code from animation specifications.

### Variable Substitution

```
{{VARIABLE_NAME}}
```

### Conditional Blocks

```
{{#if CONDITION}}
// Code when true
{{/if}}

{{#if CONDITION}}
// Code when true
{{else}}
// Code when false
{{/if}}
```

## Naming Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{ANIMATION_NAME}}` | Kebab-case animation name | `modal-entrance` |
| `{{FUNCTION_NAME}}` | camelCase function name | `modalEntrance` |
| `{{COMPONENT_NAME}}` | PascalCase component name | `ModalEntrance` |
| `{{FILE_NAME}}` | File name (kebab-case) | `modal-entrance` |
| `{{CLASS_NAME}}` | CSS class name | `modal-entrance` |

## Duration Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{DURATION}}` | Numeric duration (ms) | `250` |
| `{{DURATION_S}}` | Duration in seconds | `0.25` |
| `{{DURATION_MS}}` | Duration in milliseconds | `250` |
| `{{DURATION_TOKEN}}` | Token reference | `medium-1` |
| `{{DURATION_FRAMES}}` | Duration in frames | `8` |
| `{{FPS}}` | Frames per second | `30` |
| `{{DELAY}}` | Animation delay (ms) | `100` |
| `{{REDUCED_DURATION}}` | Reduced motion duration | `100` |

## Easing Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{EASING_CSS}}` | CSS cubic-bezier | `cubic-bezier(0.05, 0.7, 0.1, 1)` |
| `{{EASING_ARRAY}}` | Array format | `[0.05, 0.7, 0.1, 1]` |
| `{{EASING_TOKEN}}` | Token name | `emphasized-decelerate` |
| `{{EASING_TYPE}}` | Type: `bezier` or `spring` | `bezier` |
| `{{SPRING_CONFIG}}` | Spring config name | `bouncy` |

## Transform Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{FROM_OPACITY}}` | Initial opacity | `0` |
| `{{TO_OPACITY}}` | Final opacity | `1` |
| `{{FROM_SCALE}}` | Initial scale | `0.95` |
| `{{TO_SCALE}}` | Final scale | `1` |
| `{{FROM_Y}}` | Initial translateY (px) | `16` |
| `{{TO_Y}}` | Final translateY (px) | `0` |
| `{{FROM_X}}` | Initial translateX (px) | `0` |
| `{{TO_X}}` | Final translateX (px) | `0` |
| `{{FROM_TRANSFORM}}` | Full transform string | `translateY(16px) scale(0.95)` |
| `{{TO_TRANSFORM}}` | Full transform string | `translateY(0) scale(1)` |
| `{{FROM_FILTER}}` | Initial filter | `blur(4px)` |
| `{{TO_FILTER}}` | Final filter | `blur(0)` |
| `{{EXIT_SCALE}}` | Exit animation scale | `0.95` |

## CSS-Specific Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{WILL_CHANGE}}` | Performance hint properties | `transform, opacity` |
| `{{FILL_MODE}}` | Animation fill mode | `forwards` |
| `{{ITERATION_COUNT}}` | Loop count | `infinite` |
| `{{KEYFRAME_50}}` | 50% keyframe styles | `transform: scale(1.1);` |
| `{{KEYFRAME_70}}` | 70% keyframe styles | `transform: scale(0.98);` |
| `{{TRANSITION_PROPERTIES}}` | Transition shorthand | `transform 250ms cubic-bezier(...)` |
| `{{STATE_SELECTOR}}` | State class suffix | `--active` |
| `{{BASE_STYLES}}` | Initial CSS properties | `opacity: 1;` |
| `{{TARGET_STYLES}}` | Target state CSS | `transform: translateY(-4px);` |
| `{{HOVER_STYLES}}` | Hover state CSS | `box-shadow: 0 4px 8px rgba(...)` |
| `{{FOCUS_STYLES}}` | Focus state CSS | `outline: 2px solid blue;` |
| `{{ACTIVE_STYLES}}` | Active/press state CSS | `transform: scale(0.95);` |

## Reduced Motion Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{REDUCED_MOTION_STYLES}}` | Fallback CSS | `opacity: 1; transform: none;` |
| `{{REDUCED_TARGET_STYLES}}` | Reduced motion target | `opacity: 0.9;` |

## Metadata Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{STAGGER_MS}}` | Stagger delay in ms | `50` |
| `{{PRINCIPLES}}` | Applied Disney principles | `anticipation, follow-through` |
| `{{PRINCIPLE_REFS}}` | Token file references | `tokens/anticipation.tokens.json` |
| `{{RECIPE_REF}}` | Recipe reference | `modal-entrance` |
| `{{ANIMATION_DESCRIPTION}}` | Human-readable description | `Modal entrance animation` |
| `{{PROPERTIES}}` | Animated properties list | `transform, opacity, box-shadow` |

## Available Conditionals

| Conditional | True When |
|-------------|-----------|
| `HAS_STAGGER` | Animation includes staggered items |
| `HAS_EXIT` | Exit animation is defined |
| `HAS_TRANSFORM_Y` | translateY animation |
| `HAS_TRANSFORM_X` | translateX animation |
| `HAS_SCALE` | Scale animation |
| `HAS_ROTATION` | Rotation animation |
| `HAS_FILTER` | Filter animation (blur, brightness, etc.) |
| `USE_SPRING` | Using spring physics instead of bezier |
| `USE_INTERPOLATE` | Using interpolate (Remotion) |
| `HAS_CUSTOM_PROPS` | Custom props defined |
| `HOVER_STATE` | Hover state is defined |
| `FOCUS_STATE` | Focus state is defined |
| `ACTIVE_STATE` | Active/press state is defined |
| `KEYFRAME_50` | 50% keyframe is needed |
| `KEYFRAME_70` | 70% keyframe is needed |
| `FROM_OPACITY` | Opacity animation from value exists |
| `FROM_TRANSFORM` | Transform animation from value exists |
| `FROM_FILTER` | Filter animation from value exists |
| `DELAY` | Animation has a delay |
| `ITERATION_COUNT` | Animation loops |
| `PRINCIPLE_REFS` | Disney principle references exist |

## Variable Generation Rules

### `{{WILL_CHANGE}}` Generation

Based on animated properties, generate comma-separated list:
```
opacity animation -> "opacity"
transform animation -> "transform"
filter animation -> "filter"
multiple -> "transform, opacity"
```

### `{{REDUCED_MOTION_STYLES}}` Generation

Based on animation type:

| Animation Type | Reduced Motion Fallback |
|----------------|------------------------|
| Entrance (fade + transform) | `opacity: 1; transform: none;` |
| Exit (fade out) | `opacity: 0;` |
| State change (hover, press) | `opacity: 0.9;` or instant state |
| Loading (shimmer, pulse) | `animation: none;` (static) |
| Error (shake) | `border-color: var(--error);` (no motion) |
| Celebration (particles) | `opacity: 1;` (skip particles) |

### `{{PRINCIPLE_REFS}}` Generation

List token files for applied principles:
```
anticipation -> "tokens/anticipation.tokens.json"
squash-stretch -> "tokens/squash-stretch.tokens.json"
follow-through -> "tokens/follow-through.tokens.json"
```

## Template Examples

### Simple Variable Substitution

```
animation-name: {{ANIMATION_NAME}};
duration: {{DURATION}}ms;
```

### Conditional Blocks

```
{{#if HAS_SCALE}}
const scale = interpolate(frame, [0, duration], [{{FROM_SCALE}}, {{TO_SCALE}}]);
{{/if}}
```

### If-Else Blocks

```
{{#if USE_SPRING}}
transition: { type: 'spring', ...springConfigs['{{SPRING_CONFIG}}'] }
{{else}}
transition: { duration: {{DURATION_S}}, ease: {{EASING_ARRAY}} }
{{/if}}
```

## Adding New Templates

1. Create template file in `/v2/templates/`
2. Use `.template.txt` extension
3. Include all required variables
4. Add conditionals for optional features
5. Include usage examples as comments
