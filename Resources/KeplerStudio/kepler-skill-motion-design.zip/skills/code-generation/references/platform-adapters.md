# Platform Adapter Reference

Detailed implementation patterns for each supported platform.

## Token Resolution

### Duration Tokens

```typescript
const durationTokens = {
  'short-1': { ms: 50, s: 0.05, frames30: 2 },
  'short-2': { ms: 100, s: 0.1, frames30: 3 },
  'short-3': { ms: 150, s: 0.15, frames30: 5 },
  'short-4': { ms: 200, s: 0.2, frames30: 6 },
  'medium-1': { ms: 250, s: 0.25, frames30: 8 },
  'medium-2': { ms: 300, s: 0.3, frames30: 9 },
  'medium-3': { ms: 350, s: 0.35, frames30: 11 },
  'medium-4': { ms: 400, s: 0.4, frames30: 12 },
  'long-1': { ms: 450, s: 0.45, frames30: 14 },
  'long-2': { ms: 500, s: 0.5, frames30: 15 },
};
```

### Easing Tokens

```typescript
const easingTokens = {
  standard: {
    bezier: [0.2, 0, 0, 1],
    css: 'cubic-bezier(0.2, 0, 0, 1)',
    gsap: 'power2.out',
    remotion: 'Easing.bezier(0.2, 0, 0, 1)',
  },
  'emphasized-decelerate': {
    bezier: [0.05, 0.7, 0.1, 1],
    css: 'cubic-bezier(0.05, 0.7, 0.1, 1)',
    gsap: 'power3.out',
    remotion: 'Easing.bezier(0.05, 0.7, 0.1, 1)',
  },
  'emphasized-accelerate': {
    bezier: [0.3, 0, 0.8, 0.15],
    css: 'cubic-bezier(0.3, 0, 0.8, 0.15)',
    gsap: 'power2.in',
    remotion: 'Easing.bezier(0.3, 0, 0.8, 0.15)',
  },
  'standard-decelerate': {
    bezier: [0, 0, 0, 1],
    css: 'cubic-bezier(0, 0, 0, 1)',
    gsap: 'power2.out',
    remotion: 'Easing.bezier(0, 0, 0, 1)',
  },
  linear: {
    bezier: [0, 0, 1, 1],
    css: 'linear',
    gsap: 'none',
    remotion: 'Easing.linear',
  },
};
```

### Spring Tokens

```typescript
const springTokens = {
  standard: { damping: 15, stiffness: 150, mass: 1 },
  snappy: { damping: 25, stiffness: 300, mass: 0.5 },
  bouncy: { damping: 10, stiffness: 180, mass: 1 },
  gentle: { damping: 25, stiffness: 100, mass: 1.2 },
  celebratory: { damping: 8, stiffness: 180, mass: 1 },
  calming: { damping: 30, stiffness: 80, mass: 1.5 },
  urgent: { damping: 30, stiffness: 400, mass: 0.5 },
  energetic: { damping: 12, stiffness: 250, mass: 0.8 },
  mysterious: { damping: 35, stiffness: 60, mass: 2 },
};
```

## Spring to GSAP Mapping

```javascript
// Convert spring tokens to GSAP elastic ease
function springToGsap(spring) {
  // Approximate spring with elastic ease
  // Lower damping = more oscillation
  const amplitude = Math.max(0.1, 1 - (spring.damping / 50));
  const period = 1 / (spring.stiffness / 100);

  return `elastic.out(${amplitude.toFixed(2)}, ${period.toFixed(2)})`;
}

// Examples:
// bouncy (damping: 10) -> elastic.out(0.8, 0.56)
// snappy (damping: 25) -> elastic.out(0.5, 0.33)
// gentle (damping: 25) -> power2.out (no bounce)
```

## Motion Blur for Remotion

```typescript
import { interpolate, useCurrentFrame } from 'remotion';

// Vector blur based on velocity
function useMotionBlur(velocity: number, intensity: 'subtle' | 'standard' | 'dramatic') {
  const blurMap = {
    subtle: { samples: 3, spread: 2 },
    standard: { samples: 5, spread: 4 },
    dramatic: { samples: 8, spread: 8 },
  };

  const config = blurMap[intensity];

  // Render multiple offset copies for motion blur effect
  return Array.from({ length: config.samples }, (_, i) => {
    const offset = ((i - config.samples / 2) / config.samples) * config.spread;
    const opacity = 1 / config.samples;
    return { offset, opacity };
  });
}
```

## 3D Transform Examples

### CSS 3D

```css
.card-flip {
  perspective: 1000px;
  transform-style: preserve-3d;
}
.card-flip:hover .card-inner {
  transform: rotateY(180deg);
  transition: transform 600ms cubic-bezier(0.2, 0, 0, 1);
}
```

### Framer Motion 3D

```typescript
<motion.div
  style={{ perspective: 1000 }}
  animate={{ rotateY: isFlipped ? 180 : 0 }}
  transition={{ duration: 0.6, ease: [0.2, 0, 0, 1] }}
/>
```

## Platform-Specific Generation

### CSS Output

**Keyframe Animation:**

```css
/* Input specification:
   duration: 'medium-1'
   easing: 'emphasized-decelerate'
   from: { opacity: 0, y: 20 }
   to: { opacity: 1, y: 0 }
*/

@keyframes slide-up-fade-in {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

.animated-element {
  animation: slide-up-fade-in 250ms cubic-bezier(0.05, 0.7, 0.1, 1) forwards;
  will-change: transform, opacity;
}

@media (prefers-reduced-motion: reduce) {
  .animated-element {
    animation: none;
    opacity: 1;
    transform: none;
  }
}
```

### GSAP Output

```javascript
import { gsap } from 'gsap';

const prefersReducedMotion =
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function slideUpFadeIn(targets, options = {}) {
  const { delay = 0, stagger = 0.05, onComplete } = options;

  if (prefersReducedMotion) {
    return gsap.to(targets, {
      opacity: 1,
      duration: 0.1,
      delay,
      onComplete,
    });
  }

  return gsap.from(targets, {
    opacity: 0,
    y: 20,
    duration: 0.25,
    ease: 'power3.out',
    stagger,
    delay,
    onComplete,
  });
}
```

### Framer Motion Output

```typescript
import type { Variants } from 'framer-motion';
import { useReducedMotion } from 'framer-motion';

export const modalVariants: Variants = {
  hidden: {
    opacity: 0,
    scale: 0.95,
    y: 16,
  },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      duration: 0.25,
      ease: [0.05, 0.7, 0.1, 1],
    },
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: {
      duration: 0.2,
      ease: [0.3, 0, 0.8, 0.15],
    },
  },
};

export const modalReducedVariants: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.1 } },
  exit: { opacity: 0, transition: { duration: 0.1 } },
};

export function useModalVariants() {
  const prefersReducedMotion = useReducedMotion();
  return prefersReducedMotion ? modalReducedVariants : modalVariants;
}
```

### Remotion Output

```typescript
import React from 'react';
import { useCurrentFrame, useVideoConfig, interpolate, Easing } from 'remotion';

interface SlideUpFadeInProps {
  children: React.ReactNode;
  delay?: number;
}

export const SlideUpFadeIn: React.FC<SlideUpFadeInProps> = ({
  children,
  delay = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const localFrame = Math.max(0, frame - delay);
  const duration = 8; // 250ms at 30fps

  const opacity = interpolate(
    localFrame,
    [0, duration],
    [0, 1],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateRight: 'clamp',
    }
  );

  const translateY = interpolate(
    localFrame,
    [0, duration],
    [20, 0],
    {
      easing: Easing.bezier(0.05, 0.7, 0.1, 1),
      extrapolateRight: 'clamp',
    }
  );

  return (
    <div style={{
      opacity,
      transform: `translateY(${translateY}px)`,
      willChange: 'transform, opacity',
    }}>
      {children}
    </div>
  );
};
```

## Reduced Motion Generation

### Automatic Generation

```typescript
function generateReducedMotion(animation: AnimationSpec): ReducedMotionSpec {
  return {
    // Keep opacity, remove transforms
    properties: animation.properties.includes('opacity')
      ? ['opacity']
      : ['opacity'], // Always use opacity

    duration: Math.min(animation.duration, 100),

    easing: 'ease', // Simple easing

    // Instant state changes for complex animations
    instant: animation.complexity > 'simple',
  };
}
```

### Output Examples

**CSS:**
```css
@media (prefers-reduced-motion: reduce) {
  .animation {
    animation: none;
    transition: opacity 100ms ease;
  }
}
```

**GSAP:**
```javascript
if (prefersReducedMotion) {
  return gsap.to(target, { opacity: 1, duration: 0.1 });
}
```

**Framer Motion:**
```typescript
const reducedVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.1 } },
};
```

**Remotion:**
```typescript
// Remotion videos typically aren't interactive, but can include
// reduced complexity versions for accessibility contexts
const opacity = interpolate(frame, [0, 3], [0, 1], { extrapolateRight: 'clamp' });
// Skip transform animations
return <div style={{ opacity }}>{children}</div>;
```

## Generation Workflow

```typescript
function generateCode(spec: AnimationSpec): string {
  // 1. Resolve tokens
  const resolvedDuration = durationTokens[spec.duration];
  const resolvedEasing = easingTokens[spec.easing];

  // 2. Select template
  const template = templates[spec.platform];

  // 3. Build variables
  const variables = {
    ANIMATION_NAME: toKebabCase(spec.name),
    FUNCTION_NAME: toCamelCase(spec.name),
    COMPONENT_NAME: toPascalCase(spec.name),
    DURATION: resolvedDuration[platform.unit],
    DURATION_TOKEN: spec.duration,
    EASING_CSS: resolvedEasing.css,
    // ... more variables
  };

  // 4. Interpolate template
  const code = interpolateTemplate(template, variables);

  // 5. Add reduced motion
  const reducedCode = generateReducedMotion(spec, spec.platform);

  return code + '\n\n' + reducedCode;
}
```
