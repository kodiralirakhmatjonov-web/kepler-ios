# Motion Design Agent Skill System

A comprehensive agent skill system for motion design, grounded in industry standards.

## What This Is

A skill library that enables AI agents to create animations and motion graphics using de facto industry standards. Instead of guessing animation values, agents reference standardized tokens and documented patterns.

**v3.0.0** — 73 skills, 59 token files, Narrative Intentionality Layer

### What's New in v3.0.0

**Narrative Layer** transforms motion from decoration to storytelling:

```
Before: Motion = Emotional + Technical + Visual
After:  Motion = Emotional + Technical + Visual + Narrative + Intentional
```

| New Concept | What It Does |
|-------------|--------------|
| **Narrative Arc** | Freytag's pyramid for UI (exposition → climax → resolution) |
| **Intent** | WHY something moves (clarify, guide, confirm, warn, celebrate, reveal) |
| **Emotional Journey** | User state machine (curious → engaged → accomplished → delighted) |
| **Consequence** | Cause-effect chains (direct, ripple, cascade, echo) |
| **Dramaturgy** | Scene/act composition, pacing profiles, rhythm patterns |
| **Attention Path** | Reading order choreography (F-pattern, Z-pattern, center-out) |
| **Microstate** | Deep component state machines (idle → hover → active → success) |

## Standards Implemented

| Standard | Version | Role |
|----------|---------|------|
| **W3C Design Tokens** | 2025.10 (Stable) | Token format specification |
| **Material Design 3** | Current | Primary motion values baseline |
| **Lottie Specification** | v1.0 (LAC) | Animation interchange format |
| **WCAG 2.1** | 2.3.3 | Accessibility compliance |
| **agentskills.io** | Current | Skill file format |

Cross-references: Fluent 2 (Microsoft), Carbon (IBM), Apple HIG

## Quick Start

### For Agents

1. Read `SKILL.md` (root orchestrator)
2. Load tokens from `tokens/motion.tokens.json`
3. Reference sub-skills as needed

### Reading Order

| Priority | Skill | Why |
|----------|-------|-----|
| 1 | `SKILL.md` | Understand the system, decision frameworks |
| 2 | `skills/easing/` | Most common question: "which easing?" |
| 3 | `skills/duration/` | Second most common: "how long?" |
| 4 | `skills/accessibility/` | Required for all implementations |
| 5 | `skills/tools/` | Choose the right tool for the job |

### For Humans

```bash
# View all tokens
cat tokens/motion.tokens.json | jq .

# Check a specific easing value
cat tokens/easing.tokens.json | jq '.motion.easing["emphasized-decelerate"]'

# List all skills
ls skills/
```

## Skill Categories

### Core (4 skills)
- `motion-design` — Root orchestrator
- `orchestrator` — Autonomous animation generation
- `choice-resolution` — Unified parameter resolution pipeline

### Foundation (9 skills)
- `motion-principles` — Motion philosophy from design systems
- `easing` — Easing curve selection and implementation
- `duration` — Duration and timing selection
- Disney principles: `anticipation`, `squash-stretch`, `follow-through`, `secondary-action`, `exaggeration`, `arc-motion`

### Transforms (4 skills)
- `position` — Translation and movement
- `scale` — Scale transforms and squash-stretch
- `rotation` — 2D/3D rotation
- `skew` — Slant and italic transforms

### Visibility (3 skills)
- `opacity` — Fade and flash effects
- `reveals` — Mask reveals and wipes
- `blur` — Motion blur and focus

### Orchestration (3 skills)
- `sequencing` — Stagger and cascade patterns
- `looping` — Loop and oscillation
- `procedural` — Noise and generative motion

### Patterns (5 skills)
- `transitions` — Page transitions
- `container-transform` — Google M3 signature shared element transition
- `entrance-patterns` — Element entrances
- `exit-patterns` — Element exits
- `scroll-animations` — Scroll-triggered

### Effects (5 skills)
- `particles` — Confetti, snow, sparks
- `distortion` — Glitch, wave, ripple
- `glow-shadow` — Neon, shadows, elevation
- `reflection` — Floor, water, glass, mirror
- `texture` — Grain, noise, patterns

### Specialized (7 skills)
- `typography` — Kinetic typography
- `ui-micro` — Micro-interactions
- `scrollytelling` — Scroll narratives
- `attention` — Pulses, badges, spotlights
- `stylization` — Vintage, minimalist, brutalist, organic
- `audio-reactive` — Beat sync, frequency visualization
- `character` — Walk cycles, expressions, lip sync

### Space & Camera (2 skills)
- `camera` — Pan, tilt, dolly, zoom, parallax
- `depth` — Z-axis, perspective, layers

### Shape & Path (3 skills)
- `morphing` — Shape morphing
- `stroke` — Draw-on, dash patterns
- `masks` — Animated masks

### Production (2 skills)
- `compositing` — Blend modes, layers
- `cinematic` — Letterbox, fades, Ken Burns

### Color & Physics (2 skills)
- `color` — Hue, saturation, brightness, contrast
- `physics` — Gravity, friction, bounce, springs

### Control (1 skill)
- `playback-control` — Speed, direction, scrubbing

### Implementation (5 skills)
- `lottie` — Lottie/dotLottie export
- `remotion` — Video rendering
- `tools` — Tool selection guide
- `code-generation` — Code generation patterns
- `export` — Format, resolution, quality

### Components (4 skills)
- `component-animations` — UI component patterns
- `loading-states` — Loaders, skeletons
- `gesture-motion` — Touch and gesture
- `animation-recipes` — Pre-built recipes

### Advanced (3 skills)
- `3d-transforms` — 3D transformations
- `motion-blur` — Motion blur effects
- `frame-timing` — Frame-by-frame timing

### Quality (4 skills)
- `accessibility` — WCAG compliance
- `motion-audit` — Animation auditing
- `testing-patterns` — Testing strategies
- `platform-adaptation` — Cross-platform

### Emotion (2 skills)
- `emotion-mapping` — Emotion-to-animation mapping
- `emotion-selection` — Token selection guide

### Narrative (7 skills) — NEW in v3.0.0
- `narrative-arc` — Story structure (Freytag's pyramid for UI)
- `intent` — Semantic motion purpose (clarify, guide, confirm, warn, celebrate, reveal)
- `emotional-journey` — User emotional state machine
- `consequence` — Cause-effect animation chains
- `dramaturgy` — Scene/act composition, pacing profiles
- `attention-choreography` — Reading order and gaze paths
- `microstate` — Component state machine orchestration

## Token Files (59 total)

### Core Tokens
- `motion.tokens.json` — Complete token set
- `easing.tokens.json` — Easing curves
- `duration.tokens.json` — Duration scale
- `spring.tokens.json` — Spring physics

### Transform Tokens
- `position.tokens.json`, `scale.tokens.json`, `rotation.tokens.json`
- `skew.tokens.json`, `transform-origin.tokens.json`

### Visibility Tokens
- `opacity.tokens.json`, `reveal.tokens.json`, `blur.tokens.json`

### Orchestration Tokens
- `sequencing.tokens.json`, `looping.tokens.json`, `procedural.tokens.json`

### Disney Principle Tokens
- `anticipation.tokens.json`, `squash-stretch.tokens.json`
- `follow-through.tokens.json`, `exaggeration.tokens.json`

### Effect Tokens
- `particles.tokens.json`, `distortion.tokens.json`, `glow-shadow.tokens.json`
- `reflection.tokens.json`, `texture.tokens.json`
- `motion-blur.tokens.json`, `motion-path.tokens.json`, `depth.tokens.json`

### Specialized Tokens
- `camera.tokens.json`, `morphing.tokens.json`, `stroke.tokens.json`, `masks.tokens.json`
- `typography.tokens.json`, `stylization.tokens.json`
- `audio.tokens.json`, `character.tokens.json`
- `compositing.tokens.json`, `cinematic.tokens.json`
- `color.tokens.json`, `physics.tokens.json`, `playback.tokens.json`

### Semantic Tokens
- `emotion.tokens.json`, `components.tokens.json`, `recipes.tokens.json`
- `export.tokens.json`, `choice-resolution.tokens.json`

### M3 Premium Tokens (v2.3.0)
- `state-layer.tokens.json` — Interaction opacity (hover 8%, focus 12%, press 12%, drag 16%)
- `gesture.tokens.json` — Touch thresholds (long-press, double-tap, swipe velocity)
- `focus-indicator.tokens.json` — Accessibility focus ring (3px width, glow, pulse)
- `motion-levels.tokens.json` — Platform adaptation (L1-none through L4-enhanced)
- `cross-fade.tokens.json` — Container transform nested timing
- `entrance-intensity.tokens.json` — M3 hierarchy entrances (emphasized/standard/subtle)
- `scrim.tokens.json` — Depth cue opacity (light 12%, standard 32%, heavy 52%)

### Narrative Tokens (v3.0.0)
- `narrative-arc.tokens.json` — Arc phases, presets (micro/short/medium), beat types, tension curves
- `intent.tokens.json` — Primary intents with speed, intensity, patterns, emotion affinity
- `emotional-journey.tokens.json` — Journey states, transitions, archetypes (onboarding, checkout, recovery)
- `consequence.tokens.json` — Chain types (direct, ripple, cascade, echo, branch, convergent)
- `dramaturgy.tokens.json` — Scene types, pacing profiles (measured, staccato, legato), rhythm patterns
- `attention-path.tokens.json` — Reading patterns (F, Z, center-out, Gutenberg), focus anchors
- `microstate.tokens.json` — Component states, transitions, component machines (button, input, toggle)

## Directory Structure

```
motion-design-agent/
├── SKILL.md                 # Root orchestrator
├── CLAUDE.md                # Agent instructions
├── manifest.json            # Skill/token discovery
├── README.md                # This file
│
├── tokens/                  # W3C DTCG format (59 files)
│   ├── motion.tokens.json   # Complete token set
│   ├── easing.tokens.json   # Easing curves
│   ├── duration.tokens.json # Duration scale
│   ├── narrative-arc.tokens.json  # NEW: Story structure
│   ├── intent.tokens.json         # NEW: Motion purpose
│   └── ...                  # 54 more token files
│
├── skills/                  # Sub-skills (73 directories)
│   ├── easing/
│   ├── duration/
│   ├── color/
│   ├── physics/
│   └── ...                  # 69 more skills
│
├── presets/                 # Implementation-ready code
│   ├── remotion-m3.ts
│   ├── gsap-presets.js
│   └── framer-motion-presets.ts
│
├── templates/               # Starter templates
│   ├── lottie/              # 4 templates
│   ├── remotion/            # 5 templates
│   └── css/                 # 3 templates
│
└── references/              # Cross-cutting documentation
    ├── industry-standards.md
    ├── design-system-comparison.md
    ├── skill-relationships.md
    └── tool-selection.md
```

## Key Tokens

### Easing (M3 Baseline)

| Token | Value | Use |
|-------|-------|-----|
| `emphasized-decelerate` | (0.05, 0.7, 0.1, 1) | Entering screen |
| `emphasized-accelerate` | (0.3, 0, 0.8, 0.15) | Exiting screen |
| `standard` | (0.2, 0, 0, 1) | General movement |
| `linear` | (0, 0, 1, 1) | Continuous/looping |

### Duration (M3 Baseline)

| Token | Value | Use |
|-------|-------|-----|
| `short-1` to `short-4` | 50-200ms | Micro to small |
| `medium-1` to `medium-4` | 250-400ms | Components |
| `long-1` to `long-2` | 450-500ms | Page transitions |

## Example Prompts

### Basic
- "What easing should I use for a modal opening?"
- "How long should a button hover animation be?"
- "Give me the M3 duration for a page transition"

### Implementation
- "Animate a card grid entrance with stagger using Framer Motion"
- "Create a scroll-triggered reveal with GSAP and M3 tokens"
- "Build a Remotion title card with proper entrance animation"

### New in v2.3
- "Implement a container transform transition like Google apps"
- "What are the M3 state layer opacity values for hover and press?"
- "Build an entrance with M3 emphasized intensity"
- "Adapt motion for reduced-motion users using motion levels"
- "Add a proper focus indicator with accessibility tokens"

### New in v2.4 (Choice Resolution)
- "Resolve animation parameters for a playful button on video platform"
- "What's the final duration when recipe says 300ms but emotion is celebratory?"
- "How do brand constraints cap exaggeration?"

### New in v3.0.0 (Narrative)
- "Animate this button with confirm intent" → scale-pulse, checkmark pattern
- "Design a modal using short narrative arc" → exposition → rising → climax → resolution
- "What emotional journey for checkout?" → engaged → focused → anticipating → accomplished
- "Create cascading consequence from form submit" → button → loading → fields disable → success
- "Sequence this dashboard with F-pattern attention" → top-left first, attention decay downward
- "Build button with full microstate machine" → idle/hover/active/loading/success/error states

### New in v2.x
- "Create a physics-based bouncing ball animation"
- "Add vintage film grain effect to this video"
- "Animate hue shift on hover with color tokens"
- "Build an audio-reactive visualizer"
- "Create a character walk cycle"

## Accessibility

Every pattern includes reduced motion alternatives. The system enforces:

- `prefers-reduced-motion` detection
- Safe alternatives (fade instead of slide)
- WCAG 2.3.3 compliance

## Version

**v3.0.0** — Narrative Intentionality Layer

### Changelog

#### v3.0.0
- **MAJOR**: Added narrative layer for motion as storytelling
- **7 new token files**: narrative-arc, intent, emotional-journey, consequence, dramaturgy, attention-path, microstate
- **7 new skills**: narrative-arc, intent, emotional-journey, consequence, dramaturgy, attention-choreography, microstate
- Updated orchestrator with narrative pipeline (intent → journey → arc → scene → attention → consequence → microstate)
- Total: 73 skills, 59 token files

#### v2.4.0
- **New skill**: `choice-resolution` — Unified parameter resolution pipeline
- **New token file**: `choice-resolution.tokens.json` — Resolution rules, platform multipliers, brand constraints
- Updated `orchestrator` with Parameter Resolver phase
- Updated `emotion.tokens.json` with `$role: "modifier-layer"` and merge behavior
- Updated `recipes.tokens.json` with `$role: "base-layer"` and platform overrides
- Fixed unbounded duration stacking (emotions now blend before applying)
- Total: 66 skills, 52 token files

#### v2.3.0
- **7 new M3 premium token files**: state-layer, gesture, focus-indicator, motion-levels, cross-fade, entrance-intensity, scrim
- **New skill**: container-transform (Google M3 signature shared element transition)
- Updated sequencing tokens with 20ms stagger cap and choreography section
- Added arc-threshold to position tokens (10% aspect ratio trigger)
- Dynamic duration calculator and property-specific easing guidance
- Transition decision tree for pattern selection
- Updated presets with new token imports

#### v2.2.0
- Container transform skill with timing breakdown
- Arc motion tokens, scrim tokens, dynamic duration formulas
- Enter/exit asymmetry (70% rule)

#### v2.1.0
- Added 11 new skills: color, physics, stylization, playback-control, reflection, skew, depth, texture, audio-reactive, character, export
- Added 11 new token files for all new skills
- New categories: color, physics, control
- Total: 64 skills, 44 token files

#### v2.0.0
- Major expansion: 21 new skills added
- 19 new token files (transforms, visibility, orchestration, effects, shape-path, specialized, production)
- Added orchestrator skill for autonomous generation
- Categories: transforms, visibility, orchestration, effects, space-camera, shape-path, specialized, production
- Total: 53 skills, 33 token files

#### v1.2.0
- Added manifest.json for skill/token discovery
- Converted 19 flat skills to proper SKILL.md format
- Added templates for Remotion, CSS, Lottie
- Total: 30 skills, 14 token files

#### v1.1.0
- Emotion springs, template variables, platform adapters
- Standardized reduced motion fallback taxonomy

#### v1.0.0
- Initial release with 14 skills and 8 token files
- Disney's 12 Principles implementation

## License

See individual skill files for licensing information.
