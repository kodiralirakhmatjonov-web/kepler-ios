# Motion Design Agent System
## Industry-Standardized Specification

> A comprehensive agent skill system for motion design, grounded in de facto industry standards: W3C Design Tokens, Material Design 3, Lottie Specification, and cross-referenced against Fluent, Carbon, and Apple HIG.

---

## Standards Foundation

This specification is built on the following industry standards:

| Standard | Authority | Version | Role in This System |
|----------|-----------|---------|---------------------|
| **W3C Design Tokens** | W3C DTCG | 2025.10 (Stable) | Token format specification |
| **Material Design 3** | Google | Current | Primary motion values baseline |
| **Lottie Specification** | Linux Foundation LAC | v1.0 | Animation interchange format |
| **dotLottie** | LottieFiles | v2.0 | Packaged animation format |
| **Fluent 2** | Microsoft | Current | Cross-reference |
| **Carbon** | IBM | Current | Cross-reference |
| **Apple HIG** | Apple | Current | Cross-reference |
| **agentskills.io** | Anthropic/Community | Current | Skill file format |

---

## Directory Structure

```
motion-design/
├── SKILL.md                              # Root orchestrator
│
├── references/
│   ├── industry-standards.md             # Standards overview
│   ├── design-system-comparison.md       # M3 vs Fluent vs Carbon vs Apple
│   └── tool-selection.md                 # When to use what
│
├── tokens/                               # W3C DTCG format tokens
│   ├── motion.tokens.json                # Complete motion token set
│   ├── easing.tokens.json                # Easing curves only
│   ├── duration.tokens.json              # Duration scale only
│   └── spring.tokens.json                # Spring physics configs
│
├── skills/                               # Sub-skills (agentskills.io compliant)
│   │
│   ├── motion-principles/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── design-system-principles.md
│   │       └── 12-principles-animation.md
│   │
│   ├── easing/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── curve-comparison.md
│   │       └── easing-selection.md
│   │
│   ├── duration/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── duration-by-context.md
│   │       └── frame-conversion.md
│   │
│   ├── transitions/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── container-transform.md
│   │       ├── shared-axis.md
│   │       └── fade-through.md
│   │
│   ├── entrance-patterns/
│   │   ├── SKILL.md
│   │   └── references/
│   │       └── stagger-patterns.md
│   │
│   ├── exit-patterns/
│   │   └── SKILL.md
│   │
│   ├── accessibility/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── wcag-requirements.md
│   │       └── reduced-motion-alternatives.md
│   │
│   ├── lottie/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── lottie-spec.md
│   │       ├── dotlottie-spec.md
│   │       └── supported-features.md
│   │
│   ├── remotion/
│   │   ├── SKILL.md
│   │   ├── scripts/
│   │   │   └── init-project.sh
│   │   └── references/
│   │       ├── interpolate-recipes.md
│   │       └── spring-configs.md
│   │
│   └── tools/
│       ├── SKILL.md
│       └── references/
│           ├── gsap.md
│           ├── framer-motion.md
│           └── rive.md
│
└── assets/
    └── lottie/                           # Pre-made Lottie animations
        └── .gitkeep
```

---

## Root Skill: `SKILL.md`

```markdown
---
name: motion-design
description: Create animations and motion graphics using industry standards. Use when asked to animate UI elements, create video content, implement transitions, or build motion systems. Implements W3C Design Tokens, Material Design 3 baseline, and Lottie specification compliance.
---

# Motion Design Agent

Motion design specialist grounded in industry standards. Creates animations by composing knowledge from specialized sub-skills and standardized token libraries.

## Standards Compliance

This agent implements:
- **W3C Design Tokens (2025.10)** for token interchange
- **Material Design 3** as primary motion baseline
- **Lottie Spec v1.0** for animation export
- **WCAG 2.1** for accessibility

## Industry Context

Material Design 3 serves as the baseline because:
1. Most comprehensive public motion specification
2. Widely adopted across industry (referenced by Klarna, others)
3. Clear token naming conventions
4. Well-documented transition patterns

Cross-reference other systems when:
- Building for Windows/Office → Fluent 2
- Building for Apple platforms → Apple HIG
- Building enterprise apps → Carbon (IBM)

## Workflow

1. **Parse** — Identify animation type, platform, constraints
2. **Select tokens** — Load from `tokens/*.tokens.json`
3. **Apply principles** — Consult `skills/motion-principles/`
4. **Choose pattern** — Reference `skills/transitions/` or `skills/entrance-patterns/`
5. **Implement** — Use appropriate tool (Remotion, GSAP, Framer Motion, Lottie)
6. **Verify accessibility** — Check `skills/accessibility/`

## Token Library

All motion values are stored in W3C DTCG format:

```
tokens/
├── motion.tokens.json      # Complete set
├── easing.tokens.json      # Curves only
├── duration.tokens.json    # Timing only
└── spring.tokens.json      # Physics configs
```

Load tokens with: `cat tokens/motion.tokens.json`

## Sub-Skill Index

| Need | Skill | Standards Reference |
|------|-------|---------------------|
| Motion philosophy | `skills/motion-principles/` | M3, Carbon, Fluent |
| Easing curves | `skills/easing/` | W3C DTCG, M3, CSS |
| Duration/timing | `skills/duration/` | W3C DTCG, M3 |
| Page transitions | `skills/transitions/` | M3 transition patterns |
| Entrances | `skills/entrance-patterns/` | M3 |
| Exits | `skills/exit-patterns/` | M3 |
| Accessibility | `skills/accessibility/` | WCAG 2.1 |
| Lottie export | `skills/lottie/` | LAC Lottie Spec v1.0 |
| Remotion video | `skills/remotion/` | Remotion docs |
| Tool selection | `skills/tools/` | GSAP, Framer Motion, Rive |

## Decision Framework

### Easing Selection (M3 Baseline)
```
ENTERING → emphasized-decelerate: cubic-bezier(0.05, 0.7, 0.1, 1)
EXITING  → emphasized-accelerate: cubic-bezier(0.3, 0, 0.8, 0.15)
MOVING   → standard: cubic-bezier(0.2, 0, 0, 1)
LOOPING  → linear: cubic-bezier(0, 0, 1, 1)
```

### Duration Selection (M3 Baseline)
```
Micro-interaction  → short1-short2 (50-100ms)
Small component    → short3-short4 (150-200ms)
Medium component   → medium1-medium2 (250-300ms)
Large transition   → medium3-medium4 (350-400ms)
Page transition    → long1-long2 (450-500ms)
```

### Tool Selection
```
Pre-designed playback    → Lottie
Interactive/stateful     → Rive
Complex JS sequences     → GSAP
React declarative        → Framer Motion
Video rendering          → Remotion
Lightweight web          → CSS / Motion One
```

## Output Requirements

All implementations must:
1. Use token names from `tokens/` (not raw values)
2. Include reduced motion alternative
3. Specify which standard informed the decision
4. Provide code that imports from token files
```

---

## W3C Design Tokens Files

### `tokens/motion.tokens.json` (Complete Set)

```json
{
  "$schema": "https://designtokens.org/schemas/draft-2/schema.json",
  "$description": "Motion design tokens following W3C DTCG specification, with Material Design 3 as baseline",
  
  "motion": {
    "$description": "Complete motion token library",
    
    "easing": {
      "$description": "Easing curves in W3C DTCG cubicBezier format",
      
      "standard": {
        "$value": [0.2, 0, 0, 1],
        "$type": "cubicBezier",
        "$description": "Standard easing for most animations. M3: standard, Fluent: decelerate, Carbon: standard"
      },
      "emphasized": {
        "$value": [0.2, 0, 0, 1],
        "$type": "cubicBezier",
        "$description": "Emphasized easing for important transitions. M3: emphasized"
      },
      "emphasized-decelerate": {
        "$value": [0.05, 0.7, 0.1, 1],
        "$type": "cubicBezier",
        "$description": "For elements ENTERING the screen. Fast start, gentle settle. M3: emphasized-decelerate"
      },
      "emphasized-accelerate": {
        "$value": [0.3, 0, 0.8, 0.15],
        "$type": "cubicBezier",
        "$description": "For elements EXITING the screen. Slow start, fast exit. M3: emphasized-accelerate"
      },
      "standard-decelerate": {
        "$value": [0, 0, 0, 1],
        "$type": "cubicBezier",
        "$description": "Simple deceleration for basic entrances. M3: standard-decelerate"
      },
      "standard-accelerate": {
        "$value": [0.3, 0, 1, 1],
        "$type": "cubicBezier",
        "$description": "Simple acceleration for basic exits. M3: standard-accelerate"
      },
      "linear": {
        "$value": [0, 0, 1, 1],
        "$type": "cubicBezier",
        "$description": "Linear motion for continuous animations (spinners, progress). All systems: linear"
      },
      
      "cross-reference": {
        "$description": "Equivalent curves in other design systems",
        
        "fluent-decelerate": {
          "$value": [0.1, 0.9, 0.2, 1],
          "$type": "cubicBezier",
          "$description": "Fluent 2 decelerate curve"
        },
        "fluent-accelerate": {
          "$value": [0.9, 0.1, 1, 0.2],
          "$type": "cubicBezier",
          "$description": "Fluent 2 accelerate curve"
        },
        "carbon-standard": {
          "$value": [0.2, 0, 0.38, 0.9],
          "$type": "cubicBezier",
          "$description": "Carbon productive-standard curve"
        },
        "carbon-entrance": {
          "$value": [0, 0, 0.38, 0.9],
          "$type": "cubicBezier",
          "$description": "Carbon productive-entrance curve"
        },
        "carbon-exit": {
          "$value": [0.2, 0, 1, 0.9],
          "$type": "cubicBezier",
          "$description": "Carbon productive-exit curve"
        },
        "carbon-expressive-standard": {
          "$value": [0.4, 0.14, 0.3, 1],
          "$type": "cubicBezier",
          "$description": "Carbon expressive-standard curve"
        }
      }
    },
    
    "duration": {
      "$description": "Duration tokens in milliseconds. W3C DTCG duration type.",
      
      "short-1": {
        "$value": "50ms",
        "$type": "duration",
        "$description": "Micro-interactions, ripples. M3: short1"
      },
      "short-2": {
        "$value": "100ms",
        "$type": "duration",
        "$description": "Simple state changes, toggles. M3: short2"
      },
      "short-3": {
        "$value": "150ms",
        "$type": "duration",
        "$description": "Small elements, icons. M3: short3"
      },
      "short-4": {
        "$value": "200ms",
        "$type": "duration",
        "$description": "Selection controls, buttons. M3: short4"
      },
      "medium-1": {
        "$value": "250ms",
        "$type": "duration",
        "$description": "Cards, small components. M3: medium1"
      },
      "medium-2": {
        "$value": "300ms",
        "$type": "duration",
        "$description": "Dialogs, sheets. M3: medium2"
      },
      "medium-3": {
        "$value": "350ms",
        "$type": "duration",
        "$description": "Medium transitions. M3: medium3"
      },
      "medium-4": {
        "$value": "400ms",
        "$type": "duration",
        "$description": "Complex transitions. M3: medium4"
      },
      "long-1": {
        "$value": "450ms",
        "$type": "duration",
        "$description": "Page transitions. M3: long1"
      },
      "long-2": {
        "$value": "500ms",
        "$type": "duration",
        "$description": "Expressive animations. M3: long2"
      },
      "long-3": {
        "$value": "550ms",
        "$type": "duration",
        "$description": "Extended expressions. M3: long3"
      },
      "long-4": {
        "$value": "600ms",
        "$type": "duration",
        "$description": "Maximum standard duration. M3: long4"
      },
      
      "cross-reference": {
        "$description": "Equivalent durations in other design systems",
        
        "fluent-ultra-fast": {
          "$value": "50ms",
          "$type": "duration",
          "$description": "Fluent 2 ultra-fast"
        },
        "fluent-faster": {
          "$value": "100ms",
          "$type": "duration",
          "$description": "Fluent 2 faster"
        },
        "fluent-fast": {
          "$value": "150ms",
          "$type": "duration",
          "$description": "Fluent 2 fast"
        },
        "fluent-normal": {
          "$value": "200ms",
          "$type": "duration",
          "$description": "Fluent 2 normal"
        },
        "fluent-slow": {
          "$value": "300ms",
          "$type": "duration",
          "$description": "Fluent 2 slow"
        },
        "fluent-slower": {
          "$value": "400ms",
          "$type": "duration",
          "$description": "Fluent 2 slower"
        },
        "fluent-ultra-slow": {
          "$value": "500ms",
          "$type": "duration",
          "$description": "Fluent 2 ultra-slow"
        },
        "carbon-fast-01": {
          "$value": "70ms",
          "$type": "duration",
          "$description": "Carbon fast-01"
        },
        "carbon-fast-02": {
          "$value": "110ms",
          "$type": "duration",
          "$description": "Carbon fast-02"
        },
        "carbon-moderate-01": {
          "$value": "150ms",
          "$type": "duration",
          "$description": "Carbon moderate-01"
        },
        "carbon-moderate-02": {
          "$value": "240ms",
          "$type": "duration",
          "$description": "Carbon moderate-02"
        },
        "carbon-slow-01": {
          "$value": "400ms",
          "$type": "duration",
          "$description": "Carbon slow-01"
        },
        "carbon-slow-02": {
          "$value": "700ms",
          "$type": "duration",
          "$description": "Carbon slow-02"
        }
      }
    },
    
    "spring": {
      "$description": "Spring physics configurations. Not in W3C DTCG spec, but widely used.",
      
      "standard": {
        "$value": {
          "damping": 15,
          "stiffness": 150,
          "mass": 1
        },
        "$type": "object",
        "$description": "Standard spring matching M3 standard feel"
      },
      "snappy": {
        "$value": {
          "damping": 25,
          "stiffness": 300,
          "mass": 0.5
        },
        "$type": "object",
        "$description": "Quick, snappy response for small elements"
      },
      "bouncy": {
        "$value": {
          "damping": 10,
          "stiffness": 180,
          "mass": 1
        },
        "$type": "object",
        "$description": "Playful bounce for expressive moments"
      },
      "gentle": {
        "$value": {
          "damping": 25,
          "stiffness": 100,
          "mass": 1.2
        },
        "$type": "object",
        "$description": "Slow, gentle settle for large elements"
      },
      "enter": {
        "$value": {
          "damping": 20,
          "stiffness": 180,
          "mass": 1
        },
        "$type": "object",
        "$description": "Entrance spring matching M3 emphasized-decelerate feel"
      }
    },
    
    "transition": {
      "$description": "Composite transition tokens combining duration and easing",
      
      "fade-in": {
        "$value": {
          "duration": "{motion.duration.medium-1}",
          "timingFunction": "{motion.easing.emphasized-decelerate}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "Standard fade-in entrance"
      },
      "fade-out": {
        "$value": {
          "duration": "{motion.duration.short-4}",
          "timingFunction": "{motion.easing.emphasized-accelerate}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "Standard fade-out exit"
      },
      "slide-up": {
        "$value": {
          "duration": "{motion.duration.medium-1}",
          "timingFunction": "{motion.easing.emphasized-decelerate}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "Slide up entrance (combine with fade)"
      },
      "container-transform": {
        "$value": {
          "duration": "{motion.duration.long-2}",
          "timingFunction": "{motion.easing.emphasized}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "M3 container transform transition"
      },
      "shared-axis": {
        "$value": {
          "duration": "{motion.duration.medium-4}",
          "timingFunction": "{motion.easing.emphasized}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "M3 shared axis transition"
      },
      "fade-through": {
        "$value": {
          "duration": "{motion.duration.medium-2}",
          "timingFunction": "{motion.easing.standard}",
          "delay": "0ms"
        },
        "$type": "transition",
        "$description": "M3 fade through transition"
      }
    }
  }
}
```

---

## Sub-Skill: `skills/easing/SKILL.md`

```markdown
---
name: easing
description: Easing curves and cubic-bezier values from industry standards. Use when selecting animation easing, understanding curve differences across design systems, or implementing easing in code. References W3C DTCG, M3, Fluent, Carbon, and CSS standards.
---

# Easing Curves

Industry-standard easing curves with cross-system comparison.

## Standards Reference

| Standard | Documentation |
|----------|---------------|
| W3C DTCG | designtokens.org (cubicBezier type) |
| Material Design 3 | m3.material.io/styles/motion/easing-and-duration |
| Fluent 2 | fluent2.microsoft.design/motion |
| Carbon | carbondesignsystem.com/guidelines/motion |
| CSS | w3.org/TR/css-easing-1 |

## Primary Curves (M3 Baseline)

Load from: `tokens/easing.tokens.json`

| Token | Cubic Bezier | Use |
|-------|--------------|-----|
| `standard` | (0.2, 0, 0, 1) | Most animations |
| `emphasized-decelerate` | (0.05, 0.7, 0.1, 1) | **Entering** screen |
| `emphasized-accelerate` | (0.3, 0, 0.8, 0.15) | **Exiting** screen |
| `linear` | (0, 0, 1, 1) | Continuous loops |

## Selection Guide

```
Is element ENTERING? → emphasized-decelerate
Is element EXITING?  → emphasized-accelerate
Is element MOVING?   → standard
Is it CONTINUOUS?    → linear
Is it IMPORTANT?     → emphasized
```

## Cross-System Comparison

| Purpose | M3 | Fluent | Carbon |
|---------|-----|--------|--------|
| Standard | (0.2, 0, 0, 1) | (0.1, 0.9, 0.2, 1) | (0.2, 0, 0.38, 0.9) |
| Enter | (0.05, 0.7, 0.1, 1) | (0.1, 0.9, 0.2, 1) | (0, 0, 0.38, 0.9) |
| Exit | (0.3, 0, 0.8, 0.15) | (0.9, 0.1, 1, 0.2) | (0.2, 0, 1, 0.9) |

## Implementation

### JavaScript (GSAP)
```javascript
import tokens from '../tokens/easing.tokens.json';

const easing = tokens.motion.easing;
gsap.to('.element', {
  x: 100,
  duration: 0.3,
  ease: `cubic-bezier(${easing.standard.$value.join(',')})`
});
```

### CSS
```css
.entering {
  transition: all 250ms cubic-bezier(0.05, 0.7, 0.1, 1);
}
.exiting {
  transition: all 200ms cubic-bezier(0.3, 0, 0.8, 0.15);
}
```

### Remotion
```javascript
import { Easing } from 'remotion';
import tokens from '../tokens/easing.tokens.json';

const [x1, y1, x2, y2] = tokens.motion.easing['emphasized-decelerate'].$value;
const easing = Easing.bezier(x1, y1, x2, y2);
```

### React (Framer Motion)
```jsx
<motion.div
  animate={{ opacity: 1 }}
  transition={{ 
    duration: 0.25,
    ease: [0.05, 0.7, 0.1, 1] // emphasized-decelerate
  }}
/>
```

See `references/curve-comparison.md` for visual comparisons.
See `references/easing-selection.md` for detailed selection logic.
```

---

## Sub-Skill: `skills/duration/SKILL.md`

```markdown
---
name: duration
description: Duration and timing tokens from industry standards. Use when selecting animation duration, converting between milliseconds and frames, or comparing timing across design systems. References W3C DTCG, M3, Fluent, and Carbon specifications.
---

# Duration & Timing

Industry-standard duration tokens with cross-system comparison.

## Standards Reference

| Standard | Documentation |
|----------|---------------|
| W3C DTCG | designtokens.org (duration type) |
| Material Design 3 | m3.material.io/styles/motion/easing-and-duration |
| Fluent 2 | fluent2.microsoft.design/motion |
| Carbon | carbondesignsystem.com/guidelines/motion |

## M3 Duration Scale (Primary)

Load from: `tokens/duration.tokens.json`

| Token | Value | Use Case |
|-------|-------|----------|
| `short-1` | 50ms | Micro-feedback, ripples |
| `short-2` | 100ms | Toggles, checkboxes |
| `short-3` | 150ms | Icons, small elements |
| `short-4` | 200ms | Buttons, chips |
| `medium-1` | 250ms | Cards, list items |
| `medium-2` | 300ms | Dialogs, modals |
| `medium-3` | 350ms | Sheets, drawers |
| `medium-4` | 400ms | Complex expansions |
| `long-1` | 450ms | Page transitions |
| `long-2` | 500ms | Hero animations |

## Selection Guide

```
MICRO-INTERACTION?     → short-1 to short-2 (50-100ms)
SMALL COMPONENT?       → short-3 to short-4 (150-200ms)
MEDIUM COMPONENT?      → medium-1 to medium-2 (250-300ms)
LARGE TRANSITION?      → medium-3 to medium-4 (350-400ms)
PAGE/NAV CHANGE?       → long-1 to long-2 (450-500ms)
```

## Cross-System Comparison

| M3 | Fluent | Carbon | Value |
|----|--------|--------|-------|
| short-1 | ultra-fast | - | 50ms |
| short-2 | faster | fast-02 | 100-110ms |
| short-3 | fast | moderate-01 | 150ms |
| short-4 | normal | - | 200ms |
| medium-1 | - | moderate-02 | 240-250ms |
| medium-2 | slow | - | 300ms |
| medium-4 | slower | slow-01 | 400ms |
| long-2 | ultra-slow | - | 500ms |
| - | - | slow-02 | 700ms |

## Frame Conversion

| Duration | 24fps | 30fps | 60fps |
|----------|-------|-------|-------|
| 50ms | 1 | 2 | 3 |
| 100ms | 2 | 3 | 6 |
| 150ms | 4 | 5 | 9 |
| 200ms | 5 | 6 | 12 |
| 250ms | 6 | 8 | 15 |
| 300ms | 7 | 9 | 18 |
| 400ms | 10 | 12 | 24 |
| 500ms | 12 | 15 | 30 |

## Implementation

### JavaScript
```javascript
import tokens from '../tokens/duration.tokens.json';

const duration = tokens.motion.duration;
const ms = parseInt(duration['medium-1'].$value); // 250

// Convert to seconds for GSAP
gsap.to('.element', { x: 100, duration: ms / 1000 });
```

### Remotion (frames at 30fps)
```javascript
const msToFrames = (ms, fps = 30) => Math.round((ms / 1000) * fps);

// medium-1 (250ms) = 8 frames at 30fps
const frames = msToFrames(250, 30);
```

See `references/duration-by-context.md` for contextual selection.
See `references/frame-conversion.md` for all frame rate tables.
```

---

## Sub-Skill: `skills/accessibility/SKILL.md`

```markdown
---
name: accessibility
description: Motion accessibility standards and reduced motion implementation. Use when ensuring WCAG compliance, implementing prefers-reduced-motion, or creating accessible animation alternatives. References WCAG 2.1 and design system accessibility guidelines.
---

# Motion Accessibility

WCAG 2.1 compliance and reduced motion implementation.

## Standards Reference

| Standard | Documentation |
|----------|---------------|
| WCAG 2.1 | w3.org/WAI/WCAG21/Understanding/animation-from-interactions |
| WCAG 2.3.3 | Animation from Interactions (AAA) |
| M3 Accessibility | m3.material.io/styles/motion/accessibility |

## Requirements

### WCAG 2.3.3 (AAA)
Motion can be disabled unless essential to functionality.

### Key Rules
1. **Honor `prefers-reduced-motion`** — Always check user preference
2. **No flashing > 3Hz** — Seizure risk
3. **Provide pause/stop** — For auto-playing content
4. **Essential motion can remain** — But reduce intensity

## Who Is Affected

- ~35% of adults 40+ have vestibular dysfunction
- Triggers: parallax, zooming, spinning, bouncing
- Symptoms: dizziness, nausea, disorientation

## Reduced Motion Strategy

### Remove
- Decorative animations
- Parallax effects
- Auto-playing animations
- Continuous motion

### Reduce
- Use `short-1`/`short-2` durations
- Minimize travel distance
- Remove overshooting/bouncing

### Replace
- Slide → Fade
- Scale → Opacity
- Complex → Simple state change

### Retain
- Essential feedback (simplified)
- State indicators
- Focus visibility

## Implementation

### CSS
```css
/* Disable all motion */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

/* Better: Provide alternatives */
@media (prefers-reduced-motion: reduce) {
  .slide-in {
    animation: none;
    opacity: 1;
  }
}
```

### JavaScript
```javascript
const prefersReducedMotion = window.matchMedia(
  '(prefers-reduced-motion: reduce)'
).matches;

const getAnimation = () => prefersReducedMotion
  ? { opacity: [0, 1], duration: 100 }  // Fade only, short
  : { opacity: [0, 1], y: [20, 0], duration: 250 };  // Full animation
```

### React (Framer Motion)
```jsx
import { useReducedMotion } from 'framer-motion';

const Component = () => {
  const shouldReduceMotion = useReducedMotion();
  
  return (
    <motion.div
      animate={{ opacity: 1, y: shouldReduceMotion ? 0 : 20 }}
      transition={{ duration: shouldReduceMotion ? 0.1 : 0.25 }}
    />
  );
};
```

## Alternatives Table

| Full Motion | Reduced Alternative | Duration |
|-------------|---------------------|----------|
| Slide + fade | Fade only | short-2 (100ms) |
| Scale from 0.5 | Scale from 0.95 | short-2 (100ms) |
| Spring bounce | ease-out, no overshoot | short-3 (150ms) |
| Container transform | Cross-fade | medium-1 (250ms) |
| Parallax | Static or subtle opacity | - |

## Safe Animations (Always OK)

- Opacity transitions
- Color transitions
- Border/outline changes
- Very short durations (<100ms)
- User-initiated animations

See `references/wcag-requirements.md` for full WCAG text.
See `references/reduced-motion-alternatives.md` for complete mapping.
```

---

## Sub-Skill: `skills/lottie/SKILL.md`

```markdown
---
name: lottie
description: Lottie animation format specification and usage. Use when exporting animations as Lottie JSON, working with dotLottie packages, or understanding Lottie capabilities and limitations. References LAC Lottie Spec v1.0 and dotLottie v2.0.
---

# Lottie Specification

Industry-standard vector animation format.

## Standards Reference

| Standard | Authority | Version |
|----------|-----------|---------|
| Lottie Spec | Linux Foundation LAC | v1.0 (2024) |
| dotLottie | LottieFiles | v2.0 |
| IANA Registration | IANA | MIME: video/lottie+json |

## Format Details

```
File Extension: .json (legacy), .lot (IANA registered)
MIME Type: video/lottie+json
Compression: None (JSON), gzip optional
```

## Capabilities

✓ Vector graphics (shapes, paths, masks)
✓ Keyframe animation
✓ Easing curves (cubic bezier)
✓ Layer compositions
✓ Text layers
✓ Image assets (embedded or external)
✓ Expressions (limited)

## Limitations

✗ No native interactivity (requires external code)
✗ Limited After Effects feature support
✗ No state machines (use Rive for that)
✗ Some effects not supported (3D, certain blurs)

## Creation Tools

| Tool | Export Method |
|------|---------------|
| After Effects | Bodymovin plugin |
| LottieFiles Editor | Native export |
| Lottielab | Native export |
| Figma | Plugins (LottieFiles, Phase) |
| Rive | Export option |

## dotLottie v2.0 Structure

```
.lottie (ZIP archive)
├── manifest.json          # Required
├── animations/
│   ├── animation_1.json
│   └── animation_2.json
├── images/                # Optional
└── themes/                # v2.0
```

## When to Use Lottie vs Rive

| Use Case | Lottie | Rive |
|----------|--------|------|
| Pre-designed playback | ✓ Best | Good |
| Interactive elements | Limited | ✓ Best |
| After Effects workflow | ✓ Best | Manual |
| File size priority | Good | ✓ Best (10-15x smaller) |
| State machines | ✗ | ✓ Built-in |
| Cross-platform | ✓ Excellent | ✓ Good |

## Implementation

### Web (lottie-web)
```javascript
import lottie from 'lottie-web';

lottie.loadAnimation({
  container: document.getElementById('container'),
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'animation.json'
});
```

### React
```jsx
import Lottie from 'lottie-react';
import animationData from './animation.json';

<Lottie animationData={animationData} loop={true} />
```

### Remotion
```jsx
import { Lottie } from '@remotion/lottie';
import animationData from './animation.json';

<Lottie animationData={animationData} />
```

See `references/lottie-spec.md` for full specification details.
See `references/dotlottie-spec.md` for packaging format.
See `references/supported-features.md` for AE compatibility matrix.
```

---

## Sub-Skill: `skills/tools/SKILL.md`

```markdown
---
name: tools
description: Animation tool selection and implementation guidance. Use when choosing between GSAP, Framer Motion, Rive, CSS, or other animation tools. Provides comparison and implementation patterns for each.
---

# Animation Tools

Tool selection guide and implementation patterns.

## Tool Comparison

| Tool | Best For | Bundle Size | Learning Curve |
|------|----------|-------------|----------------|
| **CSS** | Simple transitions | 0kb | Low |
| **GSAP** | Complex sequences | ~60kb | Medium |
| **Framer Motion** | React apps | ~30kb | Medium |
| **Motion One** | Lightweight web | ~3kb | Low |
| **Lottie** | Pre-designed playback | ~50kb | Low |
| **Rive** | Interactive/stateful | ~150kb | Medium |
| **Remotion** | Video rendering | N/A | Medium |

## Selection Decision Tree

```
Is it a simple hover/transition?
  → CSS

Is it a pre-designed animation from After Effects?
  → Lottie

Does it need complex state logic?
  → Rive

Is it a complex sequence with precise timing?
  → GSAP

Is it a React app with declarative needs?
  → Framer Motion

Do you need smallest bundle size?
  → Motion One or CSS

Are you rendering video?
  → Remotion
```

## Implementation Examples

### CSS (Simple Transitions)
```css
.button {
  transition: 
    transform 200ms cubic-bezier(0.2, 0, 0, 1),
    opacity 200ms cubic-bezier(0.2, 0, 0, 1);
}
.button:hover {
  transform: scale(1.05);
}
```

### GSAP (Complex Sequences)
```javascript
import gsap from 'gsap';

const tl = gsap.timeline();
tl.from('.title', { opacity: 0, y: 20, duration: 0.3, ease: 'power2.out' })
  .from('.subtitle', { opacity: 0, y: 20, duration: 0.3, ease: 'power2.out' }, '-=0.1')
  .from('.cta', { opacity: 0, scale: 0.9, duration: 0.3, ease: 'back.out(1.7)' }, '-=0.1');
```

### Framer Motion (React)
```jsx
import { motion, AnimatePresence } from 'framer-motion';

<AnimatePresence>
  {isVisible && (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.25, ease: [0.05, 0.7, 0.1, 1] }}
    />
  )}
</AnimatePresence>
```

### Motion One (Lightweight)
```javascript
import { animate } from 'motion';

animate('.element', 
  { opacity: [0, 1], y: [20, 0] },
  { duration: 0.25, easing: [0.05, 0.7, 0.1, 1] }
);
```

See `references/gsap.md` for GSAP deep dive.
See `references/framer-motion.md` for Framer Motion patterns.
See `references/rive.md` for Rive state machines.
```

---

## Reference: `references/industry-standards.md`

```markdown
# Industry Standards Overview

## The Standards Landscape

There is no single governing body for animation standards. The industry relies on:

1. **Design System Guidelines** — De facto standards (M3, Fluent, Carbon, Apple HIG)
2. **File Format Specifications** — Technical interchange (Lottie, dotLottie, W3C DTCG)
3. **Best Practice Consensus** — Shared across major companies

## Why Material Design 3 as Baseline

M3 is the closest to an "industry standard" because:

1. **Most comprehensive** — Complete motion specification with tokens
2. **Widely adopted** — Used as benchmark by Klarna, others
3. **Well documented** — Clear rationale for all values
4. **Cross-platform** — Android, Web, Flutter, iOS
5. **Open** — Publicly documented, free to use

## Standards Authority

| Domain | Authority | Documentation |
|--------|-----------|---------------|
| Token Format | W3C DTCG | designtokens.org |
| Animation Format | Linux Foundation LAC | lottie.github.io |
| Android Motion | Google M3 | m3.material.io |
| iOS Motion | Apple HIG | developer.apple.com/design |
| Windows Motion | Microsoft Fluent | fluent2.microsoft.design |
| Enterprise Motion | IBM Carbon | carbondesignsystem.com |
| Accessibility | W3C WCAG | w3.org/WAI/WCAG21 |

## Key Specifications

### W3C Design Tokens (2025.10)
- Stable specification for token interchange
- Supports: duration, cubicBezier, transition types
- Backed by: Adobe, Google, Microsoft, Figma, others
- URL: designtokens.org

### Lottie Spec v1.0 (2024)
- Vector animation interchange format
- IANA registered MIME type: video/lottie+json
- Maintained by: Linux Foundation Lottie Animation Community
- URL: lottie.github.io

### dotLottie v2.0
- Packaged Lottie container format
- Adds: theming, state machines, multi-animation
- Maintained by: LottieFiles
- URL: dotlottie.io/spec
```

---

## Reference: `references/design-system-comparison.md`

```markdown
# Design System Motion Comparison

## Principles Comparison

| System | Categories |
|--------|------------|
| **M3** | Informative, Focused, Expressive |
| **Fluent** | Functional, Natural, Consistent, Appealing |
| **Carbon** | Productive, Expressive |
| **Apple** | Purpose, Continuity, Fluidity |

## Easing Comparison

| Purpose | M3 | Fluent | Carbon |
|---------|-----|--------|--------|
| Standard | (0.2, 0, 0, 1) | (0.1, 0.9, 0.2, 1) | (0.2, 0, 0.38, 0.9) |
| Enter | (0.05, 0.7, 0.1, 1) | (0.1, 0.9, 0.2, 1) | (0, 0, 0.38, 0.9) |
| Exit | (0.3, 0, 0.8, 0.15) | (0.9, 0.1, 1, 0.2) | (0.2, 0, 1, 0.9) |
| Linear | (0, 0, 1, 1) | (0, 0, 1, 1) | (0, 0, 1, 1) |

## Duration Comparison

| Use Case | M3 | Fluent | Carbon |
|----------|-----|--------|--------|
| Micro | 50ms (short-1) | 50ms (ultra-fast) | 70ms (fast-01) |
| Small | 150ms (short-3) | 150ms (fast) | 150ms (moderate-01) |
| Medium | 300ms (medium-2) | 300ms (slow) | 240ms (moderate-02) |
| Large | 500ms (long-2) | 500ms (ultra-slow) | 400ms (slow-01) |
| Expressive | - | - | 700ms (slow-02) |

## When to Use Which System

| Platform/Context | Primary System | Secondary |
|------------------|----------------|-----------|
| Android | M3 | - |
| iOS | Apple HIG | M3 for reference |
| Windows | Fluent 2 | M3 for reference |
| Web (general) | M3 | Any |
| Enterprise | Carbon | M3 |
| Cross-platform | M3 | Platform-specific adjustments |
```

---

## Generation Instructions

### 1. Create Directory Structure

```bash
mkdir -p motion-design/{references,tokens,assets/lottie}
mkdir -p motion-design/skills/{motion-principles,easing,duration,transitions,entrance-patterns,exit-patterns,accessibility,lottie,remotion,tools}

# Create reference subdirectories
for skill in motion-principles easing duration transitions accessibility lottie remotion tools; do
  mkdir -p motion-design/skills/$skill/references
done

mkdir -p motion-design/skills/remotion/scripts
```

### 2. Generate Files in Order

1. `tokens/motion.tokens.json` (W3C DTCG format)
2. `SKILL.md` (root orchestrator)
3. `references/industry-standards.md`
4. `references/design-system-comparison.md`
5. All `skills/*/SKILL.md` files
6. All `skills/*/references/*.md` files

### 3. Validation

```bash
# Validate agentskills.io compliance
skills-ref validate ./motion-design

# Validate W3C DTCG token format
npx style-dictionary validate tokens/motion.tokens.json
```

---

## Compliance Summary

| Standard | Compliance |
|----------|------------|
| agentskills.io | ✓ SKILL.md format, frontmatter, directory structure |
| W3C Design Tokens | ✓ JSON format with $value, $type, $description |
| Material Design 3 | ✓ Primary baseline for all motion values |
| Lottie Spec v1.0 | ✓ Referenced for animation export |
| WCAG 2.1 | ✓ Accessibility requirements documented |
| Cross-system | ✓ Fluent, Carbon, Apple HIG cross-referenced |

---

## Success Criteria

The system works when:

1. All tokens use W3C DTCG format
2. All motion values trace to M3 (or explicit cross-reference)
3. Agent can compare values across design systems
4. Implementations import from token files
5. Accessibility alternatives are always provided
6. Tool selection is well-reasoned
7. Lottie export follows specification
