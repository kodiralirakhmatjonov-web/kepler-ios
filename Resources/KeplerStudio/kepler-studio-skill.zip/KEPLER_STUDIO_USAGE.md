# kepler-studio

Source: Kepler Studio v0.2.
Repository: Kepler Studio v0.2 source distribution

This ZIP is a reference/agent-skill distribution. It does not automatically install into ChatGPT or Claude, grant account access, or implement a native iOS rendering engine. Verify external dependencies and their licenses for your platform. Kepler Studio AGENTS.md overrides any upstream advice that would redraw supplied source assets.
